# 14 · Repair Warranty Ledger

Track: Policy · Difficulty: Intermediate · Suggested time: 90–120 minutes

Repair a service ledger whose coverage boundary, accidental damage, cumulative extensions and repeated requests must agree.

This is a fictional training policy, not a real commercial or employment rule. The starter runs but deliberately violates this specification. Diagnose the failures, repair the business logic and implement TC10.

## API and data model

`Main(purchaseDay, baseDays)` owns the ledger and its receipt records. Public method names are identical across the three languages. The primary operation is `repair(Repair ID, Day, Kind (BATTERY/SCREEN/CASE), Accidental (true/false), Downtime days)`. Read-only methods are `expiryDay()`, `extensionDays()`, `repairCount()`.

Java rejects invalid operations with `IllegalArgumentException`, Python with `ValueError`, and JavaScript with `Error`. Tests use integer values, strings and booleans of the declared types; fractional numbers and cross-type coercions are out of scope. No database, network, clock or concurrent access is needed.

## Authoritative rules

1. Constructor Main(purchaseDay, baseDays) accepts purchase day 0–1000 and base duration 1–365. Initial expiry = purchaseDay + baseDays. All time is integer days; money is integer training credits.
2. repair(id, day, kind, accidental, downtime) accepts a nonempty ID, day 0–2000, kind exactly BATTERY, SCREEN or CASE, a boolean accidental flag, and downtime 0–30. Reject a day before purchaseDay.
3. BATTERY costs 800, SCREEN costs 1200 and CASE costs 300. A non-accidental BATTERY or SCREEN repair is free only when purchaseDay <= day < current expiry. CASE is a consumable and is always charged. Accidental damage is always charged.
4. Only a covered free repair extends the expiry. Add min(downtime, 10 − total previous extension). The cumulative extension across all covered repairs cannot exceed 10 days. Charged repairs add no extension.
5. Validate argument values first. An already stored request ID with exactly matching day, kind, accidental and downtime returns its original fee, with no new extension. Changed arguments under that ID are a conflict.
6. New accepted repair events must arrive in nondecreasing day order. Replays can refer to older stored days. A rejected event changes no state. expiryDay(), extensionDays(), repairCount() report state.

## Worked examples

- **Input:** Purchase day 10, base 30; manufacturing BATTERY repair day 39 with downtime 8. **Expected:** Fee 0; expiry 48; extension 8. Day 39 is strictly before original expiry 40.
- **Input:** Then covered SCREEN on day 47, downtime 8; then BATTERY on day 50. **Expected:** SCREEN fee 0 and expiry 50; BATTERY fee 800. Only two extension days remain; day 50 is outside the half-open coverage window.

## Supplied tests

Every test creates a fresh instance. Test fixtures are explicit in each runner.

| Case | Purpose | Required outcome |
|---|---|---|
| TC1 | Covered repair | Free covered battery repair |
| TC2 | Unknown component | Unknown kind rejected |
| TC3 | Exclusive expiry boundary | 800 on exact expiry day |
| TC4 | Accidental damage | Accidental repair costs 800 |
| TC5 | Charged repair cannot extend | 300 fee and unchanged expiry 40 |
| TC6 | Cumulative extension cap | Extension capped at 10 |
| TC7 | Repeated repair is idempotent | One repair and expiry 43 |
| TC8 | Correct component price | SCREEN costs 1200 |
| TC9 | Pre-purchase event | Day before purchase rejected |

## TC10 — candidate-owned test

Start Main(10, 30). repair(A, 39, BATTERY, False, 8) must return 0; repair(B, 47, SCREEN, False, 8) must return 0; repair(C, 50, BATTERY, False, 9) must return 800; repair(B, 47, SCREEN, False, 8) must return 0; expiryDay() must return 50; extensionDays() must return 10; repairCount() must return 3. Verify state using explicit expected values.

Expected final result: **Expiry 50, extension 10, three events; exact expiry charged, old retry remains free**. Replace only the TC10 stub with real assertions; do not call the implementation to derive expected values.

## Run

Choose one language folder. Each folder contains this complete statement as `PROBLEM.md`, the business implementation, a test runner and a console app. No third-party dependencies are needed.

### Java

From `01_Java`:

```sh
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

### Python

From `02_Python`:

```sh
python3 test_runner.py
python3 app.py
```

### JavaScript

From `03_JavaScript`:

```sh
node test_runner.js
node app.js
```

Use a working JDK 17+ for Java, Python 3.8+ or Node.js 18+. The test runner always attempts all ten cases and exits nonzero if any fail. A repaired application with an unfinished TC10 should report 9/10; complete work reports 10/10.

## Console workflow

The console starts with `Main(10, 30)`. Option 1 runs an isolated demonstration; option 2 accepts user values for `repair`; option 3 reports the current instance; option 4 resets it; option 5 exits. The demo does not change your working instance. Invalid input prints an error and returns to the menu.

## Deliverables

1. Record the initial results and a concise root-cause log.
2. Fix business code while preserving the public methods and supplied TC1–TC9 assertions.
3. Complete TC10, reach ten passing cases and demonstrate the console with an independent example.
4. Explain each repair and its boundary cases; do not hard-code fixture answers or disable tests.

## Discussion

- Why is expiry exclusive?
- Why retain the original fee?
- What is the invariant for extension?
