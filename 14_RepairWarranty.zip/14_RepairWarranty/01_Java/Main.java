import java.util.*;

public class Main {

  private final int purchase;
  private int expiry,
    extension,
    last = -1;
  private final Map<String, String> requests = new HashMap<>();
  private final Map<String, Integer> repairs = new HashMap<>();

  public Main(int purchaseDay, int baseDays) {
    if (
      purchaseDay < 0 || purchaseDay > 1000 || baseDays < 1 || baseDays > 365
    ) throw new IllegalArgumentException("invalid warranty");
    purchase = purchaseDay;
    expiry = purchaseDay + baseDays;
  }

  public int repair(
    String rid,
    int day,
    String kind,
    boolean accidental,
    int downtime
  ) {
    Map<String, Integer> prices = new HashMap<>();
    prices.put("BATTERY", 800);
    prices.put("SCREEN", 1000);
    prices.put("CASE", 300);
    if (
      rid == null ||
      rid.isEmpty() ||
      day < 0 ||
      day > 2000 ||
      !prices.containsKey(kind) ||
      downtime < 0 ||
      downtime > 30
    ) throw new IllegalArgumentException("invalid repair");
    String signature = day + ":" + kind + ":" + accidental + ":" + downtime;
    if (repairs.containsKey(rid)) {
      if (
        !requests.get(rid).equals(signature)
      ) throw new IllegalArgumentException("conflicting retry");
      int extra = Math.min(downtime, 10);
      extension += extra;
      expiry += extra;
      return repairs.get(rid);
    }
    if (day < last) throw new IllegalArgumentException("out of order");
    boolean covered = !kind.equals("CASE") && day <= expiry;
    int fee = covered ? 0 : prices.get(kind);
    int extra = Math.min(downtime, 10);
    extension += extra;
    expiry += extra;
    last = day;
    requests.put(rid, signature);
    repairs.put(rid, fee);
    return fee;
  }

  public int expiryDay() {
    return expiry;
  }

  public int extensionDays() {
    return extension;
  }

  public int repairCount() {
    return repairs.size();
  }
}
