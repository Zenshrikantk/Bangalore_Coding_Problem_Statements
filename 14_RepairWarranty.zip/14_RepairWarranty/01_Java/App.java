import java.util.*;

public class App {

  static final Scanner input = new Scanner(System.in);

  static String read(String prompt) {
    System.out.print(prompt + ": ");
    return input.nextLine().trim();
  }

  static int number(String prompt) {
    return Integer.parseInt(read(prompt));
  }

  static boolean bool(String prompt) {
    String s = read(prompt).toLowerCase(Locale.ROOT);
    if (
      !s.equals("true") && !s.equals("false")
    ) throw new IllegalArgumentException("enter true or false");
    return Boolean.parseBoolean(s);
  }

  static void report(Main m) {
    System.out.println("expiryDay: " + m.expiryDay());
    System.out.println("extensionDays: " + m.extensionDays());
    System.out.println("repairCount: " + m.repairCount());
  }

  static void demo() {
    Main m = new Main(10, 30);
    System.out.println("Result: " + m.repair("DEMO", 39, "BATTERY", false, 8));
    System.out.println("Result: " + m.repair("DEMO2", 47, "SCREEN", false, 8));
    report(m);
  }

  public static void main(String[] args) {
    Main m = new Main(10, 30);
    System.out.println("Repair Warranty Ledger — fictional training exercise");
    while (true) {
      try {
        String choice = read(
          "\n1 Demo | 2 repair | 3 Report | 4 Reset | 5 Exit\nChoice"
        );
        if (choice.equals("5")) break;
        if (choice.equals("1")) demo();
        else if (choice.equals("2")) {
          String v0 = read("Repair ID");
          int v1 = number("Day");
          String v2 = read("Kind (BATTERY/SCREEN/CASE)");
          boolean v3 = bool("Accidental (true/false)");
          int v4 = number("Downtime days");
          System.out.println("Result: " + m.repair(v0, v1, v2, v3, v4));
        } else if (choice.equals("3")) report(m);
        else if (choice.equals("4")) {
          m = new Main(10, 30);
          System.out.println("Reset complete");
        } else System.out.println("Enter 1 through 5");
      } catch (NoSuchElementException error) {
        break;
      } catch (IllegalArgumentException error) {
        System.out.println("Error: " + error.getMessage());
      }
    }
  }
}
