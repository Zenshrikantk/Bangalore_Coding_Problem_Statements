import java.util.*;

public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!Objects.equals(expected, actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void rejects(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException error) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Main m = new Main(10, 30);
    eq(0, m.repair("A", 11, "BATTERY", false, 0));
    eq(1, m.repairCount());
  }

  static void tc2() {
    Main m = new Main(10, 30);
    rejects(() -> m.repair("A", 11, "MOTOR", false, 0));
    eq(0, m.repairCount());
  }

  static void tc3() {
    Main m = new Main(10, 30);
    eq(800, m.repair("A", 40, "BATTERY", false, 0));
  }

  static void tc4() {
    Main m = new Main(10, 30);
    eq(800, m.repair("A", 20, "BATTERY", true, 0));
  }

  static void tc5() {
    Main m = new Main(10, 30);
    eq(300, m.repair("A", 20, "CASE", false, 4));
    eq(40, m.expiryDay());
  }

  static void tc6() {
    Main m = new Main(10, 30);
    eq(0, m.repair("A", 20, "BATTERY", false, 8));
    eq(0, m.repair("B", 21, "BATTERY", false, 8));
    eq(50, m.expiryDay());
    eq(10, m.extensionDays());
  }

  static void tc7() {
    Main m = new Main(10, 30);
    eq(0, m.repair("A", 20, "BATTERY", false, 3));
    eq(0, m.repair("A", 20, "BATTERY", false, 3));
    eq(43, m.expiryDay());
    eq(1, m.repairCount());
  }

  static void tc8() {
    Main m = new Main(10, 30);
    eq(1200, m.repair("A", 60, "SCREEN", true, 0));
  }

  static void tc9() {
    Main m = new Main(10, 30);
    rejects(() -> m.repair("A", 9, "BATTERY", false, 0));
    eq(0, m.repairCount());
  }

  static void tc10() {
    // Start Main(10, 30). repair(A, 39, BATTERY, False, 8) must return 0; repair(B, 47, SCREEN, False, 8) must return 0; repair(C, 50, BATTERY, False, 9) must return 800; repair(B, 47, SCREEN, False, 8) must return 0; expiryDay() must return 50; extensionDays() must return 10; repairCount() must return 3. Verify state using explicit expected values.
    throw new AssertionError("Implement TC10 with independent expected values");
  }

  public static void main(String[] args) {
    Runnable[] tests = {
      TestRunner::tc1,
      TestRunner::tc2,
      TestRunner::tc3,
      TestRunner::tc4,
      TestRunner::tc5,
      TestRunner::tc6,
      TestRunner::tc7,
      TestRunner::tc8,
      TestRunner::tc9,
      TestRunner::tc10,
    };
    int passed = 0;
    for (int i = 0; i < tests.length; i++) {
      try {
        tests[i].run();
        passed++;
        System.out.println("TC" + (i + 1) + ": PASS");
      } catch (Exception | AssertionError error) {
        System.out.println(
          "TC" + (i + 1) + ": FAIL (" + error.getMessage() + ")"
        );
      }
    }
    System.out.println(
      "SUMMARY: " + passed + "/10 PASS; " + (10 - passed) + " FAIL"
    );
    if (passed != 10) System.exit(1);
  }
}
