class Main:
    def __init__(self, purchaseDay, baseDays):
        if purchaseDay < 0 or purchaseDay > 1000 or baseDays < 1 or baseDays > 365:
            raise ValueError("invalid warranty")
        self.purchase = purchaseDay
        self.expiry = purchaseDay + baseDays
        self.extension = 0
        self.last = -1
        self.repairs = {}

    def repair(self, rid, day, kind, accidental, downtime):
        prices = {"BATTERY": 800, "SCREEN": 1000, "CASE": 300}
        if (
            not rid
            or day < 0
            or day > 2000
            or kind not in prices
            or downtime < 0
            or downtime > 30
        ):
            raise ValueError("invalid repair")
        signature = (day, kind, accidental, downtime)
        if rid in self.repairs:
            old, fee = self.repairs[rid]
            if old != signature:
                raise ValueError("conflicting retry")
            extra = min(downtime, 10)
            self.extension += extra
            self.expiry += extra
            return fee
        if day < self.last:
            raise ValueError("out of order")
        covered = kind != "CASE" and day <= self.expiry
        fee = 0 if covered else prices[kind]
        extra = min(downtime, 10)
        self.extension += extra
        self.expiry += extra
        self.last = day
        self.repairs[rid] = (signature, fee)
        return fee

    def expiryDay(self):
        return self.expiry

    def extensionDays(self):
        return self.extension

    def repairCount(self):
        return len(self.repairs)
