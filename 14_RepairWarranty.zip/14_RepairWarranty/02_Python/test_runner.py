from main import Main


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    m = Main(10, 30)
    eq(0, m.repair("A", 11, "BATTERY", False, 0))
    eq(1, m.repairCount())


def tc2():
    m = Main(10, 30)
    rejects(lambda: m.repair("A", 11, "MOTOR", False, 0))
    eq(0, m.repairCount())


def tc3():
    m = Main(10, 30)
    eq(800, m.repair("A", 40, "BATTERY", False, 0))


def tc4():
    m = Main(10, 30)
    eq(800, m.repair("A", 20, "BATTERY", True, 0))


def tc5():
    m = Main(10, 30)
    eq(300, m.repair("A", 20, "CASE", False, 4))
    eq(40, m.expiryDay())


def tc6():
    m = Main(10, 30)
    eq(0, m.repair("A", 20, "BATTERY", False, 8))
    eq(0, m.repair("B", 21, "BATTERY", False, 8))
    eq(50, m.expiryDay())
    eq(10, m.extensionDays())


def tc7():
    m = Main(10, 30)
    eq(0, m.repair("A", 20, "BATTERY", False, 3))
    eq(0, m.repair("A", 20, "BATTERY", False, 3))
    eq(43, m.expiryDay())
    eq(1, m.repairCount())


def tc8():
    m = Main(10, 30)
    eq(1200, m.repair("A", 60, "SCREEN", True, 0))


def tc9():
    m = Main(10, 30)
    rejects(lambda: m.repair("A", 9, "BATTERY", False, 0))
    eq(0, m.repairCount())


def tc10():
    # Start Main(10, 30). repair(A, 39, BATTERY, False, 8) must return 0; repair(B, 47, SCREEN, False, 8) must return 0; repair(C, 50, BATTERY, False, 9) must return 800; repair(B, 47, SCREEN, False, 8) must return 0; expiryDay() must return 50; extensionDays() must return 10; repairCount() must return 3. Verify state using explicit expected values.
    raise AssertionError("Implement TC10 with independent expected values")


if __name__ == "__main__":
    passed = 0
    for i, test in enumerate([tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10], 1):
        try:
            test()
            passed += 1
            print(f"TC{i}: PASS")
        except Exception as error:
            print(f"TC{i}: FAIL ({error})")
    print(f"SUMMARY: {passed}/10 PASS; {10-passed} FAIL")
    raise SystemExit(0 if passed == 10 else 1)
