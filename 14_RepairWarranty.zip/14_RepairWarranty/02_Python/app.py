from main import Main


def read_value(prompt, kind):
    text = input(prompt + ": ").strip()
    if kind == "int":
        return int(text)
    if kind == "bool":
        if text.lower() not in ("true", "false"):
            raise ValueError("enter true or false")
        return text.lower() == "true"
    return text


def report(m):
    print("expiryDay:", m.expiryDay())
    print("extensionDays:", m.extensionDays())
    print("repairCount:", m.repairCount())


def demo():
    m = Main(10, 30)
    print("Result:", m.repair("DEMO", 39, "BATTERY", False, 8))
    print("Result:", m.repair("DEMO2", 47, "SCREEN", False, 8))
    report(m)


def main():
    m = Main(10, 30)
    print("Repair Warranty Ledger — fictional training exercise")
    while True:
        try:
            choice = input(
                "\n1 Demo | 2 repair | 3 Report | 4 Reset | 5 Exit\nChoice: "
            ).strip()
            if choice == "5":
                break
            if choice == "1":
                demo()
            elif choice == "2":
                v0 = read_value("Repair ID", "str")
                v1 = read_value("Day", "int")
                v2 = read_value("Kind (BATTERY/SCREEN/CASE)", "str")
                v3 = read_value("Accidental (true/false)", "bool")
                v4 = read_value("Downtime days", "int")
                print("Result:", m.repair(v0, v1, v2, v3, v4))
            elif choice == "3":
                report(m)
            elif choice == "4":
                m = Main(10, 30)
                print("Reset complete")
            else:
                print("Enter 1 through 5")
        except EOFError:
            break
        except (ValueError, TypeError) as error:
            print("Error:", error)


if __name__ == "__main__":
    main()
