class Main {
  constructor(purchaseDay, baseDays) {
    if (purchaseDay < 0 || purchaseDay > 1000 || baseDays < 1 || baseDays > 365)
      throw new Error("invalid warranty");
    this.purchase = purchaseDay;
    this.expiry = purchaseDay + baseDays;
    this.extension = 0;
    this.last = -1;
    this.repairs = new Map();
  }
  repair(rid, day, kind, accidental, downtime) {
    const prices = new Map([
      ["BATTERY", 800],
      ["SCREEN", 1000],
      ["CASE", 300],
    ]);
    if (
      !rid ||
      day < 0 ||
      day > 2000 ||
      !prices.has(kind) ||
      downtime < 0 ||
      downtime > 30
    )
      throw new Error("invalid repair");
    const signature = JSON.stringify([day, kind, accidental, downtime]);
    if (this.repairs.has(rid)) {
      const [old, fee] = this.repairs.get(rid);
      if (old !== signature) throw new Error("conflicting retry");
      const extra = Math.min(downtime, 10);
      this.extension += extra;
      this.expiry += extra;
      return fee;
    }
    if (day < this.last) throw new Error("out of order");
    const covered = kind !== "CASE" && day <= this.expiry;
    const fee = covered ? 0 : prices.get(kind);
    const extra = Math.min(downtime, 10);
    this.extension += extra;
    this.expiry += extra;
    this.last = day;
    this.repairs.set(rid, [signature, fee]);
    return fee;
  }
  expiryDay() {
    return this.expiry;
  }
  extensionDays() {
    return this.extension;
  }
  repairCount() {
    return this.repairs.size;
  }
}
module.exports = { Main };
