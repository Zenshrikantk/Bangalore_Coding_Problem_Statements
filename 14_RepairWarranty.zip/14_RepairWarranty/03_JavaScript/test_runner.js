const { Main } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function rejects(fn) {
  try {
    fn();
  } catch (error) {
    if (error instanceof Error) return;
    throw error;
  }
  throw new Error("expected Error");
}
function tc1() {
  const m = new Main(10, 30);
  eq(0, m.repair("A", 11, "BATTERY", false, 0));
  eq(1, m.repairCount());
}
function tc2() {
  const m = new Main(10, 30);
  rejects(() => m.repair("A", 11, "MOTOR", false, 0));
  eq(0, m.repairCount());
}
function tc3() {
  const m = new Main(10, 30);
  eq(800, m.repair("A", 40, "BATTERY", false, 0));
}
function tc4() {
  const m = new Main(10, 30);
  eq(800, m.repair("A", 20, "BATTERY", true, 0));
}
function tc5() {
  const m = new Main(10, 30);
  eq(300, m.repair("A", 20, "CASE", false, 4));
  eq(40, m.expiryDay());
}
function tc6() {
  const m = new Main(10, 30);
  eq(0, m.repair("A", 20, "BATTERY", false, 8));
  eq(0, m.repair("B", 21, "BATTERY", false, 8));
  eq(50, m.expiryDay());
  eq(10, m.extensionDays());
}
function tc7() {
  const m = new Main(10, 30);
  eq(0, m.repair("A", 20, "BATTERY", false, 3));
  eq(0, m.repair("A", 20, "BATTERY", false, 3));
  eq(43, m.expiryDay());
  eq(1, m.repairCount());
}
function tc8() {
  const m = new Main(10, 30);
  eq(1200, m.repair("A", 60, "SCREEN", true, 0));
}
function tc9() {
  const m = new Main(10, 30);
  rejects(() => m.repair("A", 9, "BATTERY", false, 0));
  eq(0, m.repairCount());
}
function tc10() {
  // Start Main(10, 30). repair(A, 39, BATTERY, False, 8) must return 0; repair(B, 47, SCREEN, False, 8) must return 0; repair(C, 50, BATTERY, False, 9) must return 800; repair(B, 47, SCREEN, False, 8) must return 0; expiryDay() must return 50; extensionDays() must return 10; repairCount() must return 3. Verify state using explicit expected values.
  throw new Error("Implement TC10 with independent expected values");
}
let passed = 0;
[tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10].forEach((test, index) => {
  try {
    test();
    passed++;
    console.log(`TC${index + 1}: PASS`);
  } catch (error) {
    console.log(`TC${index + 1}: FAIL (${error.message})`);
  }
});
console.log(`SUMMARY: ${passed}/10 PASS; ${10 - passed} FAIL`);
process.exitCode = passed === 10 ? 0 : 1;
