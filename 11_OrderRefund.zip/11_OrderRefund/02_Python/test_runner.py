from main import Main


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    m = Main(5, 100, 0)
    eq(100, m.refund("A", 1, 0))
    eq(1, m.receiptCount())


def tc2():
    m = Main(5, 125, 20)
    rejects(lambda: m.refund("A", 0, 0))
    eq(5, m.remaining())


def tc3():
    m = Main(5, 125, 20)
    eq(200, m.refund("A", 2, 1))


def tc4():
    m = Main(5, 125, 20)
    eq(100, m.refund("A", 1, 30))


def tc5():
    m = Main(5, 125, 20)
    eq(100, m.refund("A", 1, 1))
    eq(100, m.refund("B", 1, 2))
    eq(200, m.totalRefunded())


def tc6():
    m = Main(5, 125, 20)
    eq(300, m.refund("A", 3, 2))
    eq(2, m.remaining())


def tc7():
    m = Main(5, 125, 20)
    eq(100, m.refund("A", 1, 1))
    eq(100, m.refund("A", 1, 70))
    eq(100, m.totalRefunded())


def tc8():
    m = Main(5, 125, 20)
    eq(100, m.refund("A", 1, 1))
    rejects(lambda: m.refund("B", 5, 2))
    eq(4, m.remaining())
    eq(100, m.totalRefunded())


def tc9():
    m = Main(5, 125, 20)
    eq(100, m.refund("A", 1, 1))
    rejects(lambda: m.refund("A", 2, 1))
    eq(1, m.receiptCount())


def tc10():
    # Start Main(5, 125, 20). refund(A, 2, 30) must return 200; refund(B, 1, 30) must return 100; refund(A, 2, 99) must return 200; refund(C, 3, 30) must reject; remaining() must return 2; totalRefunded() must return 300; receiptCount() must return 2. Verify state using explicit expected values.
    raise AssertionError("Implement TC10 with independent expected values")


if __name__ == "__main__":
    passed = 0
    for i, test in enumerate([tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10], 1):
        try:
            test()
            passed += 1
            print(f"TC{i}: PASS")
        except Exception as error:
            print(f"TC{i}: FAIL ({error})")
    print(f"SUMMARY: {passed}/10 PASS; {10-passed} FAIL")
    raise SystemExit(0 if passed == 10 else 1)
