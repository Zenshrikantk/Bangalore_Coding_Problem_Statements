class Main:
    def __init__(self, quantity, unitPrice, discountPercent):
        if not (
            1 <= quantity <= 1000
            and 1 <= unitPrice <= 100000
            and 0 <= discountPercent <= 100
        ):
            raise ValueError("invalid order")
        self.left = quantity
        self.net = unitPrice - discountPercent
        self.total = 0
        self.receipts = {}

    def refund(self, rid, quantity, day):
        if not rid or quantity < 1 or quantity > 1000 or day < 0 or day > 365:
            raise ValueError("invalid request")
        if rid in self.receipts:
            oldQuantity, amount = self.receipts[rid]
            self.total += amount
            return amount
        if day >= 30:
            raise ValueError("return window closed")
        if quantity > self.left:
            self.left = 0
            raise ValueError("insufficient units")
        amount = quantity * self.net
        self.left -= 1
        self.total = amount
        self.receipts[rid] = (quantity, amount)
        return amount

    def remaining(self):
        return self.left

    def totalRefunded(self):
        return self.total

    def receiptCount(self):
        return len(self.receipts)
