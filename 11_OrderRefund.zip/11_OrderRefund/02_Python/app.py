from main import Main


def read_value(prompt, kind):
    text = input(prompt + ": ").strip()
    if kind == "int":
        return int(text)
    if kind == "bool":
        if text.lower() not in ("true", "false"):
            raise ValueError("enter true or false")
        return text.lower() == "true"
    return text


def report(m):
    print("remaining:", m.remaining())
    print("totalRefunded:", m.totalRefunded())
    print("receiptCount:", m.receiptCount())


def demo():
    m = Main(5, 125, 20)
    print("Result:", m.refund("DEMO", 2, 30))
    print("Result:", m.refund("DEMO", 2, 70))
    report(m)


def main():
    m = Main(5, 125, 20)
    print("Partial Order Refunds — fictional training exercise")
    while True:
        try:
            choice = input(
                "\n1 Demo | 2 refund | 3 Report | 4 Reset | 5 Exit\nChoice: "
            ).strip()
            if choice == "5":
                break
            if choice == "1":
                demo()
            elif choice == "2":
                v0 = read_value("Refund ID", "str")
                v1 = read_value("Quantity", "int")
                v2 = read_value("Day since delivery", "int")
                print("Result:", m.refund(v0, v1, v2))
            elif choice == "3":
                report(m)
            elif choice == "4":
                m = Main(5, 125, 20)
                print("Reset complete")
            else:
                print("Enter 1 through 5")
        except EOFError:
            break
        except (ValueError, TypeError) as error:
            print("Error:", error)


if __name__ == "__main__":
    main()
