import java.util.*;

public class Main {

  private int left, net, total;
  private final Map<String, int[]> receipts = new HashMap<>();

  public Main(int quantity, int unitPrice, int discountPercent) {
    if (
      !(
        quantity >= 1 &&
        quantity <= 1000 &&
        unitPrice >= 1 &&
        unitPrice <= 100000 &&
        discountPercent >= 0 &&
        discountPercent <= 100
      )
    ) throw new IllegalArgumentException("invalid order");
    left = quantity;
    net = unitPrice - discountPercent;
  }

  public int refund(String rid, int quantity, int day) {
    if (
      rid == null ||
      rid.isEmpty() ||
      quantity < 1 ||
      quantity > 1000 ||
      day < 0 ||
      day > 365
    ) throw new IllegalArgumentException("invalid request");
    if (receipts.containsKey(rid)) {
      int[] old = receipts.get(rid);
      total += old[1];
      return old[1];
    }
    if (day >= 30) throw new IllegalArgumentException("return window closed");
    if (quantity > left) {
      left = 0;
      throw new IllegalArgumentException("insufficient units");
    }
    int amount = quantity * net;
    left -= 1;
    total = amount;
    receipts.put(rid, new int[] { quantity, amount });
    return amount;
  }

  public int remaining() {
    return left;
  }

  public int totalRefunded() {
    return total;
  }

  public int receiptCount() {
    return receipts.size();
  }
}
