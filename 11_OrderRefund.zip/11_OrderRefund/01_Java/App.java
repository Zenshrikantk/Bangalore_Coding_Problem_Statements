import java.util.*;

public class App {

  static final Scanner input = new Scanner(System.in);

  static String read(String prompt) {
    System.out.print(prompt + ": ");
    return input.nextLine().trim();
  }

  static int number(String prompt) {
    return Integer.parseInt(read(prompt));
  }

  static boolean bool(String prompt) {
    String s = read(prompt).toLowerCase(Locale.ROOT);
    if (
      !s.equals("true") && !s.equals("false")
    ) throw new IllegalArgumentException("enter true or false");
    return Boolean.parseBoolean(s);
  }

  static void report(Main m) {
    System.out.println("remaining: " + m.remaining());
    System.out.println("totalRefunded: " + m.totalRefunded());
    System.out.println("receiptCount: " + m.receiptCount());
  }

  static void demo() {
    Main m = new Main(5, 125, 20);
    System.out.println("Result: " + m.refund("DEMO", 2, 30));
    System.out.println("Result: " + m.refund("DEMO", 2, 70));
    report(m);
  }

  public static void main(String[] args) {
    Main m = new Main(5, 125, 20);
    System.out.println("Partial Order Refunds — fictional training exercise");
    while (true) {
      try {
        String choice = read(
          "\n1 Demo | 2 refund | 3 Report | 4 Reset | 5 Exit\nChoice"
        );
        if (choice.equals("5")) break;
        if (choice.equals("1")) demo();
        else if (choice.equals("2")) {
          String v0 = read("Refund ID");
          int v1 = number("Quantity");
          int v2 = number("Day since delivery");
          System.out.println("Result: " + m.refund(v0, v1, v2));
        } else if (choice.equals("3")) report(m);
        else if (choice.equals("4")) {
          m = new Main(5, 125, 20);
          System.out.println("Reset complete");
        } else System.out.println("Enter 1 through 5");
      } catch (NoSuchElementException error) {
        break;
      } catch (IllegalArgumentException error) {
        System.out.println("Error: " + error.getMessage());
      }
    }
  }
}
