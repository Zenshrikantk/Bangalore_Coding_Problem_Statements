import java.util.*;

public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!Objects.equals(expected, actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void rejects(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException error) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Main m = new Main(5, 100, 0);
    eq(100, m.refund("A", 1, 0));
    eq(1, m.receiptCount());
  }

  static void tc2() {
    Main m = new Main(5, 125, 20);
    rejects(() -> m.refund("A", 0, 0));
    eq(5, m.remaining());
  }

  static void tc3() {
    Main m = new Main(5, 125, 20);
    eq(200, m.refund("A", 2, 1));
  }

  static void tc4() {
    Main m = new Main(5, 125, 20);
    eq(100, m.refund("A", 1, 30));
  }

  static void tc5() {
    Main m = new Main(5, 125, 20);
    eq(100, m.refund("A", 1, 1));
    eq(100, m.refund("B", 1, 2));
    eq(200, m.totalRefunded());
  }

  static void tc6() {
    Main m = new Main(5, 125, 20);
    eq(300, m.refund("A", 3, 2));
    eq(2, m.remaining());
  }

  static void tc7() {
    Main m = new Main(5, 125, 20);
    eq(100, m.refund("A", 1, 1));
    eq(100, m.refund("A", 1, 70));
    eq(100, m.totalRefunded());
  }

  static void tc8() {
    Main m = new Main(5, 125, 20);
    eq(100, m.refund("A", 1, 1));
    rejects(() -> m.refund("B", 5, 2));
    eq(4, m.remaining());
    eq(100, m.totalRefunded());
  }

  static void tc9() {
    Main m = new Main(5, 125, 20);
    eq(100, m.refund("A", 1, 1));
    rejects(() -> m.refund("A", 2, 1));
    eq(1, m.receiptCount());
  }

  static void tc10() {
    // Start Main(5, 125, 20). refund(A, 2, 30) must return 200; refund(B, 1, 30) must return 100; refund(A, 2, 99) must return 200; refund(C, 3, 30) must reject; remaining() must return 2; totalRefunded() must return 300; receiptCount() must return 2. Verify state using explicit expected values.
    throw new AssertionError("Implement TC10 with independent expected values");
  }

  public static void main(String[] args) {
    Runnable[] tests = {
      TestRunner::tc1,
      TestRunner::tc2,
      TestRunner::tc3,
      TestRunner::tc4,
      TestRunner::tc5,
      TestRunner::tc6,
      TestRunner::tc7,
      TestRunner::tc8,
      TestRunner::tc9,
      TestRunner::tc10,
    };
    int passed = 0;
    for (int i = 0; i < tests.length; i++) {
      try {
        tests[i].run();
        passed++;
        System.out.println("TC" + (i + 1) + ": PASS");
      } catch (Exception | AssertionError error) {
        System.out.println(
          "TC" + (i + 1) + ": FAIL (" + error.getMessage() + ")"
        );
      }
    }
    System.out.println(
      "SUMMARY: " + passed + "/10 PASS; " + (10 - passed) + " FAIL"
    );
    if (passed != 10) System.exit(1);
  }
}
