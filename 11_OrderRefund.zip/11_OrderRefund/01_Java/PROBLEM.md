# 11 · Partial Order Refunds

Track: Policy · Difficulty: Intermediate · Suggested time: 90–120 minutes

Repair a refund ledger that must refund discounted unit prices, respect a return window, and make retries safe.

This is a fictional training policy, not a real commercial or employment rule. The starter runs but deliberately violates this specification. Diagnose the failures, repair the business logic and implement TC10.

## API and data model

`Main(quantity, unitPrice, discountPercent)` owns the ledger and its receipt records. Public method names are identical across the three languages. The primary operation is `refund(Refund ID, Quantity, Day since delivery)`. Read-only methods are `remaining()`, `totalRefunded()`, `receiptCount()`.

Java rejects invalid operations with `IllegalArgumentException`, Python with `ValueError`, and JavaScript with `Error`. Tests use integer values, strings and booleans of the declared types; fractional numbers and cross-type coercions are out of scope. No database, network, clock or concurrent access is needed.

## Authoritative rules

1. An order has 1–1000 units, integer unit price 1–100000 and discount percent 0–100. Money is in whole training credits. The constructor rejects values outside these ranges.
2. Compute netUnit = floor(unitPrice × (100 − discountPercent) / 100) once per unit. Each refund returns quantity × netUnit. This per-unit rounding is intentional; do not round the line total instead.
3. refund(id, quantity, day) accepts a nonempty string ID, quantity 1–1000 and integer day 0–365. New refunds are allowed on days 0 through 30 inclusive. Day 0 is the delivery day.
4. Validate argument ranges first. If an ID already exists, the same quantity returns its original amount without changing state, even after day 30. A different quantity is a conflict; the day is not part of the retry identity.
5. For a new ID, check the return window and sufficient remaining units before changing any state. A rejected request changes neither remaining units, cumulative refund nor receipt count.
6. remaining(), totalRefunded() and receiptCount() report state. Repeated calls do not mutate it. Cumulative refunds cannot exceed the original net order value.

## Worked examples

- **Input:** Order 5 × 125, 20% discount; refund R-A for 2 units on day 30. **Expected:** 200 credits; remaining 3; cumulative 200. Net unit is floor(125 × 80 / 100) = 100.
- **Input:** Retry R-A for 2 units on day 70. **Expected:** 200 credits again; remaining 3; cumulative 200. A valid retry reuses its original receipt and does not refund twice.

## Supplied tests

Every test creates a fresh instance. Test fixtures are explicit in each runner.

| Case | Purpose | Required outcome |
|---|---|---|
| TC1 | One-unit refund | 100 credits and one receipt |
| TC2 | Invalid quantity | Rejected; five units remain |
| TC3 | Percentage arithmetic | 200 credits |
| TC4 | Inclusive return deadline | 100 credits on day 30 |
| TC5 | Cumulative refund ledger | Cumulative 200 |
| TC6 | Multi-unit stock accounting | Two units remain |
| TC7 | Idempotent replay | Replay leaves cumulative refund 100 |
| TC8 | Atomic shortage rejection | Rejected shortage leaves four units and 100 refunded |
| TC9 | Conflicting retry | Conflicting quantity rejected |

## TC10 — candidate-owned test

Start Main(5, 125, 20). refund(A, 2, 30) must return 200; refund(B, 1, 30) must return 100; refund(A, 2, 99) must return 200; refund(C, 3, 30) must reject; remaining() must return 2; totalRefunded() must return 300; receiptCount() must return 2. Verify state using explicit expected values.

Expected final result: **Two accepted receipts, two remaining units, cumulative 300; late replay succeeds and shortage is atomic**. Replace only the TC10 stub with real assertions; do not call the implementation to derive expected values.

## Run

Choose one language folder. Each folder contains this complete statement as `PROBLEM.md`, the business implementation, a test runner and a console app. No third-party dependencies are needed.

### Java

From `01_Java`:

```sh
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

### Python

From `02_Python`:

```sh
python3 test_runner.py
python3 app.py
```

### JavaScript

From `03_JavaScript`:

```sh
node test_runner.js
node app.js
```

Use a working JDK 17+ for Java, Python 3.8+ or Node.js 18+. The test runner always attempts all ten cases and exits nonzero if any fail. A repaired application with an unfinished TC10 should report 9/10; complete work reports 10/10.

## Console workflow

The console starts with `Main(5, 125, 20)`. Option 1 runs an isolated demonstration; option 2 accepts user values for `refund`; option 3 reports the current instance; option 4 resets it; option 5 exits. The demo does not change your working instance. Invalid input prints an error and returns to the menu.

## Deliverables

1. Record the initial results and a concise root-cause log.
2. Fix business code while preserving the public methods and supplied TC1–TC9 assertions.
3. Complete TC10, reach ten passing cases and demonstrate the console with an independent example.
4. Explain each repair and its boundary cases; do not hard-code fixture answers or disable tests.

## Discussion

- Why round per unit?
- Why check retry before the return window?
- What does atomic rejection protect?
