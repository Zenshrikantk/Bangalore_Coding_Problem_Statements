class Main {
  constructor(quantity, unitPrice, discountPercent) {
    if (!(
      quantity >= 1 &&
      quantity <= 1000 &&
      unitPrice >= 1 &&
      unitPrice <= 100000 &&
      discountPercent >= 0 &&
      discountPercent <= 100
    ))
      throw new Error("invalid order");
    this.left = quantity;
    this.net = unitPrice - discountPercent;
    this.total = 0;
    this.receipts = new Map();
  }
  refund(rid, quantity, day) {
    if (!rid || quantity < 1 || quantity > 1000 || day < 0 || day > 365)
      throw new Error("invalid request");
    if (this.receipts.has(rid)) {
      const [oldQuantity, amount] = this.receipts.get(rid);
      this.total += amount;
      return amount;
    }
    if (day >= 30) throw new Error("return window closed");
    if (quantity > this.left) {
      this.left = 0;
      throw new Error("insufficient units");
    }
    const amount = quantity * this.net;
    this.left -= 1;
    this.total = amount;
    this.receipts.set(rid, [quantity, amount]);
    return amount;
  }
  remaining() {
    return this.left;
  }
  totalRefunded() {
    return this.total;
  }
  receiptCount() {
    return this.receipts.size;
  }
}
module.exports = { Main };
