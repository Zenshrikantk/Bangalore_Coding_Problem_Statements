const { Main } = require("./main");
const readline = require("readline");
const input = readline.createInterface({
  input: process.stdin,
  crlfDelay: Infinity,
});
const lines = input[Symbol.asyncIterator]();
async function read(prompt) {
  process.stdout.write(prompt + ": ");
  const next = await lines.next();
  return next.done ? null : next.value.trim();
}
async function value(prompt, kind) {
  const text = await read(prompt);
  if (text === null) throw new Error("end of input");
  if (kind === "int") {
    if (!/^-?[0-9]+$/.test(text) || !Number.isSafeInteger(Number(text)))
      throw new Error("enter an integer");
    return Number(text);
  }
  if (kind === "bool") {
    if (!["true", "false"].includes(text.toLowerCase()))
      throw new Error("enter true or false");
    return text.toLowerCase() === "true";
  }
  return text;
}
function report(m) {
  console.log("remaining:", m.remaining());
  console.log("totalRefunded:", m.totalRefunded());
  console.log("receiptCount:", m.receiptCount());
}
function demo() {
  const m = new Main(5, 125, 20);
  console.log("Result:", m.refund("DEMO", 2, 30));
  console.log("Result:", m.refund("DEMO", 2, 70));
  report(m);
}
async function main() {
  let m = new Main(5, 125, 20);
  console.log("Partial Order Refunds — fictional training exercise");
  while (true) {
    const choice = await read(
      "\n1 Demo | 2 refund | 3 Report | 4 Reset | 5 Exit\nChoice",
    );
    if (choice === null || choice === "5") break;
    try {
      if (choice === "1") demo();
      else if (choice === "2") {
        const v0 = await value("Refund ID", "str");
        const v1 = await value("Quantity", "int");
        const v2 = await value("Day since delivery", "int");
        console.log("Result:", m.refund(v0, v1, v2));
      } else if (choice === "3") report(m);
      else if (choice === "4") {
        m = new Main(5, 125, 20);
        console.log("Reset complete");
      } else console.log("Enter 1 through 5");
    } catch (error) {
      console.log("Error:", error.message);
    }
  }
  input.close();
}
main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
