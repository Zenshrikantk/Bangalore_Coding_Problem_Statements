const { Main } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function rejects(fn) {
  try {
    fn();
  } catch (error) {
    if (error instanceof Error) return;
    throw error;
  }
  throw new Error("expected Error");
}
function tc1() {
  const m = new Main(5, 100, 0);
  eq(100, m.refund("A", 1, 0));
  eq(1, m.receiptCount());
}
function tc2() {
  const m = new Main(5, 125, 20);
  rejects(() => m.refund("A", 0, 0));
  eq(5, m.remaining());
}
function tc3() {
  const m = new Main(5, 125, 20);
  eq(200, m.refund("A", 2, 1));
}
function tc4() {
  const m = new Main(5, 125, 20);
  eq(100, m.refund("A", 1, 30));
}
function tc5() {
  const m = new Main(5, 125, 20);
  eq(100, m.refund("A", 1, 1));
  eq(100, m.refund("B", 1, 2));
  eq(200, m.totalRefunded());
}
function tc6() {
  const m = new Main(5, 125, 20);
  eq(300, m.refund("A", 3, 2));
  eq(2, m.remaining());
}
function tc7() {
  const m = new Main(5, 125, 20);
  eq(100, m.refund("A", 1, 1));
  eq(100, m.refund("A", 1, 70));
  eq(100, m.totalRefunded());
}
function tc8() {
  const m = new Main(5, 125, 20);
  eq(100, m.refund("A", 1, 1));
  rejects(() => m.refund("B", 5, 2));
  eq(4, m.remaining());
  eq(100, m.totalRefunded());
}
function tc9() {
  const m = new Main(5, 125, 20);
  eq(100, m.refund("A", 1, 1));
  rejects(() => m.refund("A", 2, 1));
  eq(1, m.receiptCount());
}
function tc10() {
  // Start Main(5, 125, 20). refund(A, 2, 30) must return 200; refund(B, 1, 30) must return 100; refund(A, 2, 99) must return 200; refund(C, 3, 30) must reject; remaining() must return 2; totalRefunded() must return 300; receiptCount() must return 2. Verify state using explicit expected values.
  throw new Error("Implement TC10 with independent expected values");
}
let passed = 0;
[tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10].forEach((test, index) => {
  try {
    test();
    passed++;
    console.log(`TC${index + 1}: PASS`);
  } catch (error) {
    console.log(`TC${index + 1}: FAIL (${error.message})`);
  }
});
console.log(`SUMMARY: ${passed}/10 PASS; ${10 - passed} FAIL`);
process.exitCode = passed === 10 ? 0 : 1;
