class DomainError(Exception):
    pass


def fail(code):
    raise DomainError(code)


def number(text):
    if not text.isascii() or not text.isdigit():
        fail("INPUT")
    return int(text)


def name(text):
    if not (
        1 <= len(text) <= 16
        and text[0].isalpha()
        and text.isascii()
        and all(c.isupper() or c.isdigit() or c == "_" for c in text)
    ):
        fail("INPUT")
    return text


class Engine:
    def execute(self, line):
        parts = line.strip().split()
        try:
            if not parts:
                fail("INPUT")
            return self.run(parts)
        except DomainError as exc:
            return "ERROR:" + str(exc)
        except (ValueError, IndexError):
            return "ERROR:INPUT"

    def __init__(self):
        self.rows = [[False] * 8 for _ in range(3)]
        self.bookings = {}

    def run(self, p):
        if p[0] == "STATUS" and len(p) == 1:
            return "FREE " + ",".join(
                chr(65 + r) + "=" + str(row.count(False))
                for r, row in enumerate(self.rows)
            )
        if p[0] == "BOOK" and len(p) == 3:
            booking, count = name(p[1]), number(p[2])
            if count < 1 or count > 8:
                fail("INPUT")
            candidates = []
            for r, row in enumerate(self.rows):
                start = 0
                while start < 8:
                    if row[start]:
                        start += 1
                        continue
                    end = start
                    while end < 8 and not row[end]:
                        end += 1
                    length = end - start
                    if length > count:
                        candidates.append((length - count, r, start))
                    start = end
            if not candidates:
                fail("FULL")
            candidates.sort(key=lambda x: (-x[0], -x[1], x[2]))
            _, r, start = candidates[0]
            for seat in range(start, start + count):
                self.rows[r][seat] = True
            self.bookings[booking] = [r, start, count, True]
            return (
                "BOOKED "
                + booking
                + " "
                + chr(65 + r)
                + ":"
                + str(start + 1)
                + "-"
                + str(start + count)
            )
        if p[0] == "CANCEL" and len(p) == 2:
            booking = name(p[1])
            if booking not in self.bookings:
                fail("UNKNOWN")
            entry = self.bookings[booking]
            r, start, count = entry[:3]
            for seat in range(start, start + count - 1):
                self.rows[r][seat] = False
            entry[3] = False
            return "CANCELLED " + booking
        fail("INPUT")
