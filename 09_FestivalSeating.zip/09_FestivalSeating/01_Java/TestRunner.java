import java.util.*;

public class TestRunner {

  static int passed = 0;

  static void check(
    int number,
    String title,
    String[] commands,
    String[] expected
  ) {
    try {
      Main engine = new Main();
      List<String> actual = new ArrayList<>();
      for (String command : commands) actual.add(engine.execute(command));
      if (!actual.equals(Arrays.asList(expected))) throw new AssertionError(
        "expected " + Arrays.toString(expected) + ", got " + actual
      );
      System.out.println("TC" + number + " PASS: " + title);
      passed++;
    } catch (Throwable e) {
      System.out.println(
        "TC" + number + " FAIL: " + title + " (" + e.getMessage() + ")"
      );
    }
  }

  public static void main(String[] args) {
    check(
      1,
      "Initial free seats",
      new String[] { "STATUS" },
      new String[] { "FREE A=8,B=8,C=8" }
    );
    check(
      2,
      "Invalid size and missing booking",
      new String[] { "BOOK X 0", "BOOK X 9", "CANCEL X", "STATUS" },
      new String[] {
        "ERROR:INPUT",
        "ERROR:INPUT",
        "ERROR:UNKNOWN",
        "FREE A=8,B=8,C=8",
      }
    );
    check(
      3,
      "Exact-size run is eligible",
      new String[] { "BOOK X 8", "STATUS" },
      new String[] { "BOOKED X A:1-8", "FREE A=0,B=8,C=8" }
    );
    check(
      4,
      "Equal runs prefer earlier row",
      new String[] { "BOOK X 2" },
      new String[] { "BOOKED X A:1-2" }
    );
    check(
      5,
      "Best fit beats earlier row",
      new String[] { "BOOK X 5", "BOOK Y 4", "CANCEL X", "BOOK Z 3" },
      new String[] {
        "BOOKED X A:1-5",
        "BOOKED Y B:1-4",
        "CANCELLED X",
        "BOOKED Z B:5-7",
      }
    );
    check(
      6,
      "Cancellation releases every seat",
      new String[] { "BOOK X 3", "CANCEL X", "STATUS" },
      new String[] { "BOOKED X A:1-3", "CANCELLED X", "FREE A=8,B=8,C=8" }
    );
    check(
      7,
      "Duplicate ID rejects atomically",
      new String[] { "BOOK X 2", "BOOK X 1", "STATUS" },
      new String[] { "BOOKED X A:1-2", "ERROR:DUPLICATE", "FREE A=6,B=8,C=8" }
    );
    check(
      8,
      "No capacity rejects without mutation",
      new String[] { "BOOK X 8", "BOOK Y 8", "BOOK Z 8", "BOOK Q 1", "STATUS" },
      new String[] {
        "BOOKED X A:1-8",
        "BOOKED Y B:1-8",
        "BOOKED Z C:1-8",
        "ERROR:FULL",
        "FREE A=0,B=0,C=0",
      }
    );
    check(
      9,
      "Repeated cancellation cannot free a new booking",
      new String[] { "BOOK X 2", "CANCEL X", "BOOK Y 2", "CANCEL X", "STATUS" },
      new String[] {
        "BOOKED X A:1-2",
        "CANCELLED X",
        "BOOKED Y A:1-2",
        "CANCELLED X",
        "FREE A=6,B=8,C=8",
      }
    );
    // TC10 task: Fill row A using bookings X=3, Y=3, Z=2. Cancel Y; book Q=2 and verify it occupies A:4-5. Cancel Y again and verify free counts remain A=1,B=8,C=8. Book R=1 and assert the exact remaining gap A:6-6 is used.
    try {
      throw new AssertionError("Implement TC10 with real assertions");
    } catch (AssertionError e) {
      System.out.println("TC10 FAIL: " + e.getMessage());
    }
    System.out.println("SUMMARY: " + passed + "/10 PASS");
    System.exit(passed == 10 ? 0 : 1);
  }
}
