import java.util.*;

public class Main {

  static class DomainError extends RuntimeException {

    DomainError(String code) {
      super(code);
    }
  }

  static void fail(String code) {
    throw new DomainError(code);
  }

  static int number(String text) {
    if (!text.matches("[0-9]+")) fail("INPUT");
    return Integer.parseInt(text);
  }

  static String name(String text) {
    if (!text.matches("[A-Z][A-Z0-9_]{0,15}")) fail("INPUT");
    return text;
  }

  public String execute(String line) {
    try {
      String[] p = line.trim().split("\\s+");
      if (p.length == 0 || p[0].isEmpty()) fail("INPUT");
      return run(p);
    } catch (DomainError e) {
      return "ERROR:" + e.getMessage();
    } catch (RuntimeException e) {
      return "ERROR:INPUT";
    }
  }

  private final boolean[][] rows = new boolean[3][8];
  private final Map<String, int[]> bookings = new HashMap<>();

  String run(String[] p) {
    if (p[0].equals("STATUS") && p.length == 1) {
      List<String> counts = new ArrayList<>();
      for (int r = 0; r < 3; r++) {
        int free = 0;
        for (boolean seat : rows[r]) if (!seat) free++;
        counts.add((char) (65 + r) + "=" + free);
      }
      return "FREE " + String.join(",", counts);
    }
    if (p[0].equals("BOOK") && p.length == 3) {
      String booking = name(p[1]);
      int count = number(p[2]);
      if (count < 1 || count > 8) fail("INPUT");
      List<int[]> candidates = new ArrayList<>();
      for (int r = 0; r < 3; r++) {
        int start = 0;
        while (start < 8) {
          if (rows[r][start]) {
            start++;
            continue;
          }
          int end = start;
          while (end < 8 && !rows[r][end]) end++;
          int length = end - start;
          if (length > count) candidates.add(new int[] {
            length - count,
            r,
            start,
          });
          start = end;
        }
      }
      if (candidates.isEmpty()) fail("FULL");
      candidates.sort((a, b) ->
        a[0] != b[0]
          ? Integer.compare(b[0], a[0])
          : a[1] != b[1]
            ? Integer.compare(b[1], a[1])
            : Integer.compare(a[2], b[2])
      );
      int r = candidates.get(0)[1],
        start = candidates.get(0)[2];
      for (int seat = start; seat < start + count; seat++) rows[r][seat] = true;
      bookings.put(booking, new int[] { r, start, count, 1 });
      return (
        "BOOKED " +
        booking +
        " " +
        (char) (65 + r) +
        ":" +
        (start + 1) +
        "-" +
        (start + count)
      );
    }
    if (p[0].equals("CANCEL") && p.length == 2) {
      String booking = name(p[1]);
      if (!bookings.containsKey(booking)) fail("UNKNOWN");
      int[] entry = bookings.get(booking);
      int r = entry[0],
        start = entry[1],
        count = entry[2];
      for (int seat = start; seat < start + count - 1; seat++) rows[r][seat] =
        false;
      entry[3] = 0;
      return "CANCELLED " + booking;
    }
    fail("INPUT");
    return "";
  }
}
