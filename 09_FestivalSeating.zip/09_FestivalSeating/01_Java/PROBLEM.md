# 09 · Festival Group Seating Debugging Challenge

Track: Algorithm | Difficulty: Intermediate | Suggested time: 90–120 minutes

A college festival promises adjacent seats to each group. Repair an allocator that must choose the smallest suitable free run and safely release bookings.

Repair the deliberately defective starter, prove the behavior with tests, and explain the algorithm. The rules below are authoritative.

## Contract and commands

- Entities: three rows A, B and C, each with seats 1..8; a booking stores its row, starting seat, count and active state. API: execute(command) on Engine (Python/JavaScript) or Main (Java). Commands are BOOK id count, CANCEL id, STATUS.
- Booking IDs match [A-Z][A-Z0-9_]{0,15}. Count is an integer 1..8. A session has at most 100 distinct booking IDs. Validate syntax/range before duplicate-ID checks; invalid input returns ERROR:INPUT.
- A booking must occupy one contiguous free run within one row. Find every maximal free run with length >= count; choose the run leaving the fewest unused seats. Ties choose the alphabetically earlier row, then the smaller starting seat. Allocate from the chosen run’s left edge. Exact-size runs are valid.
- No suitable run returns ERROR:FULL without changing seats or retaining the attempted ID. BOOK returns BOOKED id row:start-end on success. Existing IDs, even cancelled IDs, return ERROR:DUPLICATE with no changes.
- CANCEL of an unknown ID returns ERROR:UNKNOWN. First cancellation frees every seat in that booking and returns CANCELLED id. Repeating cancellation returns the same text without touching seats, even if a new booking has since occupied them.
- STATUS returns FREE A=n,B=n,C=n counting currently unoccupied seats. Unknown commands or wrong argument counts return ERROR:INPUT. Seat numbers in outputs are one-based; internal indexing may be zero-based. No money or time arithmetic is involved.

## Worked examples

1. **Input:** `BOOK X 5; BOOK Y 4; CANCEL X; BOOK Z 3`
   **Expected:** `BOOKED Z B:5-7`. The four-seat free run in B leaves one seat, while the now-empty eight-seat row A would leave five.

2. **Input:** `BOOK X 2; CANCEL X; BOOK Y 2; CANCEL X; STATUS`
   **Expected:** `FREE A=6,B=8,C=8`. Repeating X’s cancellation must preserve Y’s seats.

## Supplied cases

| Case | Purpose | Expected result |
|---|---|---|
| TC1 | Initial free seats | FREE A=8,B=8,C=8 |
| TC2 | Invalid size and missing booking | ERROR:INPUT ; ERROR:INPUT ; ERROR:UNKNOWN ; FREE A=8,B=8,C=8 |
| TC3 | Exact-size run is eligible | BOOKED X A:1-8 ; FREE A=0,B=8,C=8 |
| TC4 | Equal runs prefer earlier row | BOOKED X A:1-2 |
| TC5 | Best fit beats earlier row | BOOKED X A:1-5 ; BOOKED Y B:1-4 ; CANCELLED X ; BOOKED Z B:5-7 |
| TC6 | Cancellation releases every seat | BOOKED X A:1-3 ; CANCELLED X ; FREE A=8,B=8,C=8 |
| TC7 | Duplicate ID rejects atomically | BOOKED X A:1-2 ; ERROR:DUPLICATE ; FREE A=6,B=8,C=8 |
| TC8 | No capacity rejects without mutation | BOOKED X A:1-8 ; BOOKED Y B:1-8 ; BOOKED Z C:1-8 ; ERROR:FULL ; FREE A=0,B=0,C=0 |
| TC9 | Repeated cancellation cannot free a new booking | BOOKED X A:1-2 ; CANCELLED X ; BOOKED Y A:1-2 ; CANCELLED X ; FREE A=6,B=8,C=8 |

## TC10 — candidate-owned test

Fill row A using bookings X=3, Y=3, Z=2. Cancel Y; book Q=2 and verify it occupies A:4-5. Cancel Y again and verify free counts remain A=1,B=8,C=8. Book R=1 and assert the exact remaining gap A:6-6 is used.


## Candidate deliverables

1. Run the starter and record every initial PASS/FAIL result.
2. Repair business logic without changing the command API or TC1–TC9 assertions. Do not hard-code fixture outputs or disable tests.
3. Implement the described TC10 with independent literal expectations, including state checks where requested.
4. Obtain 10/10 PASS, demonstrate the interactive console, and explain each root cause and regression test.

The supplied runner always executes all cases and exits nonzero when any case fails. A correct implementation with the original TC10 stub must score 9/10; completing TC10 earns 10/10. These are fictional training policies. Work is in-memory, single-threaded, and requires no network, database, package installation or external services.

## Run locally

Choose one language folder. `PROBLEM.md` inside it is a standalone copy of this statement.

- Java (JDK 11+): `javac Main.java TestRunner.java App.java`, then `java TestRunner` or `java App`.
- Python (3.8+): `python3 test_runner.py` or `python3 app.py`.
- JavaScript (Node.js 18+): `node test_runner.js` or `node app.js`.

Console options: 1 runs a fresh demonstration; 2 executes a command against your current session; 3 displays session status; 4 resets your session; 5 exits. Demonstration state does not alter your session.

## Technical discussion

- Why use maximal runs?
- Is best fit guaranteed to maximize future bookings?
- Why retain cancelled booking IDs?
- Why is repeated cancellation a correctness problem?
