"use strict";
class DomainError extends Error {}
function fail(code) {
  throw new DomainError(code);
}
function number(text) {
  if (!/^\d+$/.test(text || "")) fail("INPUT");
  return Number(text);
}
function name(text) {
  if (!/^[A-Z][A-Z0-9_]{0,15}$/.test(text || "")) fail("INPUT");
  return text;
}
class Engine {
  execute(line) {
    try {
      const parts = line.trim().split(/\s+/);
      if (!parts[0]) fail("INPUT");
      return this.run(parts);
    } catch (e) {
      return "ERROR:" + (e instanceof DomainError ? e.message : "INPUT");
    }
  }
  constructor() {
    this.rows = Array.from({ length: 3 }, () => Array(8).fill(false));
    this.bookings = new Map();
  }
  run(p) {
    if (p[0] === "STATUS" && p.length === 1)
      return (
        "FREE " +
        this.rows
          .map(
            (row, r) =>
              String.fromCharCode(65 + r) + "=" + row.filter((x) => !x).length,
          )
          .join(",")
      );
    if (p[0] === "BOOK" && p.length === 3) {
      const booking = name(p[1]),
        count = number(p[2]);
      if (count < 1 || count > 8) fail("INPUT");
      const candidates = [];
      for (let r = 0; r < this.rows.length; r++) {
        const row = this.rows[r];
        let start = 0;
        while (start < 8) {
          if (row[start]) {
            start++;
            continue;
          }
          let end = start;
          while (end < 8 && !row[end]) end++;
          const length = end - start;
          if (length > count) candidates.push([length - count, r, start]);
          start = end;
        }
      }
      if (!candidates.length) fail("FULL");
      candidates.sort((a, b) => b[0] - a[0] || b[1] - a[1] || a[2] - b[2]);
      const [, r, start] = candidates[0];
      for (let seat = start; seat < start + count; seat++)
        this.rows[r][seat] = true;
      this.bookings.set(booking, [r, start, count, true]);
      return (
        "BOOKED " +
        booking +
        " " +
        String.fromCharCode(65 + r) +
        ":" +
        (start + 1) +
        "-" +
        (start + count)
      );
    }
    if (p[0] === "CANCEL" && p.length === 2) {
      const booking = name(p[1]);
      if (!this.bookings.has(booking)) fail("UNKNOWN");
      const entry = this.bookings.get(booking);
      const [r, start, count] = entry;
      for (let seat = start; seat < start + count - 1; seat++)
        this.rows[r][seat] = false;
      entry[3] = false;
      return "CANCELLED " + booking;
    }
    fail("INPUT");
  }
}
module.exports = { Engine };
