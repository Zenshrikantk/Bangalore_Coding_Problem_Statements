"use strict";
const { Engine } = require("./main");
const cases = [
  ["Initial free seats", ["STATUS"], ["FREE A=8,B=8,C=8"]],
  [
    "Invalid size and missing booking",
    ["BOOK X 0", "BOOK X 9", "CANCEL X", "STATUS"],
    ["ERROR:INPUT", "ERROR:INPUT", "ERROR:UNKNOWN", "FREE A=8,B=8,C=8"],
  ],
  [
    "Exact-size run is eligible",
    ["BOOK X 8", "STATUS"],
    ["BOOKED X A:1-8", "FREE A=0,B=8,C=8"],
  ],
  ["Equal runs prefer earlier row", ["BOOK X 2"], ["BOOKED X A:1-2"]],
  [
    "Best fit beats earlier row",
    ["BOOK X 5", "BOOK Y 4", "CANCEL X", "BOOK Z 3"],
    ["BOOKED X A:1-5", "BOOKED Y B:1-4", "CANCELLED X", "BOOKED Z B:5-7"],
  ],
  [
    "Cancellation releases every seat",
    ["BOOK X 3", "CANCEL X", "STATUS"],
    ["BOOKED X A:1-3", "CANCELLED X", "FREE A=8,B=8,C=8"],
  ],
  [
    "Duplicate ID rejects atomically",
    ["BOOK X 2", "BOOK X 1", "STATUS"],
    ["BOOKED X A:1-2", "ERROR:DUPLICATE", "FREE A=6,B=8,C=8"],
  ],
  [
    "No capacity rejects without mutation",
    ["BOOK X 8", "BOOK Y 8", "BOOK Z 8", "BOOK Q 1", "STATUS"],
    [
      "BOOKED X A:1-8",
      "BOOKED Y B:1-8",
      "BOOKED Z C:1-8",
      "ERROR:FULL",
      "FREE A=0,B=0,C=0",
    ],
  ],
  [
    "Repeated cancellation cannot free a new booking",
    ["BOOK X 2", "CANCEL X", "BOOK Y 2", "CANCEL X", "STATUS"],
    [
      "BOOKED X A:1-2",
      "CANCELLED X",
      "BOOKED Y A:1-2",
      "CANCELLED X",
      "FREE A=6,B=8,C=8",
    ],
  ],
];
let passed = 0;
for (let i = 0; i < cases.length; i++) {
  const [title, commands, expected] = cases[i];
  try {
    const engine = new Engine();
    const actual = commands.map((command) => engine.execute(command));
    if (JSON.stringify(actual) !== JSON.stringify(expected))
      throw new Error(
        `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      );
    console.log(`TC${i + 1} PASS: ${title}`);
    passed++;
  } catch (e) {
    console.log(`TC${i + 1} FAIL: ${title} (${e.message})`);
  }
}
// TC10 task: Fill row A using bookings X=3, Y=3, Z=2. Cancel Y; book Q=2 and verify it occupies A:4-5. Cancel Y again and verify free counts remain A=1,B=8,C=8. Book R=1 and assert the exact remaining gap A:6-6 is used.
try {
  throw new Error("Implement TC10 with real assertions");
} catch (e) {
  console.log("TC10 FAIL: " + e.message);
}
console.log(`SUMMARY: ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
