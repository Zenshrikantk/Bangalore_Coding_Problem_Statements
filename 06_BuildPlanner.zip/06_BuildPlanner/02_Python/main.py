class DomainError(Exception):
    pass


def fail(code):
    raise DomainError(code)


def number(text):
    if not text.isascii() or not text.isdigit():
        fail("INPUT")
    return int(text)


def name(text):
    if not (
        1 <= len(text) <= 16
        and text[0].isalpha()
        and text.isascii()
        and all(c.isupper() or c.isdigit() or c == "_" for c in text)
    ):
        fail("INPUT")
    return text


class Engine:
    def execute(self, line):
        parts = line.strip().split()
        try:
            if not parts:
                fail("INPUT")
            return self.run(parts)
        except DomainError as exc:
            return "ERROR:" + str(exc)
        except (ValueError, IndexError):
            return "ERROR:INPUT"

    def __init__(self):
        self.tasks = {}

    def run(self, p):
        if p[0] == "ADD" and len(p) == 3:
            task = name(p[1])
            deps = [] if p[2] == "-" else [name(x) for x in p[2].split(",")]
            if task in self.tasks:
                fail("DUPLICATE")
            self.tasks[task] = [dep for dep in deps if dep != task]
            return "ADDED " + task
        if p[0] == "STATUS" and len(p) == 1:
            return "TASKS " + (",".join(sorted(self.tasks)) or "-")
        if p[0] == "PLAN" and len(p) == 1:
            indegree = {task: len(deps) for task, deps in self.tasks.items()}
            ready = [task for task, degree in indegree.items() if degree == 0]
            result = []
            while ready:
                ready.sort(reverse=True)
                task = ready.pop(0)
                result.append(task)
                for other, deps in self.tasks.items():
                    if task in deps:
                        indegree[other] -= 1
                        if indegree[other] == 0:
                            ready.append(other)
            if len(result) > len(self.tasks):
                fail("CYCLE")
            return "PLAN " + (",".join(result) or "-")
        fail("INPUT")
