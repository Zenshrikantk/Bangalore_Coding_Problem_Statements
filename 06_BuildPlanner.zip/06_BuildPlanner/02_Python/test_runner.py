from main import Engine
import sys

CASES = [
    ("Empty graph", ["STATUS", "PLAN"], ["TASKS -", "PLAN -"]),
    (
        "Linear chain",
        ["ADD C B", "ADD B A", "ADD A -", "PLAN"],
        ["ADDED C", "ADDED B", "ADDED A", "PLAN A,B,C"],
    ),
    (
        "Newly unlocked task joins sorted ready set",
        ["ADD A D", "ADD D -", "ADD Z -", "PLAN"],
        ["ADDED A", "ADDED D", "ADDED Z", "PLAN D,A,Z"],
    ),
    (
        "Duplicate dependency is one edge",
        ["ADD A -", "ADD B A,A", "PLAN"],
        ["ADDED A", "ADDED B", "PLAN A,B"],
    ),
    (
        "Unknown dependency rejected without mutation",
        ["ADD B M", "PLAN", "STATUS"],
        ["ADDED B", "ERROR:UNKNOWN_DEP", "TASKS B"],
    ),
    (
        "Cycle with an independent task",
        ["ADD A B", "ADD B A", "ADD Z -", "PLAN"],
        ["ADDED A", "ADDED B", "ADDED Z", "ERROR:CYCLE"],
    ),
    ("Self-cycle", ["ADD A A", "PLAN"], ["ADDED A", "ERROR:CYCLE"]),
    (
        "Repeated plan preserves graph",
        ["ADD B A", "ADD A -", "PLAN", "PLAN"],
        ["ADDED B", "ADDED A", "PLAN A,B", "PLAN A,B"],
    ),
    (
        "Duplicate task rejects overwrite",
        ["ADD A -", "ADD A Z", "PLAN"],
        ["ADDED A", "ERROR:DUPLICATE", "PLAN A"],
    ),
]

passed = 0
for index, (title, commands, expected) in enumerate(CASES, 1):
    try:
        engine = Engine()
        actual = [engine.execute(command) for command in commands]
        assert actual == expected, "expected %r, got %r" % (expected, actual)
        print("TC%d PASS: %s" % (index, title))
        passed += 1
    except Exception as exc:
        print("TC%d FAIL: %s (%s)" % (index, title, exc))

# TC10 task: Create tasks A depending on D twice, D depending on missing M, and independent Z. First assert UNKNOWN_DEP and unchanged STATUS. Add M; assert the complete deterministic plan M,D,A,Z on two successive calls.
try:
    raise AssertionError("Implement TC10 with real assertions")
except Exception as exc:
    print("TC10 FAIL: %s" % exc)

print("SUMMARY: %d/10 PASS" % passed)
sys.exit(0 if passed == 10 else 1)
