import java.util.*;

public class App {

  public static void main(String[] args) {
    Main engine = new Main();
    String[] demo = { "ADD A D", "ADD D -", "ADD Z -", "PLAN" };
    Scanner scanner = new Scanner(System.in);
    while (true) {
      System.out.println(
        "1 Demo | 2 Enter command | 3 Status | 4 Reset | 5 Exit"
      );
      if (!scanner.hasNextLine()) break;
      String choice = scanner.nextLine().trim();
      if (choice.equals("1")) {
        Main sample = new Main();
        for (String command : demo)
          System.out.println(command + " => " + sample.execute(command));
      } else if (choice.equals("2")) {
        System.out.println("Command:");
        if (!scanner.hasNextLine()) break;
        System.out.println(engine.execute(scanner.nextLine()));
      } else if (choice.equals("3")) System.out.println(
        engine.execute("STATUS")
      );
      else if (choice.equals("4")) {
        engine = new Main();
        System.out.println("RESET");
      } else if (choice.equals("5")) break;
      else System.out.println(
        "Choose 1 through 5. Read PROBLEM.md for commands."
      );
    }
  }
}
