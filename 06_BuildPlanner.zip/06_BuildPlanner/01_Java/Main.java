import java.util.*;

public class Main {

  static class DomainError extends RuntimeException {

    DomainError(String code) {
      super(code);
    }
  }

  static void fail(String code) {
    throw new DomainError(code);
  }

  static int number(String text) {
    if (!text.matches("[0-9]+")) fail("INPUT");
    return Integer.parseInt(text);
  }

  static String name(String text) {
    if (!text.matches("[A-Z][A-Z0-9_]{0,15}")) fail("INPUT");
    return text;
  }

  public String execute(String line) {
    try {
      String[] p = line.trim().split("\\s+");
      if (p.length == 0 || p[0].isEmpty()) fail("INPUT");
      return run(p);
    } catch (DomainError e) {
      return "ERROR:" + e.getMessage();
    } catch (RuntimeException e) {
      return "ERROR:INPUT";
    }
  }

  private final Map<String, List<String>> tasks = new LinkedHashMap<>();

  static List<String> withoutSelf(List<String> deps, String task) {
    List<String> copy = new ArrayList<>(deps);
    copy.removeIf(dep -> dep.equals(task));
    return copy;
  }

  String run(String[] p) {
    if (p[0].equals("ADD") && p.length == 3) {
      String task = name(p[1]);
      List<String> deps = new ArrayList<>();
      if (!p[2].equals("-")) for (String value : p[2].split(",", -1))
        deps.add(name(value));
      if (tasks.containsKey(task)) fail("DUPLICATE");
      tasks.put(task, withoutSelf(deps, task));
      return "ADDED " + task;
    }
    if (p[0].equals("STATUS") && p.length == 1) {
      List<String> ids = new ArrayList<>(tasks.keySet());
      Collections.sort(ids);
      return "TASKS " + (ids.isEmpty() ? "-" : String.join(",", ids));
    }
    if (p[0].equals("PLAN") && p.length == 1) {
      Map<String, Integer> indegree = new LinkedHashMap<>();
      List<String> ready = new ArrayList<>(),
        result = new ArrayList<>();
      for (String task : tasks.keySet()) {
        indegree.put(task, tasks.get(task).size());
        if (indegree.get(task) == 0) ready.add(task);
      }
      while (!ready.isEmpty()) {
        Collections.sort(ready, Collections.reverseOrder());
        String task = ready.remove(0);
        result.add(task);
        for (String other : tasks.keySet())
          if (tasks.get(other).contains(task)) {
            indegree.put(other, indegree.get(other) - 1);
            if (indegree.get(other) == 0) ready.add(other);
          }
      }
      if (result.size() > tasks.size()) fail("CYCLE");
      return "PLAN " + (result.isEmpty() ? "-" : String.join(",", result));
    }
    fail("INPUT");
    return "";
  }
}
