# 06 · Dependency Build Planner Debugging Challenge

Track: Algorithm | Difficulty: Intermediate | Suggested time: 90–120 minutes

A campus build service must order software tasks only after their prerequisites, while producing the same plan every time.

Repair the deliberately defective starter, prove the behavior with tests, and explain the algorithm. The rules below are authoritative.

## Contract and commands

- Entity: a task ID maps to its dependency IDs. API: Engine.execute(command) in Python/JavaScript; Main.execute(command) in Java. ADD id deps declares a task; deps is a comma-separated list or - for none. IDs match [A-Z][A-Z0-9_]{0,15}. At most 100 distinct tasks and 100 dependencies per ADD are supplied.
- ADD validates the ID and every dependency, then rejects an existing task ID with ERROR:DUPLICATE. The graph is unchanged on rejection. Repeated dependency IDs represent one edge. Forward references and self-dependencies are accepted at declaration time.
- PLAN first rejects any undeclared dependency with ERROR:UNKNOWN_DEP. Otherwise repeatedly emit the lexicographically smallest currently ready task, including tasks unlocked during the loop. Each task appears exactly once and after all dependencies.
- If not all tasks can be emitted, PLAN returns ERROR:CYCLE, including self-cycles. Do not return a partial plan. PLAN never changes stored tasks. Output is PLAN followed by comma-separated IDs, or PLAN - for an empty graph.
- STATUS returns TASKS followed by all declared IDs in ascending order, or TASKS -. ADD success returns ADDED id. Unknown commands or malformed arguments return ERROR:INPUT. Units are task counts; there are no times or money values.

## Worked examples

1. **Input:** `ADD A D; ADD D -; ADD Z -; PLAN`
   **Expected:** `PLAN D,A,Z`. D unlocks A, which must run before already-ready Z.

2. **Input:** `ADD X Y; ADD Y X; PLAN`
   **Expected:** `ERROR:CYCLE`. Neither task can become ready.

## Supplied cases

| Case | Purpose | Expected result |
|---|---|---|
| TC1 | Empty graph | TASKS - ; PLAN - |
| TC2 | Linear chain | ADDED C ; ADDED B ; ADDED A ; PLAN A,B,C |
| TC3 | Newly unlocked task joins sorted ready set | ADDED A ; ADDED D ; ADDED Z ; PLAN D,A,Z |
| TC4 | Duplicate dependency is one edge | ADDED A ; ADDED B ; PLAN A,B |
| TC5 | Unknown dependency rejected without mutation | ADDED B ; ERROR:UNKNOWN_DEP ; TASKS B |
| TC6 | Cycle with an independent task | ADDED A ; ADDED B ; ADDED Z ; ERROR:CYCLE |
| TC7 | Self-cycle | ADDED A ; ERROR:CYCLE |
| TC8 | Repeated plan preserves graph | ADDED B ; ADDED A ; PLAN A,B ; PLAN A,B |
| TC9 | Duplicate task rejects overwrite | ADDED A ; ERROR:DUPLICATE ; PLAN A |

## TC10 — candidate-owned test

Create tasks A depending on D twice, D depending on missing M, and independent Z. First assert UNKNOWN_DEP and unchanged STATUS. Add M; assert the complete deterministic plan M,D,A,Z on two successive calls.


## Candidate deliverables

1. Run the starter and record every initial PASS/FAIL result.
2. Repair business logic without changing the command API or TC1–TC9 assertions. Do not hard-code fixture outputs or disable tests.
3. Implement the described TC10 with independent literal expectations, including state checks where requested.
4. Obtain 10/10 PASS, demonstrate the interactive console, and explain each root cause and regression test.

The supplied runner always executes all cases and exits nonzero when any case fails. A correct implementation with the original TC10 stub must score 9/10; completing TC10 earns 10/10. These are fictional training policies. Work is in-memory, single-threaded, and requires no network, database, package installation or external services.

## Run locally

Choose one language folder. `PROBLEM.md` inside it is a standalone copy of this statement.

- Java (JDK 11+): `javac Main.java TestRunner.java App.java`, then `java TestRunner` or `java App`.
- Python (3.8+): `python3 test_runner.py` or `python3 app.py`.
- JavaScript (Node.js 18+): `node test_runner.js` or `node app.js`.

Console options: 1 runs a fresh demonstration; 2 executes a command against your current session; 3 displays session status; 4 resets your session; 5 exits. Demonstration state does not alter your session.

## Technical discussion

- Why must the ready set be sorted repeatedly?
- Why does duplicate-edge handling affect indegree?
- How can a cycle exist even when some tasks run?
- Why must planning use fresh indegrees?
