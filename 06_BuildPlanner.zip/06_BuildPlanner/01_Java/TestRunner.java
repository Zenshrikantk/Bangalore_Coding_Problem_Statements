import java.util.*;

public class TestRunner {

  static int passed = 0;

  static void check(
    int number,
    String title,
    String[] commands,
    String[] expected
  ) {
    try {
      Main engine = new Main();
      List<String> actual = new ArrayList<>();
      for (String command : commands) actual.add(engine.execute(command));
      if (!actual.equals(Arrays.asList(expected))) throw new AssertionError(
        "expected " + Arrays.toString(expected) + ", got " + actual
      );
      System.out.println("TC" + number + " PASS: " + title);
      passed++;
    } catch (Throwable e) {
      System.out.println(
        "TC" + number + " FAIL: " + title + " (" + e.getMessage() + ")"
      );
    }
  }

  public static void main(String[] args) {
    check(
      1,
      "Empty graph",
      new String[] { "STATUS", "PLAN" },
      new String[] { "TASKS -", "PLAN -" }
    );
    check(
      2,
      "Linear chain",
      new String[] { "ADD C B", "ADD B A", "ADD A -", "PLAN" },
      new String[] { "ADDED C", "ADDED B", "ADDED A", "PLAN A,B,C" }
    );
    check(
      3,
      "Newly unlocked task joins sorted ready set",
      new String[] { "ADD A D", "ADD D -", "ADD Z -", "PLAN" },
      new String[] { "ADDED A", "ADDED D", "ADDED Z", "PLAN D,A,Z" }
    );
    check(
      4,
      "Duplicate dependency is one edge",
      new String[] { "ADD A -", "ADD B A,A", "PLAN" },
      new String[] { "ADDED A", "ADDED B", "PLAN A,B" }
    );
    check(
      5,
      "Unknown dependency rejected without mutation",
      new String[] { "ADD B M", "PLAN", "STATUS" },
      new String[] { "ADDED B", "ERROR:UNKNOWN_DEP", "TASKS B" }
    );
    check(
      6,
      "Cycle with an independent task",
      new String[] { "ADD A B", "ADD B A", "ADD Z -", "PLAN" },
      new String[] { "ADDED A", "ADDED B", "ADDED Z", "ERROR:CYCLE" }
    );
    check(
      7,
      "Self-cycle",
      new String[] { "ADD A A", "PLAN" },
      new String[] { "ADDED A", "ERROR:CYCLE" }
    );
    check(
      8,
      "Repeated plan preserves graph",
      new String[] { "ADD B A", "ADD A -", "PLAN", "PLAN" },
      new String[] { "ADDED B", "ADDED A", "PLAN A,B", "PLAN A,B" }
    );
    check(
      9,
      "Duplicate task rejects overwrite",
      new String[] { "ADD A -", "ADD A Z", "PLAN" },
      new String[] { "ADDED A", "ERROR:DUPLICATE", "PLAN A" }
    );
    // TC10 task: Create tasks A depending on D twice, D depending on missing M, and independent Z. First assert UNKNOWN_DEP and unchanged STATUS. Add M; assert the complete deterministic plan M,D,A,Z on two successive calls.
    try {
      throw new AssertionError("Implement TC10 with real assertions");
    } catch (AssertionError e) {
      System.out.println("TC10 FAIL: " + e.getMessage());
    }
    System.out.println("SUMMARY: " + passed + "/10 PASS");
    System.exit(passed == 10 ? 0 : 1);
  }
}
