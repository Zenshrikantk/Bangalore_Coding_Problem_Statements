"use strict";
class DomainError extends Error {}
function fail(code) {
  throw new DomainError(code);
}
function number(text) {
  if (!/^\d+$/.test(text || "")) fail("INPUT");
  return Number(text);
}
function name(text) {
  if (!/^[A-Z][A-Z0-9_]{0,15}$/.test(text || "")) fail("INPUT");
  return text;
}
class Engine {
  execute(line) {
    try {
      const parts = line.trim().split(/\s+/);
      if (!parts[0]) fail("INPUT");
      return this.run(parts);
    } catch (e) {
      return "ERROR:" + (e instanceof DomainError ? e.message : "INPUT");
    }
  }
  constructor() {
    this.tasks = new Map();
  }
  run(p) {
    if (p[0] === "ADD" && p.length === 3) {
      const task = name(p[1]);
      const deps = p[2] === "-" ? [] : p[2].split(",").map(name);
      if (this.tasks.has(task)) fail("DUPLICATE");
      this.tasks.set(
        task,
        deps.filter((dep) => dep !== task),
      );
      return "ADDED " + task;
    }
    if (p[0] === "STATUS" && p.length === 1)
      return "TASKS " + ([...this.tasks.keys()].sort().join(",") || "-");
    if (p[0] === "PLAN" && p.length === 1) {
      const indegree = new Map(
        [...this.tasks].map(([task, deps]) => [task, deps.length]),
      );
      const ready = [...indegree]
        .filter(([, degree]) => degree === 0)
        .map(([task]) => task);
      const result = [];
      while (ready.length) {
        ready.sort().reverse();
        const task = ready.shift();
        result.push(task);
        for (const [other, deps] of this.tasks) {
          if (deps.includes(task)) {
            indegree.set(other, indegree.get(other) - 1);
            if (indegree.get(other) === 0) ready.push(other);
          }
        }
      }
      if (result.length > this.tasks.size) fail("CYCLE");
      return "PLAN " + (result.join(",") || "-");
    }
    fail("INPUT");
  }
}
module.exports = { Engine };
