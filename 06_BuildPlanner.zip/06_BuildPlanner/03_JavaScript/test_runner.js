"use strict";
const { Engine } = require("./main");
const cases = [
  ["Empty graph", ["STATUS", "PLAN"], ["TASKS -", "PLAN -"]],
  [
    "Linear chain",
    ["ADD C B", "ADD B A", "ADD A -", "PLAN"],
    ["ADDED C", "ADDED B", "ADDED A", "PLAN A,B,C"],
  ],
  [
    "Newly unlocked task joins sorted ready set",
    ["ADD A D", "ADD D -", "ADD Z -", "PLAN"],
    ["ADDED A", "ADDED D", "ADDED Z", "PLAN D,A,Z"],
  ],
  [
    "Duplicate dependency is one edge",
    ["ADD A -", "ADD B A,A", "PLAN"],
    ["ADDED A", "ADDED B", "PLAN A,B"],
  ],
  [
    "Unknown dependency rejected without mutation",
    ["ADD B M", "PLAN", "STATUS"],
    ["ADDED B", "ERROR:UNKNOWN_DEP", "TASKS B"],
  ],
  [
    "Cycle with an independent task",
    ["ADD A B", "ADD B A", "ADD Z -", "PLAN"],
    ["ADDED A", "ADDED B", "ADDED Z", "ERROR:CYCLE"],
  ],
  ["Self-cycle", ["ADD A A", "PLAN"], ["ADDED A", "ERROR:CYCLE"]],
  [
    "Repeated plan preserves graph",
    ["ADD B A", "ADD A -", "PLAN", "PLAN"],
    ["ADDED B", "ADDED A", "PLAN A,B", "PLAN A,B"],
  ],
  [
    "Duplicate task rejects overwrite",
    ["ADD A -", "ADD A Z", "PLAN"],
    ["ADDED A", "ERROR:DUPLICATE", "PLAN A"],
  ],
];
let passed = 0;
for (let i = 0; i < cases.length; i++) {
  const [title, commands, expected] = cases[i];
  try {
    const engine = new Engine();
    const actual = commands.map((command) => engine.execute(command));
    if (JSON.stringify(actual) !== JSON.stringify(expected))
      throw new Error(
        `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      );
    console.log(`TC${i + 1} PASS: ${title}`);
    passed++;
  } catch (e) {
    console.log(`TC${i + 1} FAIL: ${title} (${e.message})`);
  }
}
// TC10 task: Create tasks A depending on D twice, D depending on missing M, and independent Z. First assert UNKNOWN_DEP and unchanged STATUS. Add M; assert the complete deterministic plan M,D,A,Z on two successive calls.
try {
  throw new Error("Implement TC10 with real assertions");
} catch (e) {
  console.log("TC10 FAIL: " + e.message);
}
console.log(`SUMMARY: ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
