class DomainError(Exception):
    pass


def fail(code):
    raise DomainError(code)


def number(text):
    if not text.isascii() or not text.isdigit():
        fail("INPUT")
    return int(text)


def name(text):
    if not (
        1 <= len(text) <= 16
        and text[0].isalpha()
        and text.isascii()
        and all(c.isupper() or c.isdigit() or c == "_" for c in text)
    ):
        fail("INPUT")
    return text


class Engine:
    def execute(self, line):
        parts = line.strip().split()
        try:
            if not parts:
                fail("INPUT")
            return self.run(parts)
        except DomainError as exc:
            return "ERROR:" + str(exc)
        except (ValueError, IndexError):
            return "ERROR:INPUT"

    def __init__(self):
        self.streams = {}

    def run(self, p):
        if p[0] == "STATUS" and len(p) == 1:
            return "SENSORS " + (",".join(sorted(self.streams)) or "-")
        if p[0] == "ADD" and len(p) == 4:
            sensor, time, value = name(p[1]), number(p[2]), number(p[3])
            if time > 1000000 or value > 1000:
                fail("INPUT")
            stream = self.streams.get(sensor, [])
            for row in stream:
                if row[0] == time:
                    if row[1] != value:
                        row[1] = value
                        return "ADDED " + sensor + "/" + str(time)
            stream.append([time, value])
            self.streams[sensor] = stream
            return "ADDED " + sensor + "/" + str(time)
        if p[0] == "MERGE" and len(p) == 1:
            positions = {sensor: 0 for sensor in self.streams}
            result = []
            while True:
                best = None
                for sensor, rows in self.streams.items():
                    index = positions[sensor]
                    if index < len(rows):
                        candidate = (rows[index][0], sensor, rows[index][1])
                        if (
                            best is None
                            or candidate[0] > best[0]
                            or (candidate[0] == best[0] and candidate[1] > best[1])
                        ):
                            best = candidate
                if best is None:
                    break
                time, sensor, value = best
                result.append(str(time) + "/" + sensor + "/" + str(value))
                positions[sensor] += 1
            return "MERGED " + (";".join(result) or "-")
        fail("INPUT")
