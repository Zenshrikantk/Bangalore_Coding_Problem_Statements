from main import Engine
import sys

CASES = [
    ("No readings", ["STATUS", "MERGE"], ["SENSORS -", "MERGED -"]),
    (
        "One ordered stream",
        ["ADD A 2 7", "ADD A 5 9", "MERGE"],
        ["ADDED A/2", "ADDED A/5", "MERGED 2/A/7;5/A/9"],
    ),
    (
        "Interleaved timestamps",
        ["ADD A 2 7", "ADD A 8 9", "ADD B 4 3", "MERGE"],
        ["ADDED A/2", "ADDED A/8", "ADDED B/4", "MERGED 2/A/7;4/B/3;8/A/9"],
    ),
    (
        "Timestamp ties use ascending sensor ID",
        ["ADD Z 3 5", "ADD A 3 6", "MERGE"],
        ["ADDED Z/3", "ADDED A/3", "MERGED 3/A/6;3/Z/5"],
    ),
    (
        "Identical duplicate is idempotent",
        ["ADD A 3 6", "ADD A 3 6", "MERGE"],
        ["ADDED A/3", "SEEN A/3", "MERGED 3/A/6"],
    ),
    (
        "Conflicting duplicate leaves old value",
        ["ADD A 3 6", "ADD A 3 9", "MERGE"],
        ["ADDED A/3", "ERROR:CONFLICT", "MERGED 3/A/6"],
    ),
    (
        "Older new reading rejected",
        ["ADD A 5 6", "ADD A 2 9", "MERGE"],
        ["ADDED A/5", "ERROR:ORDER", "MERGED 5/A/6"],
    ),
    (
        "Merge is repeatable",
        ["ADD A 0 1", "MERGE", "MERGE", "STATUS"],
        ["ADDED A/0", "MERGED 0/A/1", "MERGED 0/A/1", "SENSORS A"],
    ),
    (
        "Invalid values create no sensor",
        ["ADD A 1 1001", "STATUS"],
        ["ERROR:INPUT", "SENSORS -"],
    ),
]

passed = 0
for index, (title, commands, expected) in enumerate(CASES, 1):
    try:
        engine = Engine()
        actual = [engine.execute(command) for command in commands]
        assert actual == expected, "expected %r, got %r" % (expected, actual)
        print("TC%d PASS: %s" % (index, title))
        passed += 1
    except Exception as exc:
        print("TC%d FAIL: %s (%s)" % (index, title, exc))

# TC10 task: Add A at times 2 and 5, and B at time 2. Repeat the older A/time-2 reading identically, then attempt a conflicting A/time-2 value. Assert duplicate detection precedes ordering checks, the conflict changes no data, ties place A before B, and two MERGE calls match.
try:
    raise AssertionError("Implement TC10 with real assertions")
except Exception as exc:
    print("TC10 FAIL: %s" % exc)

print("SUMMARY: %d/10 PASS" % passed)
sys.exit(0 if passed == 10 else 1)
