from main import Engine


def main():
    engine = Engine()
    while True:
        print("1 Demo | 2 Enter command | 3 Status | 4 Reset | 5 Exit")
        try:
            option = input("> ").strip()
        except EOFError:
            break
        if option == "1":
            sample = Engine()
            for command in DEMO:
                print(command, "=>", sample.execute(command))
        elif option == "2":
            try:
                print(engine.execute(input("Command: ")))
            except EOFError:
                break
        elif option == "3":
            print(engine.execute("STATUS"))
        elif option == "4":
            engine = Engine()
            print("RESET")
        elif option == "5":
            break
        else:
            print("Choose 1 through 5. Read PROBLEM.md for commands.")


DEMO = ["ADD A 2 7", "ADD B 2 9", "ADD A 5 8", "MERGE"]
if __name__ == "__main__":
    main()
