"use strict";
class DomainError extends Error {}
function fail(code) {
  throw new DomainError(code);
}
function number(text) {
  if (!/^\d+$/.test(text || "")) fail("INPUT");
  return Number(text);
}
function name(text) {
  if (!/^[A-Z][A-Z0-9_]{0,15}$/.test(text || "")) fail("INPUT");
  return text;
}
class Engine {
  execute(line) {
    try {
      const parts = line.trim().split(/\s+/);
      if (!parts[0]) fail("INPUT");
      return this.run(parts);
    } catch (e) {
      return "ERROR:" + (e instanceof DomainError ? e.message : "INPUT");
    }
  }
  constructor() {
    this.streams = new Map();
  }
  run(p) {
    if (p[0] === "STATUS" && p.length === 1)
      return "SENSORS " + ([...this.streams.keys()].sort().join(",") || "-");
    if (p[0] === "ADD" && p.length === 4) {
      const sensor = name(p[1]),
        time = number(p[2]),
        value = number(p[3]);
      if (time > 1000000 || value > 1000) fail("INPUT");
      const stream = this.streams.get(sensor) || [];
      for (const row of stream)
        if (row[0] === time) {
          if (row[1] !== value) {
            row[1] = value;
            return "ADDED " + sensor + "/" + time;
          }
        }
      stream.push([time, value]);
      this.streams.set(sensor, stream);
      return "ADDED " + sensor + "/" + time;
    }
    if (p[0] === "MERGE" && p.length === 1) {
      const positions = new Map(
        [...this.streams.keys()].map((sensor) => [sensor, 0]),
      );
      const result = [];
      while (true) {
        let best = null;
        for (const [sensor, rows] of this.streams) {
          const index = positions.get(sensor);
          if (index < rows.length) {
            const candidate = [rows[index][0], sensor, rows[index][1]];
            if (
              best === null ||
              candidate[0] > best[0] ||
              (candidate[0] === best[0] && candidate[1] > best[1])
            )
              best = candidate;
          }
        }
        if (best === null) break;
        const [time, sensor, value] = best;
        result.push(time + "/" + sensor + "/" + value);
        positions.set(sensor, positions.get(sensor) + 1);
      }
      return "MERGED " + (result.join(";") || "-");
    }
    fail("INPUT");
  }
}
module.exports = { Engine };
