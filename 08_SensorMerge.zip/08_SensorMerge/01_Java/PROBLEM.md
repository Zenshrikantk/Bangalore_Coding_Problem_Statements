# 08 · Sensor Stream Merger Debugging Challenge

Track: Algorithm | Difficulty: Intermediate | Suggested time: 90–120 minutes

An engineering lab receives individually ordered sensor streams and needs one reproducible timeline without duplicate or overwritten readings.

Repair the deliberately defective starter, prove the behavior with tests, and explain the algorithm. The rules below are authoritative.

## Contract and commands

- Entities: sensor ID, reading(timestamp,value), and an ordered stream per sensor. API: execute(command) on Engine (Python/JavaScript) or Main (Java). ADD sensor timestamp value records a reading; MERGE creates a timeline; STATUS lists sensor IDs.
- IDs match [A-Z][A-Z0-9_]{0,15}. Timestamps are integer ticks 0..1,000,000 and values are integers 0..1,000. Inputs contain at most 20 sensors and 1,000 distinct readings. Malformed values return ERROR:INPUT before mutation.
- A reading is uniquely identified by (sensor,timestamp). After syntax/range validation, check that identity across the whole stream. An identical repeated value returns SEEN sensor/timestamp without inserting another reading, even when later readings already exist. A different value returns ERROR:CONFLICT without overwriting the original.
- For a new identity, its timestamp must be greater than the last timestamp for that sensor. An older timestamp returns ERROR:ORDER with no state change. ADD success returns ADDED sensor/timestamp. Different sensors can share timestamps.
- MERGE selects the smallest current head from all streams, advancing only the selected stream. Output order is timestamp ascending, then sensor ID ascending. Format is MERGED timestamp/sensor/value;timestamp/sensor/value. Empty output is MERGED -. Reads never consume or reorder stored input.
- STATUS returns SENSORS followed by ascending IDs, or SENSORS -. Unknown commands or wrong argument counts return ERROR:INPUT. Values are abstract measurement units, not money.

## Worked examples

1. **Input:** `ADD A 2 7; ADD A 8 9; ADD B 4 3; MERGE`
   **Expected:** `MERGED 2/A/7;4/B/3;8/A/9`. The merger compares stream heads and advances just one stream per result.

2. **Input:** `ADD B 3 5; ADD A 3 6; ADD A 3 6; MERGE`
   **Expected:** `MERGED 3/A/6;3/B/5`. Same-timestamp readings from different sensors remain distinct, while an identical repeat is ignored.

## Supplied cases

| Case | Purpose | Expected result |
|---|---|---|
| TC1 | No readings | SENSORS - ; MERGED - |
| TC2 | One ordered stream | ADDED A/2 ; ADDED A/5 ; MERGED 2/A/7;5/A/9 |
| TC3 | Interleaved timestamps | ADDED A/2 ; ADDED A/8 ; ADDED B/4 ; MERGED 2/A/7;4/B/3;8/A/9 |
| TC4 | Timestamp ties use ascending sensor ID | ADDED Z/3 ; ADDED A/3 ; MERGED 3/A/6;3/Z/5 |
| TC5 | Identical duplicate is idempotent | ADDED A/3 ; SEEN A/3 ; MERGED 3/A/6 |
| TC6 | Conflicting duplicate leaves old value | ADDED A/3 ; ERROR:CONFLICT ; MERGED 3/A/6 |
| TC7 | Older new reading rejected | ADDED A/5 ; ERROR:ORDER ; MERGED 5/A/6 |
| TC8 | Merge is repeatable | ADDED A/0 ; MERGED 0/A/1 ; MERGED 0/A/1 ; SENSORS A |
| TC9 | Invalid values create no sensor | ERROR:INPUT ; SENSORS - |

## TC10 — candidate-owned test

Add A at times 2 and 5, and B at time 2. Repeat the older A/time-2 reading identically, then attempt a conflicting A/time-2 value. Assert duplicate detection precedes ordering checks, the conflict changes no data, ties place A before B, and two MERGE calls match.


## Candidate deliverables

1. Run the starter and record every initial PASS/FAIL result.
2. Repair business logic without changing the command API or TC1–TC9 assertions. Do not hard-code fixture outputs or disable tests.
3. Implement the described TC10 with independent literal expectations, including state checks where requested.
4. Obtain 10/10 PASS, demonstrate the interactive console, and explain each root cause and regression test.

The supplied runner always executes all cases and exits nonzero when any case fails. A correct implementation with the original TC10 stub must score 9/10; completing TC10 earns 10/10. These are fictional training policies. Work is in-memory, single-threaded, and requires no network, database, package installation or external services.

## Run locally

Choose one language folder. `PROBLEM.md` inside it is a standalone copy of this statement.

- Java (JDK 11+): `javac Main.java TestRunner.java App.java`, then `java TestRunner` or `java App`.
- Python (3.8+): `python3 test_runner.py` or `python3 app.py`.
- JavaScript (Node.js 18+): `node test_runner.js` or `node app.js`.

Console options: 1 runs a fresh demonstration; 2 executes a command against your current session; 3 displays session status; 4 resets your session; 5 exits. Demonstration state does not alter your session.

## Technical discussion

- Why does head-only merging work?
- Why not deduplicate only by timestamp?
- Why must duplicate handling precede the order check?
- What changes for an unbounded stream?
