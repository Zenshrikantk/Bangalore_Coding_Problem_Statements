import java.util.*;

public class TestRunner {

  static int passed = 0;

  static void check(
    int number,
    String title,
    String[] commands,
    String[] expected
  ) {
    try {
      Main engine = new Main();
      List<String> actual = new ArrayList<>();
      for (String command : commands) actual.add(engine.execute(command));
      if (!actual.equals(Arrays.asList(expected))) throw new AssertionError(
        "expected " + Arrays.toString(expected) + ", got " + actual
      );
      System.out.println("TC" + number + " PASS: " + title);
      passed++;
    } catch (Throwable e) {
      System.out.println(
        "TC" + number + " FAIL: " + title + " (" + e.getMessage() + ")"
      );
    }
  }

  public static void main(String[] args) {
    check(
      1,
      "No readings",
      new String[] { "STATUS", "MERGE" },
      new String[] { "SENSORS -", "MERGED -" }
    );
    check(
      2,
      "One ordered stream",
      new String[] { "ADD A 2 7", "ADD A 5 9", "MERGE" },
      new String[] { "ADDED A/2", "ADDED A/5", "MERGED 2/A/7;5/A/9" }
    );
    check(
      3,
      "Interleaved timestamps",
      new String[] { "ADD A 2 7", "ADD A 8 9", "ADD B 4 3", "MERGE" },
      new String[] {
        "ADDED A/2",
        "ADDED A/8",
        "ADDED B/4",
        "MERGED 2/A/7;4/B/3;8/A/9",
      }
    );
    check(
      4,
      "Timestamp ties use ascending sensor ID",
      new String[] { "ADD Z 3 5", "ADD A 3 6", "MERGE" },
      new String[] { "ADDED Z/3", "ADDED A/3", "MERGED 3/A/6;3/Z/5" }
    );
    check(
      5,
      "Identical duplicate is idempotent",
      new String[] { "ADD A 3 6", "ADD A 3 6", "MERGE" },
      new String[] { "ADDED A/3", "SEEN A/3", "MERGED 3/A/6" }
    );
    check(
      6,
      "Conflicting duplicate leaves old value",
      new String[] { "ADD A 3 6", "ADD A 3 9", "MERGE" },
      new String[] { "ADDED A/3", "ERROR:CONFLICT", "MERGED 3/A/6" }
    );
    check(
      7,
      "Older new reading rejected",
      new String[] { "ADD A 5 6", "ADD A 2 9", "MERGE" },
      new String[] { "ADDED A/5", "ERROR:ORDER", "MERGED 5/A/6" }
    );
    check(
      8,
      "Merge is repeatable",
      new String[] { "ADD A 0 1", "MERGE", "MERGE", "STATUS" },
      new String[] { "ADDED A/0", "MERGED 0/A/1", "MERGED 0/A/1", "SENSORS A" }
    );
    check(
      9,
      "Invalid values create no sensor",
      new String[] { "ADD A 1 1001", "STATUS" },
      new String[] { "ERROR:INPUT", "SENSORS -" }
    );
    // TC10 task: Add A at times 2 and 5, and B at time 2. Repeat the older A/time-2 reading identically, then attempt a conflicting A/time-2 value. Assert duplicate detection precedes ordering checks, the conflict changes no data, ties place A before B, and two MERGE calls match.
    try {
      throw new AssertionError("Implement TC10 with real assertions");
    } catch (AssertionError e) {
      System.out.println("TC10 FAIL: " + e.getMessage());
    }
    System.out.println("SUMMARY: " + passed + "/10 PASS");
    System.exit(passed == 10 ? 0 : 1);
  }
}
