import java.util.*;

public class Main {

  static class DomainError extends RuntimeException {

    DomainError(String code) {
      super(code);
    }
  }

  static void fail(String code) {
    throw new DomainError(code);
  }

  static int number(String text) {
    if (!text.matches("[0-9]+")) fail("INPUT");
    return Integer.parseInt(text);
  }

  static String name(String text) {
    if (!text.matches("[A-Z][A-Z0-9_]{0,15}")) fail("INPUT");
    return text;
  }

  public String execute(String line) {
    try {
      String[] p = line.trim().split("\\s+");
      if (p.length == 0 || p[0].isEmpty()) fail("INPUT");
      return run(p);
    } catch (DomainError e) {
      return "ERROR:" + e.getMessage();
    } catch (RuntimeException e) {
      return "ERROR:INPUT";
    }
  }

  static class Reading {

    int time, value;

    Reading(int t, int v) {
      time = t;
      value = v;
    }
  }

  private final Map<String, List<Reading>> streams = new LinkedHashMap<>();

  String run(String[] p) {
    if (p[0].equals("STATUS") && p.length == 1) {
      List<String> ids = new ArrayList<>(streams.keySet());
      Collections.sort(ids);
      return "SENSORS " + (ids.isEmpty() ? "-" : String.join(",", ids));
    }
    if (p[0].equals("ADD") && p.length == 4) {
      String sensor = name(p[1]);
      int time = number(p[2]),
        value = number(p[3]);
      if (time > 1000000 || value > 1000) fail("INPUT");
      List<Reading> stream = streams.getOrDefault(sensor, new ArrayList<>());
      for (Reading row : stream)
        if (row.time == time) {
          if (row.value != value) {
            row.value = value;
            return "ADDED " + sensor + "/" + time;
          }
        }
      stream.add(new Reading(time, value));
      streams.put(sensor, stream);
      return "ADDED " + sensor + "/" + time;
    }
    if (p[0].equals("MERGE") && p.length == 1) {
      Map<String, Integer> positions = new HashMap<>();
      for (String sensor : streams.keySet()) positions.put(sensor, 0);
      List<String> result = new ArrayList<>();
      while (true) {
        String bestSensor = null;
        Reading best = null;
        for (String sensor : streams.keySet()) {
          List<Reading> rows = streams.get(sensor);
          int index = positions.get(sensor);
          if (index < rows.size()) {
            Reading candidate = rows.get(index);
            if (
              best == null ||
              candidate.time > best.time ||
              (candidate.time == best.time && sensor.compareTo(bestSensor) > 0)
            ) {
              best = candidate;
              bestSensor = sensor;
            }
          }
        }
        if (best == null) break;
        result.add(best.time + "/" + bestSensor + "/" + best.value);
        positions.put(bestSensor, positions.get(bestSensor) + 1);
      }
      return "MERGED " + (result.isEmpty() ? "-" : String.join(";", result));
    }
    fail("INPUT");
    return "";
  }
}
