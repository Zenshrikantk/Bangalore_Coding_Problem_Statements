const {
  Parcel,
  StandardParcel,
  ExpressParcel,
  FragileParcel,
  Dispatch,
} = require("./main");
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const lines = [];
let waiter = null,
  ended = false;
rl.on("line", (line) => {
  if (waiter) {
    const w = waiter;
    waiter = null;
    w(line);
  } else lines.push(line);
});
rl.on("close", () => {
  ended = true;
  if (waiter) {
    waiter(null);
    waiter = null;
  }
});
async function ask(prompt) {
  process.stdout.write(prompt);
  if (lines.length) return lines.shift();
  if (ended) return null;
  return await new Promise((r) => (waiter = r));
}
function number(s) {
  if (s === null || s.trim() === "" || !Number.isInteger(Number(s)))
    throw new Error("integer required");
  return Number(s);
}
function make() {
  return new Dispatch();
}
(async () => {
  let state = make();
  try {
    while (true) {
      console.log("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit");
      const choice = await ask("> ");
      if (choice === null || choice === "5") break;
      try {
        if (choice === "1") {
          console.log(
            "Demo quote:",
            new ExpressParcel("DEMO", 501, true).quote(),
          );
        } else if (choice === "2") {
          const id = await ask("Parcel ID: "),
            kind = ((await ask("Type S/E/F: ")) || "").toUpperCase(),
            g = number(await ask("Weight grams: ")),
            r = (await ask("Remote y/n: ")) === "y";
          let p;
          if (kind === "S") p = new StandardParcel(id, g, r);
          else if (kind === "E") p = new ExpressParcel(id, g, r);
          else if (kind === "F")
            p = new FragileParcel(
              id,
              g,
              r,
              number(await ask("Declared value: ")),
            );
          else throw new Error("unknown type");
          state.add(p);
          console.log("Dispatch fee:", state.dispatch(id));
        } else if (choice === "3") {
          console.log("Pending:", state.pending(), "Total:", state.total());
        } else if (choice === "4") {
          state = make();
          console.log(
            "Reset clears shipments. Fees are fictional whole credit units. Demo does not change state.",
          );
        } else console.log("Choose 1–5");
      } catch (e) {
        console.log("Rejected: " + e.message);
      }
    }
  } finally {
    rl.close();
  }
})();
