const {
  Parcel,
  StandardParcel,
  ExpressParcel,
  FragileParcel,
  Dispatch,
} = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function raises(fn) {
  try {
    fn();
  } catch (e) {
    if (e instanceof Error) return;
    throw e;
  }
  throw new Error("expected rejection");
}

function tc1() {
  let s = new Dispatch();
  raises(() => s.quote("none"));
  raises(() => s.add(new StandardParcel("bad", 0, false)));
}

function tc2() {
  let p = new StandardParcel("PK1", 501, false);
  eq(70, p.quote());
}

function tc3() {
  let p = new ExpressParcel("PK2", 500, false);
  eq(130, p.quote());
}

function tc4() {
  let p = new FragileParcel("PK3", 500, false, 101);
  eq(56, p.quote());
}

function tc5() {
  let p = new StandardParcel("PK4", 500, true);
  eq(75, p.quote());
}

function tc6() {
  let s = new Dispatch();
  s.add(new StandardParcel("PK5", 500, false));
  eq(50, s.dispatch("PK5"));
  eq(0, s.pending());
  raises(() => s.dispatch("PK5"));
}

function tc7() {
  let s = new Dispatch();
  s.add(new StandardParcel("PK6", 500, false));
  eq(50, s.quote("PK6"));
  eq(50, s.quote("PK6"));
  eq(1, s.pending());
}

function tc8() {
  let s = new Dispatch();
  s.add(new StandardParcel("PK7", 500, false));
  raises(() => s.add(new StandardParcel("PK7", 500, false)));
  eq(1, s.pending());
}

function tc9() {
  let s = new Dispatch();
  s.add(new StandardParcel("A", 500, false));
  s.add(new ExpressParcel("B", 500, false));
  s.add(new FragileParcel("C", 500, false, 100));
  eq(233, s.total());
}

function tc10() {
  throw new Error(
    "Add a remote Express parcel RX weighing 501g. Assert total and dispatch fee are 195; after dispatch assert pending and total are zero. Attempt a repeat dispatch, assert rejection, and confirm total remains zero.",
  );
}

let passed = 0;
try {
  tc1();
  passed++;
  console.log("TC1 PASS: Validation and unknown ID");
} catch (e) {
  console.log("TC1 FAIL: Validation and unknown ID: " + e.message);
}
try {
  tc2();
  passed++;
  console.log("TC2 PASS: Weight block boundary");
} catch (e) {
  console.log("TC2 FAIL: Weight block boundary: " + e.message);
}
try {
  tc3();
  passed++;
  console.log("TC3 PASS: Express override");
} catch (e) {
  console.log("TC3 FAIL: Express override: " + e.message);
}
try {
  tc4();
  passed++;
  console.log("TC4 PASS: Fragile insurance ceiling");
} catch (e) {
  console.log("TC4 FAIL: Fragile insurance ceiling: " + e.message);
}
try {
  tc5();
  passed++;
  console.log("TC5 PASS: Remote surcharge");
} catch (e) {
  console.log("TC5 FAIL: Remote surcharge: " + e.message);
}
try {
  tc6();
  passed++;
  console.log("TC6 PASS: Dispatch lifecycle");
} catch (e) {
  console.log("TC6 FAIL: Dispatch lifecycle: " + e.message);
}
try {
  tc7();
  passed++;
  console.log("TC7 PASS: Quote is pure");
} catch (e) {
  console.log("TC7 FAIL: Quote is pure: " + e.message);
}
try {
  tc8();
  passed++;
  console.log("TC8 PASS: Duplicate identifier");
} catch (e) {
  console.log("TC8 FAIL: Duplicate identifier: " + e.message);
}
try {
  tc9();
  passed++;
  console.log("TC9 PASS: Mixed subtype total");
} catch (e) {
  console.log("TC9 FAIL: Mixed subtype total: " + e.message);
}
try {
  tc10();
  passed++;
  console.log("TC10 PASS: Combined remote express lifecycle");
} catch (e) {
  console.log("TC10 FAIL: Combined remote express lifecycle: " + e.message);
}
console.log(`SUMMARY ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
