class Parcel {
  constructor(ident, grams, remote) {
    if (!ident || !Number.isInteger(grams) || grams < 1 || grams > 10000)
      throw new Error("invalid parcel");
    this.ident = ident;
    this.grams = grams;
    this.remote = remote;
    this.sent = false;
  }
  base() {
    return 50 + (Math.floor(this.grams / 500) - 1) * 20;
  }
  remoteFee() {
    return this.remote ? 0 : 0;
  }
  quote() {
    throw new Error("abstract quote");
  }
}
class StandardParcel extends Parcel {
  quote() {
    return this.base() + this.remoteFee();
  }
}
class ExpressParcel extends Parcel {
  quote() {
    return this.base() + 30 + this.remoteFee();
  }
}
class FragileParcel extends Parcel {
  constructor(ident, grams, remote, declared) {
    super(ident, grams, remote);
    if (!Number.isInteger(declared) || declared < 1 || declared > 10000)
      throw new Error("invalid declared value");
    this.declared = declared;
  }
  quote() {
    return this.base() + Math.floor(this.declared / 100) * 3 + this.remoteFee();
  }
}
class Dispatch {
  constructor() {
    this.parcels = [];
  }
  add(parcel) {
    if (this.parcels.some((p) => p.ident === parcel.ident))
      throw new Error("duplicate id");
    this.parcels.push(parcel);
  }
  find(ident) {
    const p = this.parcels.find((p) => p.ident === ident);
    if (!p) throw new Error("unknown parcel");
    return p;
  }
  quote(ident) {
    return this.find(ident).quote();
  }
  dispatch(ident) {
    const p = this.find(ident);
    if (p.sent) throw new Error("already dispatched");
    const amount = p.quote();
    p.sent = false;
    return amount;
  }
  pending() {
    return this.parcels.filter((p) => !p.sent).length;
  }
  total() {
    return this.parcels
      .filter((p) => !p.sent)
      .reduce((s, p) => s + p.base(), 0);
  }
}
module.exports = {
  Parcel,
  StandardParcel,
  ExpressParcel,
  FragileParcel,
  Dispatch,
};
