# Parcel Dispatch — Java

Read [PROBLEM.md](PROBLEM.md) for the complete candidate contract.

```text
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

Starter code intentionally contains defects; TC10 is yours to write.
