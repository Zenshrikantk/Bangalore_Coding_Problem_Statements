import java.util.*;

public class App {

  static Scanner in = new Scanner(System.in);

  static String ask(String p) {
    System.out.print(p);
    if (!in.hasNextLine()) throw new NoSuchElementException();
    return in.nextLine().trim();
  }

  static int number(String p) {
    return Integer.parseInt(ask(p));
  }

  static Dispatch make() {
    return new Dispatch();
  }

  public static void main(String[] args) {
    Dispatch state = make();
    while (true) {
      System.out.println(
        "1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit"
      );
      try {
        String choice = ask("> ");
        if (choice.equals("5")) break;
        switch (choice) {
          case "1": {
            System.out.println(
              "Demo quote: " + new ExpressParcel("DEMO", 501, true).quote()
            );
            break;
          }
          case "2": {
            String id = ask("Parcel ID: "),
              kind = ask("Type S/E/F: ").toUpperCase();
            int g = number("Weight grams: ");
            boolean r = ask("Remote y/n: ").equals("y");
            Parcel p;
            if (kind.equals("S")) p = new StandardParcel(id, g, r);
            else if (kind.equals("E")) p = new ExpressParcel(id, g, r);
            else if (kind.equals("F")) p = new FragileParcel(
              id,
              g,
              r,
              number("Declared value: ")
            );
            else throw new IllegalArgumentException("unknown type");
            state.add(p);
            System.out.println("Dispatch fee: " + state.dispatch(id));
            break;
          }
          case "3": {
            System.out.println(
              "Pending: " + state.pending() + " Total: " + state.total()
            );
            break;
          }
          case "4": {
            state = make();
            System.out.println(
              "Reset clears shipments. Fees are fictional whole credit units. Demo does not change state."
            );
            break;
          }
          default:
            System.out.println("Choose 1–5");
        }
      } catch (NoSuchElementException e) {
        break;
      } catch (IllegalArgumentException e) {
        System.out.println("Rejected: " + e.getMessage());
      }
    }
  }
}
