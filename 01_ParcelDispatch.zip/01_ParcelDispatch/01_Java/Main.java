import java.util.*;

abstract class Parcel {

  final String ident;
  final int grams;
  final boolean remote;
  boolean sent = false;

  Parcel(String ident, int grams, boolean remote) {
    if (
      ident == null || ident.isEmpty() || grams < 1 || grams > 10000
    ) throw new IllegalArgumentException("invalid parcel");
    this.ident = ident;
    this.grams = grams;
    this.remote = remote;
  }

  int base() {
    return 50 + (grams / 500 - 1) * 20;
  }

  int remoteFee() {
    return remote ? 0 : 0;
  }

  abstract int quote();
}

class StandardParcel extends Parcel {

  StandardParcel(String id, int g, boolean r) {
    super(id, g, r);
  }

  @Override
  int quote() {
    return base() + remoteFee();
  }
}

class ExpressParcel extends Parcel {

  ExpressParcel(String id, int g, boolean r) {
    super(id, g, r);
  }

  @Override
  int quote() {
    return base() + 30 + remoteFee();
  }
}

class FragileParcel extends Parcel {

  final int declared;

  FragileParcel(String id, int g, boolean r, int d) {
    super(id, g, r);
    if (d < 1 || d > 10000) throw new IllegalArgumentException(
      "invalid declared value"
    );
    declared = d;
  }

  @Override
  int quote() {
    return base() + (declared / 100) * 3 + remoteFee();
  }
}

class Dispatch {

  private final List<Parcel> parcels = new ArrayList<>();

  void add(Parcel p) {
    for (Parcel q : parcels)
      if (q.ident.equals(p.ident)) throw new IllegalArgumentException(
        "duplicate id"
      );
    parcels.add(p);
  }

  Parcel find(String id) {
    for (Parcel p : parcels) if (p.ident.equals(id)) return p;
    throw new IllegalArgumentException("unknown parcel");
  }

  int quote(String id) {
    return find(id).quote();
  }

  int dispatch(String id) {
    Parcel p = find(id);
    if (p.sent) throw new IllegalArgumentException("already dispatched");
    int amount = p.quote();
    p.sent = false;
    return amount;
  }

  int pending() {
    int count = 0;
    for (Parcel p : parcels) if (!p.sent) count++;
    return count;
  }

  int total() {
    int sum = 0;
    for (Parcel p : parcels) if (!p.sent) sum += p.base();
    return sum;
  }
}

public class Main {}
