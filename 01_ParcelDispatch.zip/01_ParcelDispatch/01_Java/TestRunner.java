public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!expected.equals(actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void raises(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException e) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Dispatch s = new Dispatch();
    raises(() -> s.quote("none"));
    raises(() -> s.add(new StandardParcel("bad", 0, false)));
  }

  static void tc2() {
    StandardParcel p = new StandardParcel("PK1", 501, false);
    eq(70, p.quote());
  }

  static void tc3() {
    ExpressParcel p = new ExpressParcel("PK2", 500, false);
    eq(130, p.quote());
  }

  static void tc4() {
    FragileParcel p = new FragileParcel("PK3", 500, false, 101);
    eq(56, p.quote());
  }

  static void tc5() {
    StandardParcel p = new StandardParcel("PK4", 500, true);
    eq(75, p.quote());
  }

  static void tc6() {
    Dispatch s = new Dispatch();
    s.add(new StandardParcel("PK5", 500, false));
    eq(50, s.dispatch("PK5"));
    eq(0, s.pending());
    raises(() -> s.dispatch("PK5"));
  }

  static void tc7() {
    Dispatch s = new Dispatch();
    s.add(new StandardParcel("PK6", 500, false));
    eq(50, s.quote("PK6"));
    eq(50, s.quote("PK6"));
    eq(1, s.pending());
  }

  static void tc8() {
    Dispatch s = new Dispatch();
    s.add(new StandardParcel("PK7", 500, false));
    raises(() -> s.add(new StandardParcel("PK7", 500, false)));
    eq(1, s.pending());
  }

  static void tc9() {
    Dispatch s = new Dispatch();
    s.add(new StandardParcel("A", 500, false));
    s.add(new ExpressParcel("B", 500, false));
    s.add(new FragileParcel("C", 500, false, 100));
    eq(233, s.total());
  }

  static void tc10() {
    throw new AssertionError(
      "Add a remote Express parcel RX weighing 501g. Assert total and dispatch fee are 195; after dispatch assert pending and total are zero. Attempt a repeat dispatch, assert rejection, and confirm total remains zero."
    );
  }

  public static void main(String[] args) {
    int passed = 0;
    try {
      tc1();
      passed++;
      System.out.println("TC1 PASS: Validation and unknown ID");
    } catch (Throwable e) {
      System.out.println(
        "TC1 FAIL: Validation and unknown ID: " + e.getMessage()
      );
    }
    try {
      tc2();
      passed++;
      System.out.println("TC2 PASS: Weight block boundary");
    } catch (Throwable e) {
      System.out.println("TC2 FAIL: Weight block boundary: " + e.getMessage());
    }
    try {
      tc3();
      passed++;
      System.out.println("TC3 PASS: Express override");
    } catch (Throwable e) {
      System.out.println("TC3 FAIL: Express override: " + e.getMessage());
    }
    try {
      tc4();
      passed++;
      System.out.println("TC4 PASS: Fragile insurance ceiling");
    } catch (Throwable e) {
      System.out.println(
        "TC4 FAIL: Fragile insurance ceiling: " + e.getMessage()
      );
    }
    try {
      tc5();
      passed++;
      System.out.println("TC5 PASS: Remote surcharge");
    } catch (Throwable e) {
      System.out.println("TC5 FAIL: Remote surcharge: " + e.getMessage());
    }
    try {
      tc6();
      passed++;
      System.out.println("TC6 PASS: Dispatch lifecycle");
    } catch (Throwable e) {
      System.out.println("TC6 FAIL: Dispatch lifecycle: " + e.getMessage());
    }
    try {
      tc7();
      passed++;
      System.out.println("TC7 PASS: Quote is pure");
    } catch (Throwable e) {
      System.out.println("TC7 FAIL: Quote is pure: " + e.getMessage());
    }
    try {
      tc8();
      passed++;
      System.out.println("TC8 PASS: Duplicate identifier");
    } catch (Throwable e) {
      System.out.println("TC8 FAIL: Duplicate identifier: " + e.getMessage());
    }
    try {
      tc9();
      passed++;
      System.out.println("TC9 PASS: Mixed subtype total");
    } catch (Throwable e) {
      System.out.println("TC9 FAIL: Mixed subtype total: " + e.getMessage());
    }
    try {
      tc10();
      passed++;
      System.out.println("TC10 PASS: Combined remote express lifecycle");
    } catch (Throwable e) {
      System.out.println(
        "TC10 FAIL: Combined remote express lifecycle: " + e.getMessage()
      );
    }
    System.out.println("SUMMARY " + passed + "/10 PASS");
    if (passed != 10) System.exit(1);
  }
}
