# Parcel Dispatch Debugging Challenge

**Track:** OOP · **Difficulty:** Intermediate · **Suggested time:** 90–120 minutes

Repair a dispatch service whose parcel subclasses misprice deliveries and whose lifecycle leaves sent parcels pending.

This is a deliberately defective, dependency-free console application. Diagnose the defects, repair business code, and implement TC10. The rules below are authoritative; source code may disagree. Policies are fictional training rules.

## Model and public API

`Parcel(id, grams, remote)` is abstract. `StandardParcel` and `ExpressParcel` inherit that constructor; `FragileParcel(id, grams, remote, declared)` adds insured value. `quote()` returns integer credits. `Dispatch.add(parcel)`, `quote(id)`, `dispatch(id)`, `pending()` and `total()` manage a collection. `dispatch` returns the charged quote.

## Rules and boundaries

- IDs are nonempty case-sensitive strings and unique within one Dispatch; duplicate add rejects without replacing the original. All operations receive proper object/types; grams and declared value are integers in 1–10000.
- Every started 500g block counts. Base fee = 50 + (ceil(grams/500) - 1) × 20.
- Standard = base; Express = base × 2 + 30; Fragile = base + ceil(declared/100) × 3. All amounts use integer fictional credits.
- Every subtype adds 25 for a remote destination, after its subtype formula.
- Quotation is pure. Dispatch checks existence, then already-sent state, then stores sent=true and returns the quote. Re-dispatch rejects without changing state.
- pending() counts unsent parcels; total() sums their polymorphic quotes, including remote and subtype charges. Zero parcels means zero. Failed operations leave collection/lifecycle state unchanged.
- Use at most 1000 parcels per Dispatch; execution is single-threaded. Invalid values, duplicate IDs and invalid transitions raise ValueError / Error / IllegalArgumentException.

## Worked examples

- **Express parcel, 501g, remote** → **195 credits**. 2 blocks → base 70; 70 × 2 + 30 + 25.
- **Fragile parcel, 500g, declared 101, local** → **56 credits**. Base 50 plus 2 insurance units × 3.

## Supplied tests

| Case | Coverage | Expected outcome |
|---|---|---|
| TC1 | Validation and unknown ID | Unknown ID and zero weight reject. |
| TC2 | Weight block boundary | 501g costs 70. |
| TC3 | Express override | 500g local Express costs 130. |
| TC4 | Fragile insurance ceiling | Declared 101 costs 56 at 500g. |
| TC5 | Remote surcharge | 500g remote Standard costs 75. |
| TC6 | Dispatch lifecycle | One dispatch returns 50, removes pending status; repeat rejects. |
| TC7 | Quote is pure | Repeated quotes return 50 and retain pending=1. |
| TC8 | Duplicate identifier | Duplicate rejected; one pending remains. |
| TC9 | Mixed subtype total | Standard + Express + Fragile = 233. |

## TC10 — candidate-owned test

Add a remote Express parcel RX weighing 501g. Assert total and dispatch fee are 195; after dispatch assert pending and total are zero. Attempt a repeat dispatch, assert rejection, and confirm total remains zero.

Replace the deliberately failing stub with meaningful assertions. Retain TC1–TC9 unchanged. The runner continues after each failure and exits nonzero if any test fails.

## Run locally

Select one language; all three implement the same rules.

```text
Java (01_Java):       javac Main.java TestRunner.java App.java
                     java TestRunner
                     java App
Python (02_Python):   python3 test_runner.py
                     python3 app.py
Node (03_JavaScript): node test_runner.js
                     node app.js
```

Requires a JDK (Java 11+), Python 3.8+, or Node 16+. No package installation is required. Run from the chosen language directory.

## Candidate deliverables

1. Record the baseline failures and explain each root cause.
2. Repair business logic while preserving the public APIs and the supplied tests.
3. Complete TC10, achieve 10/10, and demonstrate a user-entered console operation.
4. Explain the object model, boundary arithmetic, and complexity. Avoid fixture-specific outputs or disabling assertions.

## Discussion prompts

- Why must total call quote rather than base?
- Where should the remote fee be applied?
- Why reject a repeated dispatch?
