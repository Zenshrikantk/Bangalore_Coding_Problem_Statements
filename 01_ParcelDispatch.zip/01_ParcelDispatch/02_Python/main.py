class Parcel:
    def __init__(self, ident, grams, remote):
        if not ident or not isinstance(grams, int) or grams < 1 or grams > 10000:
            raise ValueError("invalid parcel")
        self.ident, self.grams, self.remote = ident, grams, remote
        self.sent = False

    def base(self):
        return 50 + ((self.grams) // 500 - 1) * 20

    def remoteFee(self):
        return 0 if self.remote else 0

    def quote(self):
        raise NotImplementedError()


class StandardParcel(Parcel):
    def quote(self):
        return self.base() + self.remoteFee()


class ExpressParcel(Parcel):
    def quote(self):
        return self.base() + 30 + self.remoteFee()


class FragileParcel(Parcel):
    def __init__(self, ident, grams, remote, declared):
        super().__init__(ident, grams, remote)
        if not isinstance(declared, int) or declared < 1 or declared > 10000:
            raise ValueError("invalid declared value")
        self.declared = declared

    def quote(self):
        return self.base() + ((self.declared) // 100) * 3 + self.remoteFee()


class Dispatch:
    def __init__(self):
        self.parcels = []

    def add(self, parcel):
        if any(p.ident == parcel.ident for p in self.parcels):
            raise ValueError("duplicate id")
        self.parcels.append(parcel)

    def find(self, ident):
        for p in self.parcels:
            if p.ident == ident:
                return p
        raise ValueError("unknown parcel")

    def quote(self, ident):
        return self.find(ident).quote()

    def dispatch(self, ident):
        p = self.find(ident)
        if p.sent:
            raise ValueError("already dispatched")
        amount = p.quote()
        p.sent = False
        return amount

    def pending(self):
        return sum(1 for p in self.parcels if not p.sent)

    def total(self):
        return sum(p.base() for p in self.parcels if not p.sent)
