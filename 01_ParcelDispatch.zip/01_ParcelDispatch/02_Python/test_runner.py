from main import *
import sys


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def raises(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    s = Dispatch()
    raises(lambda: s.quote("none"))
    raises(lambda: s.add(StandardParcel("bad", 0, False)))


def tc2():
    p = StandardParcel("PK1", 501, False)
    eq(70, p.quote())


def tc3():
    p = ExpressParcel("PK2", 500, False)
    eq(130, p.quote())


def tc4():
    p = FragileParcel("PK3", 500, False, 101)
    eq(56, p.quote())


def tc5():
    p = StandardParcel("PK4", 500, True)
    eq(75, p.quote())


def tc6():
    s = Dispatch()
    s.add(StandardParcel("PK5", 500, False))
    eq(50, s.dispatch("PK5"))
    eq(0, s.pending())
    raises(lambda: s.dispatch("PK5"))


def tc7():
    s = Dispatch()
    s.add(StandardParcel("PK6", 500, False))
    eq(50, s.quote("PK6"))
    eq(50, s.quote("PK6"))
    eq(1, s.pending())


def tc8():
    s = Dispatch()
    s.add(StandardParcel("PK7", 500, False))
    raises(lambda: s.add(StandardParcel("PK7", 500, False)))
    eq(1, s.pending())


def tc9():
    s = Dispatch()
    s.add(StandardParcel("A", 500, False))
    s.add(ExpressParcel("B", 500, False))
    s.add(FragileParcel("C", 500, False, 100))
    eq(233, s.total())


def tc10():
    raise AssertionError(
        "Add a remote Express parcel RX weighing 501g. Assert total and dispatch fee are 195; after dispatch assert pending and total are zero. Attempt a repeat dispatch, assert rejection, and confirm total remains zero."
    )


if __name__ == "__main__":
    passed = 0
    try:
        tc1()
        passed += 1
        print("TC1 PASS: Validation and unknown ID")
    except Exception as e:
        print("TC1 FAIL: Validation and unknown ID: " + str(e))
    try:
        tc2()
        passed += 1
        print("TC2 PASS: Weight block boundary")
    except Exception as e:
        print("TC2 FAIL: Weight block boundary: " + str(e))
    try:
        tc3()
        passed += 1
        print("TC3 PASS: Express override")
    except Exception as e:
        print("TC3 FAIL: Express override: " + str(e))
    try:
        tc4()
        passed += 1
        print("TC4 PASS: Fragile insurance ceiling")
    except Exception as e:
        print("TC4 FAIL: Fragile insurance ceiling: " + str(e))
    try:
        tc5()
        passed += 1
        print("TC5 PASS: Remote surcharge")
    except Exception as e:
        print("TC5 FAIL: Remote surcharge: " + str(e))
    try:
        tc6()
        passed += 1
        print("TC6 PASS: Dispatch lifecycle")
    except Exception as e:
        print("TC6 FAIL: Dispatch lifecycle: " + str(e))
    try:
        tc7()
        passed += 1
        print("TC7 PASS: Quote is pure")
    except Exception as e:
        print("TC7 FAIL: Quote is pure: " + str(e))
    try:
        tc8()
        passed += 1
        print("TC8 PASS: Duplicate identifier")
    except Exception as e:
        print("TC8 FAIL: Duplicate identifier: " + str(e))
    try:
        tc9()
        passed += 1
        print("TC9 PASS: Mixed subtype total")
    except Exception as e:
        print("TC9 FAIL: Mixed subtype total: " + str(e))
    try:
        tc10()
        passed += 1
        print("TC10 PASS: Combined remote express lifecycle")
    except Exception as e:
        print("TC10 FAIL: Combined remote express lifecycle: " + str(e))
    print(f"SUMMARY {passed}/10 PASS")
    sys.exit(0 if passed == 10 else 1)
