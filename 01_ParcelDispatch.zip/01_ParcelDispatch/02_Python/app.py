from main import *


def make():
    return Dispatch()


state = make()
while True:
    print("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit")
    try:
        choice = input("> ").strip()
        if choice == "5":
            break
        if choice == "1":
            p = ExpressParcel("DEMO", 501, True)
            print("Demo quote:", p.quote())
        elif choice == "2":
            ident = input("Parcel ID: ").strip()
            kind = input("Type S/E/F: ").strip().upper()
            grams = int(input("Weight grams: "))
            remote = input("Remote y/n: ").strip().lower() == "y"
            if kind == "S":
                p = StandardParcel(ident, grams, remote)
            elif kind == "E":
                p = ExpressParcel(ident, grams, remote)
            elif kind == "F":
                p = FragileParcel(ident, grams, remote, int(input("Declared value: ")))
            else:
                raise ValueError("unknown type")
            state.add(p)
            print("Dispatch fee:", state.dispatch(ident))
        elif choice == "3":
            print("Pending:", state.pending(), "Total:", state.total())
        elif choice == "4":
            state = make()
            print(
                "Reset clears shipments. Fees are fictional whole credit units. Demo does not change state."
            )
        else:
            print("Choose 1–5")
    except (EOFError, KeyboardInterrupt):
        break
    except (ValueError, TypeError) as e:
        print("Rejected:", e)
