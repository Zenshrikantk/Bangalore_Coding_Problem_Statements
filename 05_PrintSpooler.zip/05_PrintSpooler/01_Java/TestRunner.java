public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!expected.equals(actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void raises(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException e) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Spooler s = new Spooler();
    raises(() -> s.cancel("missing"));
    raises(() -> s.submit(new MonoJob("BAD", 0, 1, false)));
    eq(0, s.pending());
  }

  static void tc2() {
    MonoJob x = new MonoJob("P1", 5, 2, true);
    eq(6, x.sheets());
  }

  static void tc3() {
    ColorJob x = new ColorJob("P2", 3, 1, false);
    eq(15, x.quote());
  }

  static void tc4() {
    BookletJob x = new BookletJob("P3", 5, 1);
    eq(2, x.sheets());
  }

  static void tc5() {
    MonoJob x = new MonoJob("P4", 4, 2, true);
    eq(8, x.quote());
  }

  static void tc6() {
    BookletJob x = new BookletJob("P5", 4, 2);
    eq(36, x.quote());
  }

  static void tc7() {
    Spooler s = new Spooler();
    s.submit(new MonoJob("FIRST", 2, 1, false));
    s.submit(new MonoJob("SECOND", 2, 1, false));
    eq("FIRST", s.process());
    eq("PRINTED", s.status("FIRST"));
    eq(1, s.pending());
  }

  static void tc8() {
    Spooler s = new Spooler();
    s.submit(new MonoJob("CANCEL", 2, 1, false));
    s.cancel("CANCEL");
    eq("CANCELLED", s.status("CANCEL"));
    eq(0, s.pending());
    raises(() -> s.process());
    eq(0, s.sheetsPrinted());
  }

  static void tc9() {
    Spooler s = new Spooler();
    MonoJob x = new MonoJob("KEEP", 3, 1, false);
    s.submit(x);
    raises(() -> s.submit(new MonoJob("KEEP", 9, 1, false)));
    eq(3, x.quote());
    eq(3, x.quote());
    eq(1, s.pending());
  }

  static void tc10() {
    throw new AssertionError(
      "Queue Mono SKIP (3 pages,1 simplex copy), Booklet BOOK (7 pages,2 copies), then Mono LAST (1 page,1 simplex copy). Cancel SKIP. Assert first process returns BOOK, printed sheets4 and pending1. Reject cancellation of BOOK and preserve sheets4. Process LAST, assert total sheets5, then reject empty processing."
    );
  }

  public static void main(String[] args) {
    int passed = 0;
    try {
      tc1();
      passed++;
      System.out.println("TC1 PASS: Invalid job and unknown cancellation");
    } catch (Throwable e) {
      System.out.println(
        "TC1 FAIL: Invalid job and unknown cancellation: " + e.getMessage()
      );
    }
    try {
      tc2();
      passed++;
      System.out.println("TC2 PASS: Odd duplex page count per copy");
    } catch (Throwable e) {
      System.out.println(
        "TC2 FAIL: Odd duplex page count per copy: " + e.getMessage()
      );
    }
    try {
      tc3();
      passed++;
      System.out.println("TC3 PASS: Color rate override");
    } catch (Throwable e) {
      System.out.println("TC3 FAIL: Color rate override: " + e.getMessage());
    }
    try {
      tc4();
      passed++;
      System.out.println("TC4 PASS: Booklet folding sheet ceiling");
    } catch (Throwable e) {
      System.out.println(
        "TC4 FAIL: Booklet folding sheet ceiling: " + e.getMessage()
      );
    }
    try {
      tc5();
      passed++;
      System.out.println("TC5 PASS: Charge content pages not sheets");
    } catch (Throwable e) {
      System.out.println(
        "TC5 FAIL: Charge content pages not sheets: " + e.getMessage()
      );
    }
    try {
      tc6();
      passed++;
      System.out.println("TC6 PASS: Booklet binding per copy");
    } catch (Throwable e) {
      System.out.println(
        "TC6 FAIL: Booklet binding per copy: " + e.getMessage()
      );
    }
    try {
      tc7();
      passed++;
      System.out.println("TC7 PASS: FIFO processing order");
    } catch (Throwable e) {
      System.out.println("TC7 FAIL: FIFO processing order: " + e.getMessage());
    }
    try {
      tc8();
      passed++;
      System.out.println("TC8 PASS: Cancel changes queue state");
    } catch (Throwable e) {
      System.out.println(
        "TC8 FAIL: Cancel changes queue state: " + e.getMessage()
      );
    }
    try {
      tc9();
      passed++;
      System.out.println("TC9 PASS: Duplicate protection and pure quote");
    } catch (Throwable e) {
      System.out.println(
        "TC9 FAIL: Duplicate protection and pure quote: " + e.getMessage()
      );
    }
    try {
      tc10();
      passed++;
      System.out.println(
        "TC10 PASS: Skip cancelled job and account booklet sheets"
      );
    } catch (Throwable e) {
      System.out.println(
        "TC10 FAIL: Skip cancelled job and account booklet sheets: " +
          e.getMessage()
      );
    }
    System.out.println("SUMMARY " + passed + "/10 PASS");
    if (passed != 10) System.exit(1);
  }
}
