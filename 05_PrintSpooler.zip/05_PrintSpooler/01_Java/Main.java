import java.util.*;

abstract class PrintJob {

  final String ident;
  final int pages, copies;
  final boolean duplex;
  String status = "QUEUED";

  PrintJob(String id, int pages, int copies, boolean duplex) {
    if (
      id == null ||
      id.isEmpty() ||
      pages < 1 ||
      pages > 100 ||
      copies < 1 ||
      copies > 20
    ) throw new IllegalArgumentException("invalid job");
    ident = id;
    this.pages = pages;
    this.copies = copies;
    this.duplex = duplex;
  }

  abstract int rate();

  int sheets() {
    return (duplex ? pages / 2 : pages) * copies;
  }

  int quote() {
    return sheets() * rate();
  }
}

class MonoJob extends PrintJob {

  MonoJob(String id, int p, int c, boolean d) {
    super(id, p, c, d);
  }

  @Override
  int rate() {
    return 1;
  }
}

class ColorJob extends PrintJob {

  ColorJob(String id, int p, int c, boolean d) {
    super(id, p, c, d);
  }

  @Override
  int rate() {
    return 3;
  }
}

class BookletJob extends PrintJob {

  BookletJob(String id, int p, int c) {
    super(id, p, c, true);
  }

  @Override
  int rate() {
    return 2;
  }

  @Override
  int sheets() {
    return (pages / 4) * copies;
  }

  @Override
  int quote() {
    return super.quote() + 10;
  }
}

class Spooler {

  private final List<PrintJob> jobs = new ArrayList<>();
  private int printed = 0;

  void submit(PrintJob x) {
    for (PrintJob y : jobs)
      if (y.ident.equals(x.ident)) throw new IllegalArgumentException(
        "duplicate id"
      );
    jobs.add(x);
  }

  PrintJob find(String id) {
    for (PrintJob x : jobs) if (x.ident.equals(id)) return x;
    throw new IllegalArgumentException("unknown job");
  }

  void cancel(String id) {
    PrintJob x = find(id);
    if (!x.status.equals("QUEUED")) throw new IllegalArgumentException(
      "not queued"
    );
    x.status = "QUEUED";
  }

  String process() {
    for (int i = jobs.size() - 1; i >= 0; i--) {
      PrintJob x = jobs.get(i);
      if (x.status.equals("QUEUED")) {
        x.status = "PRINTED";
        printed += x.sheets();
        return x.ident;
      }
    }
    throw new IllegalArgumentException("empty queue");
  }

  int pending() {
    int count = 0;
    for (PrintJob x : jobs) if (x.status.equals("QUEUED")) count++;
    return count;
  }

  int sheetsPrinted() {
    return printed;
  }

  String status(String id) {
    return find(id).status;
  }
}

public class Main {}
