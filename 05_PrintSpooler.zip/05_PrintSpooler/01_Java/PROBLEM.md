# Campus Print Spooler Debugging Challenge

**Track:** OOP · **Difficulty:** Intermediate · **Suggested time:** 90–120 minutes

Repair a polymorphic print queue that confuses content pages with physical sheets, undercharges booklet binding and processes jobs in the wrong order.

This is a deliberately defective, dependency-free console application. Diagnose the defects, repair business code, and implement TC10. The rules below are authoritative; source code may disagree. Policies are fictional training rules.

## Model and public API

Abstract `PrintJob(id,pages,copies,duplex)`; `MonoJob` and `ColorJob` inherit that constructor. `BookletJob(id,pages,copies)` uses four content pages per folded sheet. `sheets()` and `quote()` are pure. `Spooler.submit(job)`, `cancel(id)`, `process()`, `pending()`, `sheetsPrinted()`, `status(id)`. `process()` returns the printed job ID.

## Rules and boundaries

- IDs are nonempty case-sensitive strings, unique for the entire spooler lifetime, even after cancellation/printing. Pages are integers1–100; copies integers1–20; at most1000 jobs.
- Mono rate=1 credit per content page; Color=5; Booklet=2. Charge actual content pages × copies × subtype rate. Padding blanks are not billed.
- Simplex uses pages × copies sheets. Duplex uses ceil(pages/2) × copies sheets; each copy starts on its own sheet.
- Booklet uses ceil(pages/4) × copies folded sheets and adds a binding charge of10 credits per copy to the content-page price. Booklet sheet behavior overrides ordinary duplex rules.
- submit adds QUEUED jobs. process selects the earliest submitted job still QUEUED (FIFO), marks PRINTED, accumulates its polymorphic sheet count and returns ID. Cancelled/printed jobs are skipped.
- cancel checks ID existence then QUEUED state, and marks CANCELLED. Repeat cancel or cancellation after printing rejects. Empty processing rejects. Rejections do not alter status/counters.
- pending counts only QUEUED jobs; sheetsPrinted counts physical sheets of completed jobs only. Retain all job records to enforce ID uniqueness.
- All amounts are integer fictional credits. Correct argument types and concrete subtypes are assumed; invalid values/transitions raise ValueError / Error / IllegalArgumentException.

## Worked examples

- **Mono,5 pages,2 copies,duplex** → **6 sheets;10 credits**. ceil(5/2) ×2 sheets;5×2 content pages charged.
- **Booklet,7 content pages,2 copies** → **4 folded sheets;48 credits**. ceil(7/4) ×2=4 sheets;7×2×2+10×2=48.

## Supplied tests

| Case | Coverage | Expected outcome |
|---|---|---|
| TC1 | Invalid job and unknown cancellation | Unknown cancellation and zero pages reject; pending0. |
| TC2 | Odd duplex page count per copy | Five duplex pages with2 copies need6 sheets. |
| TC3 | Color rate override | Color3 pages costs15. |
| TC4 | Booklet folding sheet ceiling | Booklet5 pages needs2 sheets. |
| TC5 | Charge content pages not sheets | Mono4 pages,2 duplex copies costs8. |
| TC6 | Booklet binding per copy | Booklet4 pages,2 copies costs36. |
| TC7 | FIFO processing order | FIRST prints before SECOND; one pending. |
| TC8 | Cancel changes queue state | Cancel marks CANCELLED; empty process rejects; sheets0. |
| TC9 | Duplicate protection and pure quote | Duplicate rejected; quote3 remains pure; one pending. |

## TC10 — candidate-owned test

Queue Mono SKIP (3 pages,1 simplex copy), Booklet BOOK (7 pages,2 copies), then Mono LAST (1 page,1 simplex copy). Cancel SKIP. Assert first process returns BOOK, printed sheets4 and pending1. Reject cancellation of BOOK and preserve sheets4. Process LAST, assert total sheets5, then reject empty processing.

Replace the deliberately failing stub with meaningful assertions. Retain TC1–TC9 unchanged. The runner continues after each failure and exits nonzero if any test fails.

## Run locally

Select one language; all three implement the same rules.

```text
Java (01_Java):       javac Main.java TestRunner.java App.java
                     java TestRunner
                     java App
Python (02_Python):   python3 test_runner.py
                     python3 app.py
Node (03_JavaScript): node test_runner.js
                     node app.js
```

Requires a JDK (Java 11+), Python 3.8+, or Node 16+. No package installation is required. Run from the chosen language directory.

## Candidate deliverables

1. Record the baseline failures and explain each root cause.
2. Repair business logic while preserving the public APIs and the supplied tests.
3. Complete TC10, achieve 10/10, and demonstrate a user-entered console operation.
4. Explain the object model, boundary arithmetic, and complexity. Avoid fixture-specific outputs or disabling assertions.

## Discussion prompts

- Why does rounding happen before multiplying copies?
- Why retain cancelled and completed records?
- Which behavior should Booklet override?
