import java.util.*;

public class App {

  static Scanner in = new Scanner(System.in);

  static String ask(String p) {
    System.out.print(p);
    if (!in.hasNextLine()) throw new NoSuchElementException();
    return in.nextLine().trim();
  }

  static int number(String p) {
    return Integer.parseInt(ask(p));
  }

  static Spooler make() {
    return new Spooler();
  }

  public static void main(String[] args) {
    Spooler state = make();
    while (true) {
      System.out.println(
        "1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit"
      );
      try {
        String choice = ask("> ");
        if (choice.equals("5")) break;
        switch (choice) {
          case "1": {
            BookletJob x = new BookletJob("DEMO", 7, 2);
            System.out.println(
              "Booklet quote: " + x.quote() + " Sheets: " + x.sheets()
            );
            break;
          }
          case "2": {
            String id = ask("Job ID: "),
              kind = ask("Type M/C/B: ").toUpperCase();
            int p = number("Content pages: "),
              cp = number("Copies: ");
            PrintJob x;
            if (kind.equals("B")) x = new BookletJob(id, p, cp);
            else if (kind.equals("M") || kind.equals("C")) {
              boolean d = ask("Duplex y/n: ").equals("y");
              x = kind.equals("M")
                ? new MonoJob(id, p, cp, d)
                : new ColorJob(id, p, cp, d);
            } else throw new IllegalArgumentException("unknown type");
            state.submit(x);
            System.out.println(
              "Queued quote: " + x.quote() + " Sheets: " + x.sheets()
            );
            break;
          }
          case "3": {
            String action = ask(
              "Action P=process, C=cancel, R=report: "
            ).toUpperCase();
            if (action.equals("P")) System.out.println(
              "Printed: " + state.process()
            );
            else if (action.equals("C")) state.cancel(ask("Job ID: "));
            else if (!action.equals("R")) throw new IllegalArgumentException(
              "unknown action"
            );
            System.out.println(
              "Pending: " +
                state.pending() +
                " Printed sheets: " +
                state.sheetsPrinted()
            );
            break;
          }
          case "4": {
            state = make();
            System.out.println(
              "Option2 queues a job. Option3 processes the oldest queued job, cancels by ID or reports. Reset clears all history."
            );
            break;
          }
          default:
            System.out.println("Choose 1–5");
        }
      } catch (NoSuchElementException e) {
        break;
      } catch (IllegalArgumentException e) {
        System.out.println("Rejected: " + e.getMessage());
      }
    }
  }
}
