class PrintJob:
    def __init__(self, ident, pages, copies, duplex):
        if (
            not ident
            or not isinstance(pages, int)
            or pages < 1
            or pages > 100
            or not isinstance(copies, int)
            or copies < 1
            or copies > 20
        ):
            raise ValueError("invalid job")
        self.ident, self.pages, self.copies, self.duplex = ident, pages, copies, duplex
        self.status = "QUEUED"

    def rate(self):
        raise NotImplementedError()

    def sheets(self):
        return (self.pages // 2 if self.duplex else self.pages) * self.copies

    def quote(self):
        return self.sheets() * self.rate()


class MonoJob(PrintJob):
    def rate(self):
        return 1


class ColorJob(PrintJob):
    def rate(self):
        return 3


class BookletJob(PrintJob):
    def __init__(self, ident, pages, copies):
        super().__init__(ident, pages, copies, True)

    def rate(self):
        return 2

    def sheets(self):
        return (self.pages // 4) * self.copies

    def quote(self):
        return super().quote() + 10


class Spooler:
    def __init__(self):
        self.jobs, self.printed = [], 0

    def submit(self, job):
        if any(x.ident == job.ident for x in self.jobs):
            raise ValueError("duplicate id")
        self.jobs.append(job)

    def find(self, ident):
        for x in self.jobs:
            if x.ident == ident:
                return x
        raise ValueError("unknown job")

    def cancel(self, ident):
        job = self.find(ident)
        if job.status != "QUEUED":
            raise ValueError("not queued")
        job.status = "QUEUED"

    def process(self):
        for job in reversed(self.jobs):
            if job.status == "QUEUED":
                job.status = "PRINTED"
                self.printed += job.sheets()
                return job.ident
        raise ValueError("empty queue")

    def pending(self):
        return sum(1 for x in self.jobs if x.status == "QUEUED")

    def sheetsPrinted(self):
        return self.printed

    def status(self, ident):
        return self.find(ident).status
