from main import *


def make():
    return Spooler()


state = make()
while True:
    print("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit")
    try:
        choice = input("> ").strip()
        if choice == "5":
            break
        if choice == "1":
            x = BookletJob("DEMO", 7, 2)
            print("Booklet quote:", x.quote(), "Sheets:", x.sheets())
        elif choice == "2":
            ident = input("Job ID: ").strip()
            kind = input("Type M/C/B: ").strip().upper()
            pages = int(input("Content pages: "))
            copies = int(input("Copies: "))
            if kind == "B":
                x = BookletJob(ident, pages, copies)
            elif kind in ["M", "C"]:
                duplex = input("Duplex y/n: ").strip().lower() == "y"
                x = (
                    MonoJob(ident, pages, copies, duplex)
                    if kind == "M"
                    else ColorJob(ident, pages, copies, duplex)
                )
            else:
                raise ValueError("unknown type")
            state.submit(x)
            print("Queued quote:", x.quote(), "Sheets:", x.sheets())
        elif choice == "3":
            action = input("Action P=process, C=cancel, R=report: ").strip().upper()
            if action == "P":
                print("Printed:", state.process())
            elif action == "C":
                state.cancel(input("Job ID: ").strip())
            elif action != "R":
                raise ValueError("unknown action")
            print("Pending:", state.pending(), "Printed sheets:", state.sheetsPrinted())
        elif choice == "4":
            state = make()
            print(
                "Option2 queues a job. Option3 processes the oldest queued job, cancels by ID or reports. Reset clears all history."
            )
        else:
            print("Choose 1–5")
    except (EOFError, KeyboardInterrupt):
        break
    except (ValueError, TypeError) as e:
        print("Rejected:", e)
