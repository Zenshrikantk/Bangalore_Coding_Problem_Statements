from main import *
import sys


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def raises(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    s = Spooler()
    raises(lambda: s.cancel("missing"))
    raises(lambda: s.submit(MonoJob("BAD", 0, 1, False)))
    eq(0, s.pending())


def tc2():
    x = MonoJob("P1", 5, 2, True)
    eq(6, x.sheets())


def tc3():
    x = ColorJob("P2", 3, 1, False)
    eq(15, x.quote())


def tc4():
    x = BookletJob("P3", 5, 1)
    eq(2, x.sheets())


def tc5():
    x = MonoJob("P4", 4, 2, True)
    eq(8, x.quote())


def tc6():
    x = BookletJob("P5", 4, 2)
    eq(36, x.quote())


def tc7():
    s = Spooler()
    s.submit(MonoJob("FIRST", 2, 1, False))
    s.submit(MonoJob("SECOND", 2, 1, False))
    eq("FIRST", s.process())
    eq("PRINTED", s.status("FIRST"))
    eq(1, s.pending())


def tc8():
    s = Spooler()
    s.submit(MonoJob("CANCEL", 2, 1, False))
    s.cancel("CANCEL")
    eq("CANCELLED", s.status("CANCEL"))
    eq(0, s.pending())
    raises(lambda: s.process())
    eq(0, s.sheetsPrinted())


def tc9():
    s = Spooler()
    x = MonoJob("KEEP", 3, 1, False)
    s.submit(x)
    raises(lambda: s.submit(MonoJob("KEEP", 9, 1, False)))
    eq(3, x.quote())
    eq(3, x.quote())
    eq(1, s.pending())


def tc10():
    raise AssertionError(
        "Queue Mono SKIP (3 pages,1 simplex copy), Booklet BOOK (7 pages,2 copies), then Mono LAST (1 page,1 simplex copy). Cancel SKIP. Assert first process returns BOOK, printed sheets4 and pending1. Reject cancellation of BOOK and preserve sheets4. Process LAST, assert total sheets5, then reject empty processing."
    )


if __name__ == "__main__":
    passed = 0
    try:
        tc1()
        passed += 1
        print("TC1 PASS: Invalid job and unknown cancellation")
    except Exception as e:
        print("TC1 FAIL: Invalid job and unknown cancellation: " + str(e))
    try:
        tc2()
        passed += 1
        print("TC2 PASS: Odd duplex page count per copy")
    except Exception as e:
        print("TC2 FAIL: Odd duplex page count per copy: " + str(e))
    try:
        tc3()
        passed += 1
        print("TC3 PASS: Color rate override")
    except Exception as e:
        print("TC3 FAIL: Color rate override: " + str(e))
    try:
        tc4()
        passed += 1
        print("TC4 PASS: Booklet folding sheet ceiling")
    except Exception as e:
        print("TC4 FAIL: Booklet folding sheet ceiling: " + str(e))
    try:
        tc5()
        passed += 1
        print("TC5 PASS: Charge content pages not sheets")
    except Exception as e:
        print("TC5 FAIL: Charge content pages not sheets: " + str(e))
    try:
        tc6()
        passed += 1
        print("TC6 PASS: Booklet binding per copy")
    except Exception as e:
        print("TC6 FAIL: Booklet binding per copy: " + str(e))
    try:
        tc7()
        passed += 1
        print("TC7 PASS: FIFO processing order")
    except Exception as e:
        print("TC7 FAIL: FIFO processing order: " + str(e))
    try:
        tc8()
        passed += 1
        print("TC8 PASS: Cancel changes queue state")
    except Exception as e:
        print("TC8 FAIL: Cancel changes queue state: " + str(e))
    try:
        tc9()
        passed += 1
        print("TC9 PASS: Duplicate protection and pure quote")
    except Exception as e:
        print("TC9 FAIL: Duplicate protection and pure quote: " + str(e))
    try:
        tc10()
        passed += 1
        print("TC10 PASS: Skip cancelled job and account booklet sheets")
    except Exception as e:
        print("TC10 FAIL: Skip cancelled job and account booklet sheets: " + str(e))
    print(f"SUMMARY {passed}/10 PASS")
    sys.exit(0 if passed == 10 else 1)
