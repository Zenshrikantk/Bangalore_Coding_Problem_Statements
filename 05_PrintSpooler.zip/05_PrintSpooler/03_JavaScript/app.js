const { PrintJob, MonoJob, ColorJob, BookletJob, Spooler } = require("./main");
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const lines = [];
let waiter = null,
  ended = false;
rl.on("line", (line) => {
  if (waiter) {
    const w = waiter;
    waiter = null;
    w(line);
  } else lines.push(line);
});
rl.on("close", () => {
  ended = true;
  if (waiter) {
    waiter(null);
    waiter = null;
  }
});
async function ask(prompt) {
  process.stdout.write(prompt);
  if (lines.length) return lines.shift();
  if (ended) return null;
  return await new Promise((r) => (waiter = r));
}
function number(s) {
  if (s === null || s.trim() === "" || !Number.isInteger(Number(s)))
    throw new Error("integer required");
  return Number(s);
}
function make() {
  return new Spooler();
}
(async () => {
  let state = make();
  try {
    while (true) {
      console.log("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit");
      const choice = await ask("> ");
      if (choice === null || choice === "5") break;
      try {
        if (choice === "1") {
          const x = new BookletJob("DEMO", 7, 2);
          console.log("Booklet quote:", x.quote(), "Sheets:", x.sheets());
        } else if (choice === "2") {
          const id = await ask("Job ID: "),
            kind = ((await ask("Type M/C/B: ")) || "").toUpperCase(),
            p = number(await ask("Content pages: ")),
            cp = number(await ask("Copies: "));
          let x;
          if (kind === "B") x = new BookletJob(id, p, cp);
          else if (kind === "M" || kind === "C") {
            const d = (await ask("Duplex y/n: ")) === "y";
            x =
              kind === "M"
                ? new MonoJob(id, p, cp, d)
                : new ColorJob(id, p, cp, d);
          } else throw new Error("unknown type");
          state.submit(x);
          console.log("Queued quote:", x.quote(), "Sheets:", x.sheets());
        } else if (choice === "3") {
          const action = (
            (await ask("Action P=process, C=cancel, R=report: ")) || ""
          ).toUpperCase();
          if (action === "P") console.log("Printed:", state.process());
          else if (action === "C") state.cancel(await ask("Job ID: "));
          else if (action !== "R") throw new Error("unknown action");
          console.log(
            "Pending:",
            state.pending(),
            "Printed sheets:",
            state.sheetsPrinted(),
          );
        } else if (choice === "4") {
          state = make();
          console.log(
            "Option2 queues a job. Option3 processes the oldest queued job, cancels by ID or reports. Reset clears all history.",
          );
        } else console.log("Choose 1–5");
      } catch (e) {
        console.log("Rejected: " + e.message);
      }
    }
  } finally {
    rl.close();
  }
})();
