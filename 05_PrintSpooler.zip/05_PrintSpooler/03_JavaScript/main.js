class PrintJob {
  constructor(ident, pages, copies, duplex) {
    if (
      !ident ||
      !Number.isInteger(pages) ||
      pages < 1 ||
      pages > 100 ||
      !Number.isInteger(copies) ||
      copies < 1 ||
      copies > 20
    )
      throw new Error("invalid job");
    this.ident = ident;
    this.pages = pages;
    this.copies = copies;
    this.duplex = duplex;
    this.status = "QUEUED";
  }
  rate() {
    throw new Error("abstract rate");
  }
  sheets() {
    return (
      (this.duplex ? Math.floor(this.pages / 2) : this.pages) * this.copies
    );
  }
  quote() {
    return this.sheets() * this.rate();
  }
}
class MonoJob extends PrintJob {
  rate() {
    return 1;
  }
}
class ColorJob extends PrintJob {
  rate() {
    return 3;
  }
}
class BookletJob extends PrintJob {
  constructor(id, pages, copies) {
    super(id, pages, copies, true);
  }
  rate() {
    return 2;
  }
  sheets() {
    return Math.floor(this.pages / 4) * this.copies;
  }
  quote() {
    return super.quote() + 10;
  }
}
class Spooler {
  constructor() {
    this.jobs = [];
    this.printed = 0;
  }
  submit(x) {
    if (this.jobs.some((y) => y.ident === x.ident))
      throw new Error("duplicate id");
    this.jobs.push(x);
  }
  find(id) {
    const x = this.jobs.find((x) => x.ident === id);
    if (!x) throw new Error("unknown job");
    return x;
  }
  cancel(id) {
    const x = this.find(id);
    if (x.status !== "QUEUED") throw new Error("not queued");
    x.status = "QUEUED";
  }
  process() {
    for (const x of [...this.jobs].reverse()) {
      if (x.status === "QUEUED") {
        x.status = "PRINTED";
        this.printed += x.sheets();
        return x.ident;
      }
    }
    throw new Error("empty queue");
  }
  pending() {
    return this.jobs.filter((x) => x.status === "QUEUED").length;
  }
  sheetsPrinted() {
    return this.printed;
  }
  status(id) {
    return this.find(id).status;
  }
}
module.exports = { PrintJob, MonoJob, ColorJob, BookletJob, Spooler };
