const { PrintJob, MonoJob, ColorJob, BookletJob, Spooler } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function raises(fn) {
  try {
    fn();
  } catch (e) {
    if (e instanceof Error) return;
    throw e;
  }
  throw new Error("expected rejection");
}

function tc1() {
  let s = new Spooler();
  raises(() => s.cancel("missing"));
  raises(() => s.submit(new MonoJob("BAD", 0, 1, false)));
  eq(0, s.pending());
}

function tc2() {
  let x = new MonoJob("P1", 5, 2, true);
  eq(6, x.sheets());
}

function tc3() {
  let x = new ColorJob("P2", 3, 1, false);
  eq(15, x.quote());
}

function tc4() {
  let x = new BookletJob("P3", 5, 1);
  eq(2, x.sheets());
}

function tc5() {
  let x = new MonoJob("P4", 4, 2, true);
  eq(8, x.quote());
}

function tc6() {
  let x = new BookletJob("P5", 4, 2);
  eq(36, x.quote());
}

function tc7() {
  let s = new Spooler();
  s.submit(new MonoJob("FIRST", 2, 1, false));
  s.submit(new MonoJob("SECOND", 2, 1, false));
  eq("FIRST", s.process());
  eq("PRINTED", s.status("FIRST"));
  eq(1, s.pending());
}

function tc8() {
  let s = new Spooler();
  s.submit(new MonoJob("CANCEL", 2, 1, false));
  s.cancel("CANCEL");
  eq("CANCELLED", s.status("CANCEL"));
  eq(0, s.pending());
  raises(() => s.process());
  eq(0, s.sheetsPrinted());
}

function tc9() {
  let s = new Spooler();
  let x = new MonoJob("KEEP", 3, 1, false);
  s.submit(x);
  raises(() => s.submit(new MonoJob("KEEP", 9, 1, false)));
  eq(3, x.quote());
  eq(3, x.quote());
  eq(1, s.pending());
}

function tc10() {
  throw new Error(
    "Queue Mono SKIP (3 pages,1 simplex copy), Booklet BOOK (7 pages,2 copies), then Mono LAST (1 page,1 simplex copy). Cancel SKIP. Assert first process returns BOOK, printed sheets4 and pending1. Reject cancellation of BOOK and preserve sheets4. Process LAST, assert total sheets5, then reject empty processing.",
  );
}

let passed = 0;
try {
  tc1();
  passed++;
  console.log("TC1 PASS: Invalid job and unknown cancellation");
} catch (e) {
  console.log("TC1 FAIL: Invalid job and unknown cancellation: " + e.message);
}
try {
  tc2();
  passed++;
  console.log("TC2 PASS: Odd duplex page count per copy");
} catch (e) {
  console.log("TC2 FAIL: Odd duplex page count per copy: " + e.message);
}
try {
  tc3();
  passed++;
  console.log("TC3 PASS: Color rate override");
} catch (e) {
  console.log("TC3 FAIL: Color rate override: " + e.message);
}
try {
  tc4();
  passed++;
  console.log("TC4 PASS: Booklet folding sheet ceiling");
} catch (e) {
  console.log("TC4 FAIL: Booklet folding sheet ceiling: " + e.message);
}
try {
  tc5();
  passed++;
  console.log("TC5 PASS: Charge content pages not sheets");
} catch (e) {
  console.log("TC5 FAIL: Charge content pages not sheets: " + e.message);
}
try {
  tc6();
  passed++;
  console.log("TC6 PASS: Booklet binding per copy");
} catch (e) {
  console.log("TC6 FAIL: Booklet binding per copy: " + e.message);
}
try {
  tc7();
  passed++;
  console.log("TC7 PASS: FIFO processing order");
} catch (e) {
  console.log("TC7 FAIL: FIFO processing order: " + e.message);
}
try {
  tc8();
  passed++;
  console.log("TC8 PASS: Cancel changes queue state");
} catch (e) {
  console.log("TC8 FAIL: Cancel changes queue state: " + e.message);
}
try {
  tc9();
  passed++;
  console.log("TC9 PASS: Duplicate protection and pure quote");
} catch (e) {
  console.log("TC9 FAIL: Duplicate protection and pure quote: " + e.message);
}
try {
  tc10();
  passed++;
  console.log("TC10 PASS: Skip cancelled job and account booklet sheets");
} catch (e) {
  console.log(
    "TC10 FAIL: Skip cancelled job and account booklet sheets: " + e.message,
  );
}
console.log(`SUMMARY ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
