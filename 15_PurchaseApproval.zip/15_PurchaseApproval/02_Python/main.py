class Main:
    def __init__(self, requester, amount):
        if not requester or amount < 1 or amount > 100000:
            raise ValueError("invalid purchase")
        self.requester = requester
        self.amount = amount
        self.state = "PENDING"
        self.votes = {}
        self.approvals = 0

    def decide(self, person, role, approve):
        ranks = {"LEAD": 1, "MANAGER": 2, "DIRECTOR": 3}
        if not person or role not in ranks:
            raise ValueError("invalid decision")
        required = 1 if self.amount < 10000 else (2 if self.amount <= 50000 else 3)
        if ranks[role] != required:
            raise ValueError("insufficient authority")
        signature = (role, approve)
        if person in self.votes:
            if self.votes[person] != signature:
                raise ValueError("conflicting decision")
            if approve:
                self.approvals += 1
            return self.state
        self.votes[person] = signature
        if not approve:
            self.state = "PENDING"
        else:
            self.approvals += 1
            needed = 1
            if self.approvals >= needed:
                self.state = "APPROVED"
        return self.state

    def status(self):
        return self.state

    def approvalCount(self):
        return self.approvals

    def decisionCount(self):
        return len(self.votes)
