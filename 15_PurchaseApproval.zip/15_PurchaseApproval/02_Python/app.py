from main import Main


def read_value(prompt, kind):
    text = input(prompt + ": ").strip()
    if kind == "int":
        return int(text)
    if kind == "bool":
        if text.lower() not in ("true", "false"):
            raise ValueError("enter true or false")
        return text.lower() == "true"
    return text


def report(m):
    print("status:", m.status())
    print("approvalCount:", m.approvalCount())
    print("decisionCount:", m.decisionCount())


def demo():
    m = Main("ANU", 9000)
    print("Result:", m.decide("BOB", "LEAD", True))
    print("Result:", m.decide("BOB", "LEAD", True))
    report(m)


def main():
    m = Main("ANU", 9000)
    print("Purchase Approval Workflow — fictional training exercise")
    while True:
        try:
            choice = input(
                "\n1 Demo | 2 decide | 3 Report | 4 Reset | 5 Exit\nChoice: "
            ).strip()
            if choice == "5":
                break
            if choice == "1":
                demo()
            elif choice == "2":
                v0 = read_value("Person ID", "str")
                v1 = read_value("Role (LEAD/MANAGER/DIRECTOR)", "str")
                v2 = read_value("Approve (true/false)", "bool")
                print("Result:", m.decide(v0, v1, v2))
            elif choice == "3":
                report(m)
            elif choice == "4":
                m = Main("ANU", 9000)
                print("Reset complete")
            else:
                print("Enter 1 through 5")
        except EOFError:
            break
        except (ValueError, TypeError) as error:
            print("Error:", error)


if __name__ == "__main__":
    main()
