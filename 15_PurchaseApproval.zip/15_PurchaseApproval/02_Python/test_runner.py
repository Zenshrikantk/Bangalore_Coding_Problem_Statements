from main import Main


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    m = Main("ANU", 9000)
    eq("APPROVED", m.decide("BOB", "LEAD", True))
    eq(1, m.approvalCount())


def tc2():
    m = Main("ANU", 9000)
    rejects(lambda: m.decide("BOB", "INTERN", True))
    eq(0, m.decisionCount())


def tc3():
    m = Main("ANU", 10000)
    eq("APPROVED", m.decide("BOB", "LEAD", True))


def tc4():
    m = Main("ANU", 9000)
    eq("APPROVED", m.decide("BOB", "DIRECTOR", True))


def tc5():
    m = Main("ANU", 9000)
    rejects(lambda: m.decide("ANU", "LEAD", True))
    eq("PENDING", m.status())


def tc6():
    m = Main("ANU", 60000)
    eq("PENDING", m.decide("BOB", "DIRECTOR", True))
    eq(1, m.approvalCount())


def tc7():
    m = Main("ANU", 60000)
    eq("PENDING", m.decide("BOB", "DIRECTOR", True))
    eq("PENDING", m.decide("BOB", "DIRECTOR", True))
    eq(1, m.approvalCount())


def tc8():
    m = Main("ANU", 9000)
    eq("REJECTED", m.decide("BOB", "LEAD", False))
    eq("REJECTED", m.status())


def tc9():
    m = Main("ANU", 9000)
    eq("APPROVED", m.decide("BOB", "LEAD", True))
    rejects(lambda: m.decide("CYRA", "LEAD", False))
    eq("APPROVED", m.status())


def tc10():
    # Start Main(ANU, 50001). decide(BOB, DIRECTOR, True) must return PENDING; decide(BOB, DIRECTOR, True) must return PENDING; decide(CYRA, MANAGER, True) must reject; decide(ANU, DIRECTOR, True) must reject; decide(CYRA, DIRECTOR, True) must return APPROVED; decide(BOB, DIRECTOR, True) must return APPROVED; approvalCount() must return 2; decisionCount() must return 2. Verify state using explicit expected values.
    raise AssertionError("Implement TC10 with independent expected values")


if __name__ == "__main__":
    passed = 0
    for i, test in enumerate([tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10], 1):
        try:
            test()
            passed += 1
            print(f"TC{i}: PASS")
        except Exception as error:
            print(f"TC{i}: FAIL ({error})")
    print(f"SUMMARY: {passed}/10 PASS; {10-passed} FAIL")
    raise SystemExit(0 if passed == 10 else 1)
