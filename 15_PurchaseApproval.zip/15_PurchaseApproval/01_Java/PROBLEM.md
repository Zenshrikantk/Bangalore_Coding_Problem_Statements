# 15 · Purchase Approval Workflow

Track: Policy · Difficulty: Intermediate · Suggested time: 90–120 minutes

Repair a purchase decision workflow with role thresholds, separation of duties, duplicate votes and final states.

This is a fictional training policy, not a real commercial or employment rule. The starter runs but deliberately violates this specification. Diagnose the failures, repair the business logic and implement TC10.

## API and data model

`Main(requester, amount)` owns the ledger and its receipt records. Public method names are identical across the three languages. The primary operation is `decide(Person ID, Role (LEAD/MANAGER/DIRECTOR), Approve (true/false))`. Read-only methods are `status()`, `approvalCount()`, `decisionCount()`.

Java rejects invalid operations with `IllegalArgumentException`, Python with `ValueError`, and JavaScript with `Error`. Tests use integer values, strings and booleans of the declared types; fractional numbers and cross-type coercions are out of scope. No database, network, clock or concurrent access is needed.

## Authoritative rules

1. Main(requester, amount) accepts a nonempty requester ID and amount 1–100000 integer training credits. Every new request starts PENDING. IDs are case-sensitive nonempty strings.
2. decide(person, role, approve) records an approval (true) or rejection (false). Roles are exactly LEAD, MANAGER, DIRECTOR, ordered from least to most senior.
3. For amounts <= 10000, LEAD or higher may decide; for 10001–50000, MANAGER or higher; for 50001–100000, DIRECTOR only. Exact thresholds belong to the lower band.
4. An eligible rejection immediately makes the request REJECTED. An eligible approval completes a request <= 50000 immediately. A request > 50000 requires approvals from two distinct directors.
5. The requester cannot approve or reject their own request. Validate person and role, self-decision and role eligibility before considering a new vote. Invalid decisions do not change state.
6. A repeated decision by an existing person with the same role and approve flag is idempotent and returns the current status. Changed role or decision under the same person is a conflict. The same person never counts twice.
7. After APPROVED or REJECTED, exact repeats remain valid but a decision from a new person is rejected. status() returns PENDING/APPROVED/REJECTED; approvalCount() counts unique approving people; decisionCount() counts all unique recorded people.

## Worked examples

- **Input:** ANU requests 60000; director BOB approves; BOB repeats. **Expected:** PENDING; approval count 1. The same director cannot satisfy both required approvals.
- **Input:** Director CYRA then approves; BOB repeats again. **Expected:** APPROVED; approval count 2; repeated call returns APPROVED. Two distinct directors satisfy the high-value rule; replay returns current state.

## Supplied tests

Every test creates a fresh instance. Test fixtures are explicit in each runner.

| Case | Purpose | Required outcome |
|---|---|---|
| TC1 | Ordinary lead approval | Approved with one eligible lead |
| TC2 | Unknown role | Unknown role rejected |
| TC3 | Exact lower-band threshold | 10000 is within lead authority |
| TC4 | Senior role substitution | Director can decide a low-value purchase |
| TC5 | No self-decision | Requester cannot approve |
| TC6 | Dual approval required | One director leaves high-value purchase pending |
| TC7 | Duplicate voter | Repeated director is counted once |
| TC8 | Rejection finalizes | Eligible rejection closes request |
| TC9 | Closed workflow rejects new person | A new decision cannot reopen approved request |

## TC10 — candidate-owned test

Start Main(ANU, 50001). decide(BOB, DIRECTOR, True) must return PENDING; decide(BOB, DIRECTOR, True) must return PENDING; decide(CYRA, MANAGER, True) must reject; decide(ANU, DIRECTOR, True) must reject; decide(CYRA, DIRECTOR, True) must return APPROVED; decide(BOB, DIRECTOR, True) must return APPROVED; approvalCount() must return 2; decisionCount() must return 2. Verify state using explicit expected values.

Expected final result: **Exactly two unique approvals; invalid role and self-decision leave no trace; old vote returns APPROVED**. Replace only the TC10 stub with real assertions; do not call the implementation to derive expected values.

## Run

Choose one language folder. Each folder contains this complete statement as `PROBLEM.md`, the business implementation, a test runner and a console app. No third-party dependencies are needed.

### Java

From `01_Java`:

```sh
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

### Python

From `02_Python`:

```sh
python3 test_runner.py
python3 app.py
```

### JavaScript

From `03_JavaScript`:

```sh
node test_runner.js
node app.js
```

Use a working JDK 17+ for Java, Python 3.8+ or Node.js 18+. The test runner always attempts all ten cases and exits nonzero if any fail. A repaired application with an unfinished TC10 should report 9/10; complete work reports 10/10.

## Console workflow

The console starts with `Main(ANU, 9000)`. Option 1 runs an isolated demonstration; option 2 accepts user values for `decide`; option 3 reports the current instance; option 4 resets it; option 5 exits. The demo does not change your working instance. Invalid input prints an error and returns to the menu.

## Deliverables

1. Record the initial results and a concise root-cause log.
2. Fix business code while preserving the public methods and supplied TC1–TC9 assertions.
3. Complete TC10, reach ten passing cases and demonstrate the console with an independent example.
4. Explain each repair and its boundary cases; do not hard-code fixture answers or disable tests.

## Discussion

- Why can a director approve a small purchase?
- Should changing an approval to a rejection be a retry?
- Why keep an exact repeat valid after closure?
