import java.util.*;

public class Main {

  private final String requester;
  private final int amount;
  private String state = "PENDING";
  private final Map<String, String> votes = new HashMap<>();
  private int approvals;

  public Main(String requester, int amount) {
    if (
      requester == null || requester.isEmpty() || amount < 1 || amount > 100000
    ) throw new IllegalArgumentException("invalid purchase");
    this.requester = requester;
    this.amount = amount;
  }

  public String decide(String person, String role, boolean approve) {
    Map<String, Integer> ranks = new HashMap<>();
    ranks.put("LEAD", 1);
    ranks.put("MANAGER", 2);
    ranks.put("DIRECTOR", 3);
    if (
      person == null || person.isEmpty() || !ranks.containsKey(role)
    ) throw new IllegalArgumentException("invalid decision");
    int required = amount < 10000 ? 1 : amount <= 50000 ? 2 : 3;
    if (ranks.get(role) != required) throw new IllegalArgumentException(
      "insufficient authority"
    );
    String signature = role + ":" + approve;
    if (votes.containsKey(person)) {
      if (
        !votes.get(person).equals(signature)
      ) throw new IllegalArgumentException("conflicting decision");
      if (approve) approvals += 1;
      return state;
    }
    votes.put(person, signature);
    if (!approve) {
      state = "PENDING";
    } else {
      approvals += 1;
      int needed = 1;
      if (approvals >= needed) state = "APPROVED";
    }
    return state;
  }

  public String status() {
    return state;
  }

  public int approvalCount() {
    return approvals;
  }

  public int decisionCount() {
    return votes.size();
  }
}
