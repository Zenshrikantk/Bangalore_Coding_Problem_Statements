import java.util.*;

public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!Objects.equals(expected, actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void rejects(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException error) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Main m = new Main("ANU", 9000);
    eq("APPROVED", m.decide("BOB", "LEAD", true));
    eq(1, m.approvalCount());
  }

  static void tc2() {
    Main m = new Main("ANU", 9000);
    rejects(() -> m.decide("BOB", "INTERN", true));
    eq(0, m.decisionCount());
  }

  static void tc3() {
    Main m = new Main("ANU", 10000);
    eq("APPROVED", m.decide("BOB", "LEAD", true));
  }

  static void tc4() {
    Main m = new Main("ANU", 9000);
    eq("APPROVED", m.decide("BOB", "DIRECTOR", true));
  }

  static void tc5() {
    Main m = new Main("ANU", 9000);
    rejects(() -> m.decide("ANU", "LEAD", true));
    eq("PENDING", m.status());
  }

  static void tc6() {
    Main m = new Main("ANU", 60000);
    eq("PENDING", m.decide("BOB", "DIRECTOR", true));
    eq(1, m.approvalCount());
  }

  static void tc7() {
    Main m = new Main("ANU", 60000);
    eq("PENDING", m.decide("BOB", "DIRECTOR", true));
    eq("PENDING", m.decide("BOB", "DIRECTOR", true));
    eq(1, m.approvalCount());
  }

  static void tc8() {
    Main m = new Main("ANU", 9000);
    eq("REJECTED", m.decide("BOB", "LEAD", false));
    eq("REJECTED", m.status());
  }

  static void tc9() {
    Main m = new Main("ANU", 9000);
    eq("APPROVED", m.decide("BOB", "LEAD", true));
    rejects(() -> m.decide("CYRA", "LEAD", false));
    eq("APPROVED", m.status());
  }

  static void tc10() {
    // Start Main(ANU, 50001). decide(BOB, DIRECTOR, True) must return PENDING; decide(BOB, DIRECTOR, True) must return PENDING; decide(CYRA, MANAGER, True) must reject; decide(ANU, DIRECTOR, True) must reject; decide(CYRA, DIRECTOR, True) must return APPROVED; decide(BOB, DIRECTOR, True) must return APPROVED; approvalCount() must return 2; decisionCount() must return 2. Verify state using explicit expected values.
    throw new AssertionError("Implement TC10 with independent expected values");
  }

  public static void main(String[] args) {
    Runnable[] tests = {
      TestRunner::tc1,
      TestRunner::tc2,
      TestRunner::tc3,
      TestRunner::tc4,
      TestRunner::tc5,
      TestRunner::tc6,
      TestRunner::tc7,
      TestRunner::tc8,
      TestRunner::tc9,
      TestRunner::tc10,
    };
    int passed = 0;
    for (int i = 0; i < tests.length; i++) {
      try {
        tests[i].run();
        passed++;
        System.out.println("TC" + (i + 1) + ": PASS");
      } catch (Exception | AssertionError error) {
        System.out.println(
          "TC" + (i + 1) + ": FAIL (" + error.getMessage() + ")"
        );
      }
    }
    System.out.println(
      "SUMMARY: " + passed + "/10 PASS; " + (10 - passed) + " FAIL"
    );
    if (passed != 10) System.exit(1);
  }
}
