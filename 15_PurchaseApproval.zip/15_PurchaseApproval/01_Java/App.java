import java.util.*;

public class App {

  static final Scanner input = new Scanner(System.in);

  static String read(String prompt) {
    System.out.print(prompt + ": ");
    return input.nextLine().trim();
  }

  static int number(String prompt) {
    return Integer.parseInt(read(prompt));
  }

  static boolean bool(String prompt) {
    String s = read(prompt).toLowerCase(Locale.ROOT);
    if (
      !s.equals("true") && !s.equals("false")
    ) throw new IllegalArgumentException("enter true or false");
    return Boolean.parseBoolean(s);
  }

  static void report(Main m) {
    System.out.println("status: " + m.status());
    System.out.println("approvalCount: " + m.approvalCount());
    System.out.println("decisionCount: " + m.decisionCount());
  }

  static void demo() {
    Main m = new Main("ANU", 9000);
    System.out.println("Result: " + m.decide("BOB", "LEAD", true));
    System.out.println("Result: " + m.decide("BOB", "LEAD", true));
    report(m);
  }

  public static void main(String[] args) {
    Main m = new Main("ANU", 9000);
    System.out.println(
      "Purchase Approval Workflow — fictional training exercise"
    );
    while (true) {
      try {
        String choice = read(
          "\n1 Demo | 2 decide | 3 Report | 4 Reset | 5 Exit\nChoice"
        );
        if (choice.equals("5")) break;
        if (choice.equals("1")) demo();
        else if (choice.equals("2")) {
          String v0 = read("Person ID");
          String v1 = read("Role (LEAD/MANAGER/DIRECTOR)");
          boolean v2 = bool("Approve (true/false)");
          System.out.println("Result: " + m.decide(v0, v1, v2));
        } else if (choice.equals("3")) report(m);
        else if (choice.equals("4")) {
          m = new Main("ANU", 9000);
          System.out.println("Reset complete");
        } else System.out.println("Enter 1 through 5");
      } catch (NoSuchElementException error) {
        break;
      } catch (IllegalArgumentException error) {
        System.out.println("Error: " + error.getMessage());
      }
    }
  }
}
