class Main {
  constructor(requester, amount) {
    if (!requester || amount < 1 || amount > 100000)
      throw new Error("invalid purchase");
    this.requester = requester;
    this.amount = amount;
    this.state = "PENDING";
    this.votes = new Map();
    this.approvals = 0;
  }
  decide(person, role, approve) {
    const ranks = new Map([
      ["LEAD", 1],
      ["MANAGER", 2],
      ["DIRECTOR", 3],
    ]);
    if (!person || !ranks.has(role)) throw new Error("invalid decision");
    const required = this.amount < 10000 ? 1 : this.amount <= 50000 ? 2 : 3;
    if (ranks.get(role) !== required) throw new Error("insufficient authority");
    const signature = JSON.stringify([role, approve]);
    if (this.votes.has(person)) {
      if (this.votes.get(person) !== signature)
        throw new Error("conflicting decision");
      if (approve) this.approvals += 1;
      return this.state;
    }
    this.votes.set(person, signature);
    if (!approve) {
      this.state = "PENDING";
    } else {
      this.approvals += 1;
      const needed = 1;
      if (this.approvals >= needed) this.state = "APPROVED";
    }
    return this.state;
  }
  status() {
    return this.state;
  }
  approvalCount() {
    return this.approvals;
  }
  decisionCount() {
    return this.votes.size;
  }
}
module.exports = { Main };
