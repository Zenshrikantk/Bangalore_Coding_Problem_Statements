const { Main } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function rejects(fn) {
  try {
    fn();
  } catch (error) {
    if (error instanceof Error) return;
    throw error;
  }
  throw new Error("expected Error");
}
function tc1() {
  const m = new Main("ANU", 9000);
  eq("APPROVED", m.decide("BOB", "LEAD", true));
  eq(1, m.approvalCount());
}
function tc2() {
  const m = new Main("ANU", 9000);
  rejects(() => m.decide("BOB", "INTERN", true));
  eq(0, m.decisionCount());
}
function tc3() {
  const m = new Main("ANU", 10000);
  eq("APPROVED", m.decide("BOB", "LEAD", true));
}
function tc4() {
  const m = new Main("ANU", 9000);
  eq("APPROVED", m.decide("BOB", "DIRECTOR", true));
}
function tc5() {
  const m = new Main("ANU", 9000);
  rejects(() => m.decide("ANU", "LEAD", true));
  eq("PENDING", m.status());
}
function tc6() {
  const m = new Main("ANU", 60000);
  eq("PENDING", m.decide("BOB", "DIRECTOR", true));
  eq(1, m.approvalCount());
}
function tc7() {
  const m = new Main("ANU", 60000);
  eq("PENDING", m.decide("BOB", "DIRECTOR", true));
  eq("PENDING", m.decide("BOB", "DIRECTOR", true));
  eq(1, m.approvalCount());
}
function tc8() {
  const m = new Main("ANU", 9000);
  eq("REJECTED", m.decide("BOB", "LEAD", false));
  eq("REJECTED", m.status());
}
function tc9() {
  const m = new Main("ANU", 9000);
  eq("APPROVED", m.decide("BOB", "LEAD", true));
  rejects(() => m.decide("CYRA", "LEAD", false));
  eq("APPROVED", m.status());
}
function tc10() {
  // Start Main(ANU, 50001). decide(BOB, DIRECTOR, True) must return PENDING; decide(BOB, DIRECTOR, True) must return PENDING; decide(CYRA, MANAGER, True) must reject; decide(ANU, DIRECTOR, True) must reject; decide(CYRA, DIRECTOR, True) must return APPROVED; decide(BOB, DIRECTOR, True) must return APPROVED; approvalCount() must return 2; decisionCount() must return 2. Verify state using explicit expected values.
  throw new Error("Implement TC10 with independent expected values");
}
let passed = 0;
[tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10].forEach((test, index) => {
  try {
    test();
    passed++;
    console.log(`TC${index + 1}: PASS`);
  } catch (error) {
    console.log(`TC${index + 1}: FAIL (${error.message})`);
  }
});
console.log(`SUMMARY: ${passed}/10 PASS; ${10 - passed} FAIL`);
process.exitCode = passed === 10 ? 0 : 1;
