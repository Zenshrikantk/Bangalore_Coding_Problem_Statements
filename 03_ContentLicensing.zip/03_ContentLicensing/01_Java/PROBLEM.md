# Digital Content Licensing Debugging Challenge

**Track:** OOP · **Difficulty:** Intermediate · **Suggested time:** 90–120 minutes

Repair a content player whose license subtypes confuse expiry, lifetime play quotas and aggregated remaining access.

This is a deliberately defective, dependency-free console application. Diagnose the defects, repair business code, and implement TC10. The rules below are authoritative; source code may disagree. Policies are fictional training rules.

## Model and public API

Abstract `License(id,start,used=0)` with Trial/Standard/Premium subclasses; Java provides two-argument and three-argument constructors. `duration()`, `quota()`, `valid(day)`, `canPlay(day)`, `play(day)`, `remaining(day)`, `plays()`. `Catalogue.add`, `play(id,day)`, `remaining(id,day)`, `totalRemaining(day)`, `count()`. `play` returns total successful plays used, not remaining.

## Rules and boundaries

- IDs nonempty/case-sensitive/unique per Catalogue. Start days are integers 0–10000; query/play days 0–20000. Initial used count is 0..quota; optional used supports importing an existing license. At most 1000 licenses.
- Trial duration=3 days, quota=2; Standard duration=7, quota=5; Premium duration=30, quota=10. Quotas are lifetime totals with no daily reset.
- A license is time-valid exactly when start <= day < start + duration. Expiry day itself is excluded. Querying a before-start or expired day is allowed and reports unavailable.
- canPlay requires time validity and used < quota. play rejects if unavailable; success increases used exactly once and returns the new used count. A failed play does not change used.
- remaining(day) is zero outside the validity interval; otherwise max(0,quota-used). totalRemaining sums subtype-aware remaining values, excluding expired/not-started licenses.
- Duplicate add rejects without replacing an existing license. Unknown IDs reject before play. Each accepted play is a distinct consumption; repeated valid calls are not idempotent.
- Bad domain values raise ValueError / Error / IllegalArgumentException. Direct construction of abstract License is outside the contract; use concrete subtypes.

## Worked examples

- **Trial starting day 5, used 0; play at 5 then 7** → **used becomes 1 then 2; remaining=0**. Both days are within [5,8), but the quota is now exhausted.
- **Premium starting day 0, used 3; query day 20 then day 30** → **7 remaining, then 0**. Premium runs for 30 days and excludes its expiry day.

## Supplied tests

| Case | Coverage | Expected outcome |
|---|---|---|
| TC1 | Unknown license rejects | Unknown ID rejects and catalogue stays empty. |
| TC2 | Exclusive expiry boundary | Trial start10 valid12, invalid13; play13 rejects. |
| TC3 | Standard quota override | Fresh Standard has five remaining. |
| TC4 | Premium duration override | Premium valid at20, invalid at30. |
| TC5 | Successful play consumes allowance | First play returns1, used1, remaining1. |
| TC6 | Exact exhausted quota rejects | Initial used2 Trial cannot play; count unchanged. |
| TC7 | Before-start access rejected | Day9 rejected for start10; used remains0. |
| TC8 | Duplicate ID preserves catalogue | Duplicate rejects and count stays1. |
| TC9 | Mixed active remaining quota | Trial2 + Standard5 + Premium10 =17. |

## TC10 — candidate-owned test

Create a TrialLicense starting day 5. Play at days 5 and 7, asserting used counts 1 and 2. Assert zero remaining at day 7, reject a third play at day 7, and preserve used=2. Assert day 8 is invalid, reject that play, and preserve used=2 again.

Replace the deliberately failing stub with meaningful assertions. Retain TC1–TC9 unchanged. The runner continues after each failure and exits nonzero if any test fails.

## Run locally

Select one language; all three implement the same rules.

```text
Java (01_Java):       javac Main.java TestRunner.java App.java
                     java TestRunner
                     java App
Python (02_Python):   python3 test_runner.py
                     python3 app.py
Node (03_JavaScript): node test_runner.js
                     node app.js
```

Requires a JDK (Java 11+), Python 3.8+, or Node 16+. No package installation is required. Run from the chosen language directory.

## Candidate deliverables

1. Record the baseline failures and explain each root cause.
2. Repair business logic while preserving the public APIs and the supplied tests.
3. Complete TC10, achieve 10/10, and demonstrate a user-entered console operation.
4. Explain the object model, boundary arithmetic, and complexity. Avoid fixture-specific outputs or disabling assertions.

## Discussion prompts

- Why is expiry modeled as a half-open interval?
- Can inheritance preserve the lifetime-quota invariant?
- Why is used initialized in the constructor?
