public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!expected.equals(actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void raises(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException e) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Catalogue s = new Catalogue();
    raises(() -> s.play("missing", 0));
    eq(0, s.count());
  }

  static void tc2() {
    TrialLicense x = new TrialLicense("L1", 10);
    eq(true, x.valid(12));
    eq(false, x.valid(13));
    raises(() -> x.play(13));
  }

  static void tc3() {
    StandardLicense x = new StandardLicense("L2", 0);
    eq(5, x.remaining(0));
  }

  static void tc4() {
    PremiumLicense x = new PremiumLicense("L3", 0);
    eq(true, x.valid(20));
    eq(false, x.valid(30));
  }

  static void tc5() {
    TrialLicense x = new TrialLicense("L4", 0);
    eq(1, x.play(1));
    eq(1, x.plays());
    eq(1, x.remaining(1));
  }

  static void tc6() {
    TrialLicense x = new TrialLicense("L5", 0, 2);
    eq(false, x.canPlay(1));
    raises(() -> x.play(1));
    eq(2, x.plays());
  }

  static void tc7() {
    TrialLicense x = new TrialLicense("L6", 10);
    eq(false, x.canPlay(9));
    raises(() -> x.play(9));
    eq(0, x.plays());
  }

  static void tc8() {
    Catalogue s = new Catalogue();
    s.add(new TrialLicense("DUP", 0));
    raises(() -> s.add(new TrialLicense("DUP", 0)));
    eq(1, s.count());
  }

  static void tc9() {
    Catalogue s = new Catalogue();
    s.add(new TrialLicense("A", 0));
    s.add(new StandardLicense("B", 0));
    s.add(new PremiumLicense("C", 0));
    eq(17, s.totalRemaining(0));
  }

  static void tc10() {
    throw new AssertionError(
      "Create a TrialLicense starting day 5. Play at days 5 and 7, asserting used counts 1 and 2. Assert zero remaining at day 7, reject a third play at day 7, and preserve used=2. Assert day 8 is invalid, reject that play, and preserve used=2 again."
    );
  }

  public static void main(String[] args) {
    int passed = 0;
    try {
      tc1();
      passed++;
      System.out.println("TC1 PASS: Unknown license rejects");
    } catch (Throwable e) {
      System.out.println(
        "TC1 FAIL: Unknown license rejects: " + e.getMessage()
      );
    }
    try {
      tc2();
      passed++;
      System.out.println("TC2 PASS: Exclusive expiry boundary");
    } catch (Throwable e) {
      System.out.println(
        "TC2 FAIL: Exclusive expiry boundary: " + e.getMessage()
      );
    }
    try {
      tc3();
      passed++;
      System.out.println("TC3 PASS: Standard quota override");
    } catch (Throwable e) {
      System.out.println(
        "TC3 FAIL: Standard quota override: " + e.getMessage()
      );
    }
    try {
      tc4();
      passed++;
      System.out.println("TC4 PASS: Premium duration override");
    } catch (Throwable e) {
      System.out.println(
        "TC4 FAIL: Premium duration override: " + e.getMessage()
      );
    }
    try {
      tc5();
      passed++;
      System.out.println("TC5 PASS: Successful play consumes allowance");
    } catch (Throwable e) {
      System.out.println(
        "TC5 FAIL: Successful play consumes allowance: " + e.getMessage()
      );
    }
    try {
      tc6();
      passed++;
      System.out.println("TC6 PASS: Exact exhausted quota rejects");
    } catch (Throwable e) {
      System.out.println(
        "TC6 FAIL: Exact exhausted quota rejects: " + e.getMessage()
      );
    }
    try {
      tc7();
      passed++;
      System.out.println("TC7 PASS: Before-start access rejected");
    } catch (Throwable e) {
      System.out.println(
        "TC7 FAIL: Before-start access rejected: " + e.getMessage()
      );
    }
    try {
      tc8();
      passed++;
      System.out.println("TC8 PASS: Duplicate ID preserves catalogue");
    } catch (Throwable e) {
      System.out.println(
        "TC8 FAIL: Duplicate ID preserves catalogue: " + e.getMessage()
      );
    }
    try {
      tc9();
      passed++;
      System.out.println("TC9 PASS: Mixed active remaining quota");
    } catch (Throwable e) {
      System.out.println(
        "TC9 FAIL: Mixed active remaining quota: " + e.getMessage()
      );
    }
    try {
      tc10();
      passed++;
      System.out.println("TC10 PASS: Quota and time boundaries together");
    } catch (Throwable e) {
      System.out.println(
        "TC10 FAIL: Quota and time boundaries together: " + e.getMessage()
      );
    }
    System.out.println("SUMMARY " + passed + "/10 PASS");
    if (passed != 10) System.exit(1);
  }
}
