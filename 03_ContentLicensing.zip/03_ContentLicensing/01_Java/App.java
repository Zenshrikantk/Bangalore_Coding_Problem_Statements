import java.util.*;

public class App {

  static Scanner in = new Scanner(System.in);

  static String ask(String p) {
    System.out.print(p);
    if (!in.hasNextLine()) throw new NoSuchElementException();
    return in.nextLine().trim();
  }

  static int number(String p) {
    return Integer.parseInt(ask(p));
  }

  static Catalogue make() {
    Catalogue s = new Catalogue();
    s.add(new TrialLicense("TRIAL", 0));
    s.add(new StandardLicense("STANDARD", 0));
    s.add(new PremiumLicense("PREMIUM", 0));
    return s;
  }

  public static void main(String[] args) {
    Catalogue state = make();
    while (true) {
      System.out.println(
        "1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit"
      );
      try {
        String choice = ask("> ");
        if (choice.equals("5")) break;
        switch (choice) {
          case "1": {
            TrialLicense x = new TrialLicense("DEMO", 5);
            System.out.println(
              "First play: " + x.play(5) + " Remaining: " + x.remaining(5)
            );
            break;
          }
          case "2": {
            String id = ask("License TRIAL/STANDARD/PREMIUM: ");
            int day = number("Day: ");
            System.out.println("Total used: " + state.play(id, day));
            break;
          }
          case "3": {
            int day = number("Report day: ");
            System.out.println("Available plays: " + state.totalRemaining(day));
            break;
          }
          case "4": {
            state = make();
            System.out.println(
              "Reset creates three licenses starting day 0. Quotas are lifetime totals; days are integer counts."
            );
            break;
          }
          default:
            System.out.println("Choose 1–5");
        }
      } catch (NoSuchElementException e) {
        break;
      } catch (IllegalArgumentException e) {
        System.out.println("Rejected: " + e.getMessage());
      }
    }
  }
}
