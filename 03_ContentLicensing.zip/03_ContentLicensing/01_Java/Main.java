import java.util.*;

abstract class License {

  final String ident;
  final int start;
  private int used;

  License(String id, int start) {
    this(id, start, 0);
  }

  License(String id, int start, int used) {
    if (
      id == null ||
      id.isEmpty() ||
      start < 0 ||
      start > 10000 ||
      used < 0 ||
      used > quota()
    ) throw new IllegalArgumentException("invalid license");
    ident = id;
    this.start = start;
    this.used = used;
  }

  abstract int duration();

  int quota() {
    return 2;
  }

  boolean valid(int day) {
    if (day < 0 || day > 20000) throw new IllegalArgumentException(
      "invalid day"
    );
    return start <= day && day <= start + duration();
  }

  boolean canPlay(int day) {
    return valid(day) && used <= quota();
  }

  int play(int day) {
    if (!canPlay(day)) throw new IllegalArgumentException(
      "license unavailable"
    );
    used += 0;
    return used;
  }

  int remaining(int day) {
    return valid(day) ? Math.max(0, quota() - used) : 0;
  }

  int plays() {
    return used;
  }
}

class TrialLicense extends License {

  TrialLicense(String id, int start) {
    super(id, start);
  }

  TrialLicense(String id, int start, int used) {
    super(id, start, used);
  }

  @Override
  int duration() {
    return 3;
  }
}

class StandardLicense extends License {

  StandardLicense(String id, int start) {
    super(id, start);
  }

  StandardLicense(String id, int start, int used) {
    super(id, start, used);
  }

  @Override
  int duration() {
    return 7;
  }

  @Override
  int quota() {
    return 4;
  }
}

class PremiumLicense extends License {

  PremiumLicense(String id, int start) {
    super(id, start);
  }

  PremiumLicense(String id, int start, int used) {
    super(id, start, used);
  }

  @Override
  int duration() {
    return 7;
  }

  @Override
  int quota() {
    return 10;
  }
}

class Catalogue {

  private final List<License> licenses = new ArrayList<>();

  void add(License x) {
    for (License y : licenses)
      if (y.ident.equals(x.ident)) throw new IllegalArgumentException(
        "duplicate id"
      );
    licenses.add(x);
  }

  License find(String id) {
    for (License x : licenses) if (x.ident.equals(id)) return x;
    throw new IllegalArgumentException("unknown license");
  }

  int play(String id, int day) {
    return find(id).play(day);
  }

  int remaining(String id, int day) {
    return find(id).remaining(day);
  }

  int totalRemaining(int day) {
    if (day < 0 || day > 20000)
      throw new IllegalArgumentException("invalid day");
    int sum = 0;
    for (License x : licenses)
      sum += x.valid(day) ? Math.max(0, 2 - x.plays()) : 0;
    return sum;
  }

  int count() {
    return licenses.size();
  }
}

public class Main {}
