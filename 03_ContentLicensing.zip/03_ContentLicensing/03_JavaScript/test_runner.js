const {
  License,
  TrialLicense,
  StandardLicense,
  PremiumLicense,
  Catalogue,
} = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function raises(fn) {
  try {
    fn();
  } catch (e) {
    if (e instanceof Error) return;
    throw e;
  }
  throw new Error("expected rejection");
}

function tc1() {
  let s = new Catalogue();
  raises(() => s.play("missing", 0));
  eq(0, s.count());
}

function tc2() {
  let x = new TrialLicense("L1", 10);
  eq(true, x.valid(12));
  eq(false, x.valid(13));
  raises(() => x.play(13));
}

function tc3() {
  let x = new StandardLicense("L2", 0);
  eq(5, x.remaining(0));
}

function tc4() {
  let x = new PremiumLicense("L3", 0);
  eq(true, x.valid(20));
  eq(false, x.valid(30));
}

function tc5() {
  let x = new TrialLicense("L4", 0);
  eq(1, x.play(1));
  eq(1, x.plays());
  eq(1, x.remaining(1));
}

function tc6() {
  let x = new TrialLicense("L5", 0, 2);
  eq(false, x.canPlay(1));
  raises(() => x.play(1));
  eq(2, x.plays());
}

function tc7() {
  let x = new TrialLicense("L6", 10);
  eq(false, x.canPlay(9));
  raises(() => x.play(9));
  eq(0, x.plays());
}

function tc8() {
  let s = new Catalogue();
  s.add(new TrialLicense("DUP", 0));
  raises(() => s.add(new TrialLicense("DUP", 0)));
  eq(1, s.count());
}

function tc9() {
  let s = new Catalogue();
  s.add(new TrialLicense("A", 0));
  s.add(new StandardLicense("B", 0));
  s.add(new PremiumLicense("C", 0));
  eq(17, s.totalRemaining(0));
}

function tc10() {
  throw new Error(
    "Create a TrialLicense starting day 5. Play at days 5 and 7, asserting used counts 1 and 2. Assert zero remaining at day 7, reject a third play at day 7, and preserve used=2. Assert day 8 is invalid, reject that play, and preserve used=2 again.",
  );
}

let passed = 0;
try {
  tc1();
  passed++;
  console.log("TC1 PASS: Unknown license rejects");
} catch (e) {
  console.log("TC1 FAIL: Unknown license rejects: " + e.message);
}
try {
  tc2();
  passed++;
  console.log("TC2 PASS: Exclusive expiry boundary");
} catch (e) {
  console.log("TC2 FAIL: Exclusive expiry boundary: " + e.message);
}
try {
  tc3();
  passed++;
  console.log("TC3 PASS: Standard quota override");
} catch (e) {
  console.log("TC3 FAIL: Standard quota override: " + e.message);
}
try {
  tc4();
  passed++;
  console.log("TC4 PASS: Premium duration override");
} catch (e) {
  console.log("TC4 FAIL: Premium duration override: " + e.message);
}
try {
  tc5();
  passed++;
  console.log("TC5 PASS: Successful play consumes allowance");
} catch (e) {
  console.log("TC5 FAIL: Successful play consumes allowance: " + e.message);
}
try {
  tc6();
  passed++;
  console.log("TC6 PASS: Exact exhausted quota rejects");
} catch (e) {
  console.log("TC6 FAIL: Exact exhausted quota rejects: " + e.message);
}
try {
  tc7();
  passed++;
  console.log("TC7 PASS: Before-start access rejected");
} catch (e) {
  console.log("TC7 FAIL: Before-start access rejected: " + e.message);
}
try {
  tc8();
  passed++;
  console.log("TC8 PASS: Duplicate ID preserves catalogue");
} catch (e) {
  console.log("TC8 FAIL: Duplicate ID preserves catalogue: " + e.message);
}
try {
  tc9();
  passed++;
  console.log("TC9 PASS: Mixed active remaining quota");
} catch (e) {
  console.log("TC9 FAIL: Mixed active remaining quota: " + e.message);
}
try {
  tc10();
  passed++;
  console.log("TC10 PASS: Quota and time boundaries together");
} catch (e) {
  console.log("TC10 FAIL: Quota and time boundaries together: " + e.message);
}
console.log(`SUMMARY ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
