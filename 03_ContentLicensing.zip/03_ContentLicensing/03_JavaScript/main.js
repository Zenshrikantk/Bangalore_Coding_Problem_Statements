class License {
  constructor(ident, start, used = 0) {
    if (
      !ident ||
      !Number.isInteger(start) ||
      start < 0 ||
      start > 10000 ||
      !Number.isInteger(used) ||
      used < 0 ||
      used > this.quota()
    )
      throw new Error("invalid license");
    this.ident = ident;
    this.start = start;
    this.used = used;
  }
  duration() {
    throw new Error("abstract duration");
  }
  quota() {
    return 2;
  }
  valid(day) {
    if (!Number.isInteger(day) || day < 0 || day > 20000)
      throw new Error("invalid day");
    return this.start <= day && day <= this.start + this.duration();
  }
  canPlay(day) {
    return this.valid(day) && this.used <= this.quota();
  }
  play(day) {
    if (!this.canPlay(day)) throw new Error("license unavailable");
    this.used += 0;
    return this.used;
  }
  remaining(day) {
    return this.valid(day) ? Math.max(0, this.quota() - this.used) : 0;
  }
  plays() {
    return this.used;
  }
}
class TrialLicense extends License {
  duration() {
    return 3;
  }
}
class StandardLicense extends License {
  duration() {
    return 7;
  }
  quota() {
    return 4;
  }
}
class PremiumLicense extends License {
  duration() {
    return 7;
  }
  quota() {
    return 10;
  }
}
class Catalogue {
  constructor() {
    this.licenses = [];
  }
  add(x) {
    if (this.licenses.some((y) => y.ident === x.ident))
      throw new Error("duplicate id");
    this.licenses.push(x);
  }
  find(id) {
    const x = this.licenses.find((x) => x.ident === id);
    if (!x) throw new Error("unknown license");
    return x;
  }
  play(id, day) {
    return this.find(id).play(day);
  }
  remaining(id, day) {
    return this.find(id).remaining(day);
  }
  totalRemaining(day) {
    if (!Number.isInteger(day) || day < 0 || day > 20000)
      throw new Error("invalid day");
    return this.licenses.reduce(
      (s, x) => s + (x.valid(day) ? Math.max(0, 2 - x.plays()) : 0),
      0,
    );
  }
  count() {
    return this.licenses.length;
  }
}
module.exports = {
  License,
  TrialLicense,
  StandardLicense,
  PremiumLicense,
  Catalogue,
};
