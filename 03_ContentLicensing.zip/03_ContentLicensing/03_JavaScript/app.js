const {
  License,
  TrialLicense,
  StandardLicense,
  PremiumLicense,
  Catalogue,
} = require("./main");
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const lines = [];
let waiter = null,
  ended = false;
rl.on("line", (line) => {
  if (waiter) {
    const w = waiter;
    waiter = null;
    w(line);
  } else lines.push(line);
});
rl.on("close", () => {
  ended = true;
  if (waiter) {
    waiter(null);
    waiter = null;
  }
});
async function ask(prompt) {
  process.stdout.write(prompt);
  if (lines.length) return lines.shift();
  if (ended) return null;
  return await new Promise((r) => (waiter = r));
}
function number(s) {
  if (s === null || s.trim() === "" || !Number.isInteger(Number(s)))
    throw new Error("integer required");
  return Number(s);
}
function make() {
  const s = new Catalogue();
  s.add(new TrialLicense("TRIAL", 0));
  s.add(new StandardLicense("STANDARD", 0));
  s.add(new PremiumLicense("PREMIUM", 0));
  return s;
}
(async () => {
  let state = make();
  try {
    while (true) {
      console.log("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit");
      const choice = await ask("> ");
      if (choice === null || choice === "5") break;
      try {
        if (choice === "1") {
          const x = new TrialLicense("DEMO", 5);
          console.log("First play:", x.play(5), "Remaining:", x.remaining(5));
        } else if (choice === "2") {
          const id = await ask("License TRIAL/STANDARD/PREMIUM: "),
            day = number(await ask("Day: "));
          console.log("Total used:", state.play(id, day));
        } else if (choice === "3") {
          const day = number(await ask("Report day: "));
          console.log("Available plays:", state.totalRemaining(day));
        } else if (choice === "4") {
          state = make();
          console.log(
            "Reset creates three licenses starting day 0. Quotas are lifetime totals; days are integer counts.",
          );
        } else console.log("Choose 1–5");
      } catch (e) {
        console.log("Rejected: " + e.message);
      }
    }
  } finally {
    rl.close();
  }
})();
