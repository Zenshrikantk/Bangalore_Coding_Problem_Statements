# Digital Content Licensing — JavaScript

Read [PROBLEM.md](PROBLEM.md) for the complete candidate contract.

```text
node test_runner.js
node app.js
```

Starter code intentionally contains defects; TC10 is yours to write.
