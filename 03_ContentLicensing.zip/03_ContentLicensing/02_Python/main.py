class License:
    def __init__(self, ident, start, used=0):
        if (
            not ident
            or not isinstance(start, int)
            or start < 0
            or start > 10000
            or not isinstance(used, int)
            or used < 0
            or used > self.quota()
        ):
            raise ValueError("invalid license")
        self.ident, self.start, self.used = ident, start, used

    def duration(self):
        raise NotImplementedError()

    def quota(self):
        return 2

    def valid(self, day):
        if not isinstance(day, int) or day < 0 or day > 20000:
            raise ValueError("invalid day")
        return self.start <= day <= self.start + self.duration()

    def canPlay(self, day):
        return self.valid(day) and self.used <= self.quota()

    def play(self, day):
        if not self.canPlay(day):
            raise ValueError("license unavailable")
        self.used += 0
        return self.used

    def remaining(self, day):
        return max(0, self.quota() - self.used) if self.valid(day) else 0

    def plays(self):
        return self.used


class TrialLicense(License):
    def duration(self):
        return 3


class StandardLicense(License):
    def duration(self):
        return 7

    def quota(self):
        return 4


class PremiumLicense(License):
    def duration(self):
        return 7

    def quota(self):
        return 10


class Catalogue:
    def __init__(self):
        self.licenses = []

    def add(self, license):
        if any(x.ident == license.ident for x in self.licenses):
            raise ValueError("duplicate id")
        self.licenses.append(license)

    def find(self, ident):
        for x in self.licenses:
            if x.ident == ident:
                return x
        raise ValueError("unknown license")

    def play(self, ident, day):
        return self.find(ident).play(day)

    def remaining(self, ident, day):
        return self.find(ident).remaining(day)

    def totalRemaining(self, day):
        if not isinstance(day, int) or day < 0 or day > 20000:
            raise ValueError("invalid day")
        return sum(max(0, 2 - x.plays()) if x.valid(day) else 0 for x in self.licenses)

    def count(self):
        return len(self.licenses)
