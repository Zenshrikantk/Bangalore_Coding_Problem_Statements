from main import *
import sys


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def raises(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    s = Catalogue()
    raises(lambda: s.play("missing", 0))
    eq(0, s.count())


def tc2():
    x = TrialLicense("L1", 10)
    eq(True, x.valid(12))
    eq(False, x.valid(13))
    raises(lambda: x.play(13))


def tc3():
    x = StandardLicense("L2", 0)
    eq(5, x.remaining(0))


def tc4():
    x = PremiumLicense("L3", 0)
    eq(True, x.valid(20))
    eq(False, x.valid(30))


def tc5():
    x = TrialLicense("L4", 0)
    eq(1, x.play(1))
    eq(1, x.plays())
    eq(1, x.remaining(1))


def tc6():
    x = TrialLicense("L5", 0, 2)
    eq(False, x.canPlay(1))
    raises(lambda: x.play(1))
    eq(2, x.plays())


def tc7():
    x = TrialLicense("L6", 10)
    eq(False, x.canPlay(9))
    raises(lambda: x.play(9))
    eq(0, x.plays())


def tc8():
    s = Catalogue()
    s.add(TrialLicense("DUP", 0))
    raises(lambda: s.add(TrialLicense("DUP", 0)))
    eq(1, s.count())


def tc9():
    s = Catalogue()
    s.add(TrialLicense("A", 0))
    s.add(StandardLicense("B", 0))
    s.add(PremiumLicense("C", 0))
    eq(17, s.totalRemaining(0))


def tc10():
    raise AssertionError(
        "Create a TrialLicense starting day 5. Play at days 5 and 7, asserting used counts 1 and 2. Assert zero remaining at day 7, reject a third play at day 7, and preserve used=2. Assert day 8 is invalid, reject that play, and preserve used=2 again."
    )


if __name__ == "__main__":
    passed = 0
    try:
        tc1()
        passed += 1
        print("TC1 PASS: Unknown license rejects")
    except Exception as e:
        print("TC1 FAIL: Unknown license rejects: " + str(e))
    try:
        tc2()
        passed += 1
        print("TC2 PASS: Exclusive expiry boundary")
    except Exception as e:
        print("TC2 FAIL: Exclusive expiry boundary: " + str(e))
    try:
        tc3()
        passed += 1
        print("TC3 PASS: Standard quota override")
    except Exception as e:
        print("TC3 FAIL: Standard quota override: " + str(e))
    try:
        tc4()
        passed += 1
        print("TC4 PASS: Premium duration override")
    except Exception as e:
        print("TC4 FAIL: Premium duration override: " + str(e))
    try:
        tc5()
        passed += 1
        print("TC5 PASS: Successful play consumes allowance")
    except Exception as e:
        print("TC5 FAIL: Successful play consumes allowance: " + str(e))
    try:
        tc6()
        passed += 1
        print("TC6 PASS: Exact exhausted quota rejects")
    except Exception as e:
        print("TC6 FAIL: Exact exhausted quota rejects: " + str(e))
    try:
        tc7()
        passed += 1
        print("TC7 PASS: Before-start access rejected")
    except Exception as e:
        print("TC7 FAIL: Before-start access rejected: " + str(e))
    try:
        tc8()
        passed += 1
        print("TC8 PASS: Duplicate ID preserves catalogue")
    except Exception as e:
        print("TC8 FAIL: Duplicate ID preserves catalogue: " + str(e))
    try:
        tc9()
        passed += 1
        print("TC9 PASS: Mixed active remaining quota")
    except Exception as e:
        print("TC9 FAIL: Mixed active remaining quota: " + str(e))
    try:
        tc10()
        passed += 1
        print("TC10 PASS: Quota and time boundaries together")
    except Exception as e:
        print("TC10 FAIL: Quota and time boundaries together: " + str(e))
    print(f"SUMMARY {passed}/10 PASS")
    sys.exit(0 if passed == 10 else 1)
