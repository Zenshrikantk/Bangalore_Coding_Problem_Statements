from main import *


def make():
    s = Catalogue()
    s.add(TrialLicense("TRIAL", 0))
    s.add(StandardLicense("STANDARD", 0))
    s.add(PremiumLicense("PREMIUM", 0))
    return s


state = make()
while True:
    print("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit")
    try:
        choice = input("> ").strip()
        if choice == "5":
            break
        if choice == "1":
            x = TrialLicense("DEMO", 5)
            print("First play:", x.play(5), "Remaining:", x.remaining(5))
        elif choice == "2":
            ident = input("License TRIAL/STANDARD/PREMIUM: ").strip()
            day = int(input("Day: "))
            print("Total used:", state.play(ident, day))
        elif choice == "3":
            day = int(input("Report day: "))
            print("Available plays:", state.totalRemaining(day))
        elif choice == "4":
            state = make()
            print(
                "Reset creates three licenses starting day 0. Quotas are lifetime totals; days are integer counts."
            )
        else:
            print("Choose 1–5")
    except (EOFError, KeyboardInterrupt):
        break
    except (ValueError, TypeError) as e:
        print("Rejected:", e)
