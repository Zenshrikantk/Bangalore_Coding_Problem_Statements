const { Material, Paper, Glass, Metal, Depot } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function raises(fn) {
  try {
    fn();
  } catch (e) {
    if (e instanceof Error) return;
    throw e;
  }
  throw new Error("expected rejection");
}

function tc1() {
  let s = new Depot();
  raises(() => s.credit("none"));
  raises(() => s.add(new Paper("BAD", 0, 100)));
  eq(0, s.balance());
}

function tc2() {
  let x = new Paper("R1", 2, 90);
  eq(true, x.eligible());
  eq(4, x.points());
}

function tc3() {
  let x = new Glass("R2", 2, 100);
  eq(6, x.points());
}

function tc4() {
  let x = new Metal("R3", 2, 85);
  eq(10, x.points());
}

function tc5() {
  let x = new Paper("R4", 10, 100);
  eq(22, x.points());
}

function tc6() {
  let x = new Metal("R5", 11, 100);
  eq(60, x.points());
}

function tc7() {
  let s = new Depot();
  s.add(new Paper("R6", 2, 50));
  raises(() => s.credit("R6"));
  eq(0, s.balance());
  eq(0, s.creditedCount());
}

function tc8() {
  let s = new Depot();
  s.add(new Paper("R7", 2, 100));
  eq(4, s.credit("R7"));
  raises(() => s.credit("R7"));
  eq(4, s.balance());
  eq(1, s.creditedCount());
}

function tc9() {
  let s = new Depot();
  s.add(new Paper("A", 2, 100));
  s.add(new Paper("B", 3, 100));
  eq(4, s.credit("A"));
  eq(6, s.credit("B"));
  eq(10, s.balance());
  eq(2, s.creditedCount());
}

function tc10() {
  throw new Error(
    "Add Metal MX (11kg,purity80) and Glass GX (10kg,purity95). Credit them for60 and33; assert balance93 and creditedCount2. Retry MX, assert rejection and unchanged balance93/count2.",
  );
}

let passed = 0;
try {
  tc1();
  passed++;
  console.log("TC1 PASS: Unknown material and invalid quantities");
} catch (e) {
  console.log(
    "TC1 FAIL: Unknown material and invalid quantities: " + e.message,
  );
}
try {
  tc2();
  passed++;
  console.log("TC2 PASS: Inclusive purity threshold");
} catch (e) {
  console.log("TC2 FAIL: Inclusive purity threshold: " + e.message);
}
try {
  tc3();
  passed++;
  console.log("TC3 PASS: Glass rate override");
} catch (e) {
  console.log("TC3 FAIL: Glass rate override: " + e.message);
}
try {
  tc4();
  passed++;
  console.log("TC4 PASS: Metal purity override");
} catch (e) {
  console.log("TC4 FAIL: Metal purity override: " + e.message);
}
try {
  tc5();
  passed++;
  console.log("TC5 PASS: Bulk threshold at ten kilograms");
} catch (e) {
  console.log("TC5 FAIL: Bulk threshold at ten kilograms: " + e.message);
}
try {
  tc6();
  passed++;
  console.log("TC6 PASS: Bulk bonus rounds down");
} catch (e) {
  console.log("TC6 FAIL: Bulk bonus rounds down: " + e.message);
}
try {
  tc7();
  passed++;
  console.log("TC7 PASS: Rejected purity preserves ledger");
} catch (e) {
  console.log("TC7 FAIL: Rejected purity preserves ledger: " + e.message);
}
try {
  tc8();
  passed++;
  console.log("TC8 PASS: Repeated credit rejected");
} catch (e) {
  console.log("TC8 FAIL: Repeated credit rejected: " + e.message);
}
try {
  tc9();
  passed++;
  console.log("TC9 PASS: Ledger accumulates multiple credits");
} catch (e) {
  console.log("TC9 FAIL: Ledger accumulates multiple credits: " + e.message);
}
try {
  tc10();
  passed++;
  console.log("TC10 PASS: Mixed thresholds, bonus and retry");
} catch (e) {
  console.log("TC10 FAIL: Mixed thresholds, bonus and retry: " + e.message);
}
console.log(`SUMMARY ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
