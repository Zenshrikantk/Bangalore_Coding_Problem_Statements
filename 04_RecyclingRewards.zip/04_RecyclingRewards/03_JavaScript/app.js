const { Material, Paper, Glass, Metal, Depot } = require("./main");
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const lines = [];
let waiter = null,
  ended = false;
rl.on("line", (line) => {
  if (waiter) {
    const w = waiter;
    waiter = null;
    w(line);
  } else lines.push(line);
});
rl.on("close", () => {
  ended = true;
  if (waiter) {
    waiter(null);
    waiter = null;
  }
});
async function ask(prompt) {
  process.stdout.write(prompt);
  if (lines.length) return lines.shift();
  if (ended) return null;
  return await new Promise((r) => (waiter = r));
}
function number(s) {
  if (s === null || s.trim() === "" || !Number.isInteger(Number(s)))
    throw new Error("integer required");
  return Number(s);
}
function make() {
  return new Depot();
}
(async () => {
  let state = make();
  try {
    while (true) {
      console.log("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit");
      const choice = await ask("> ");
      if (choice === null || choice === "5") break;
      try {
        if (choice === "1") {
          console.log(
            "Metal 11kg, purity80:",
            new Metal("DEMO", 11, 80).points(),
          );
        } else if (choice === "2") {
          const id = await ask("Receipt ID: "),
            kind = ((await ask("Material P/G/M: ")) || "").toUpperCase(),
            kg = number(await ask("Kilograms: ")),
            p = number(await ask("Purity percent: "));
          let x;
          if (kind === "P") x = new Paper(id, kg, p);
          else if (kind === "G") x = new Glass(id, kg, p);
          else if (kind === "M") x = new Metal(id, kg, p);
          else throw new Error("unknown material");
          state.add(x);
          console.log("Credited:", state.credit(id));
        } else if (choice === "3") {
          console.log(
            "Balance:",
            state.balance(),
            "Credited receipts:",
            state.creditedCount(),
          );
        } else if (choice === "4") {
          state = make();
          console.log(
            "Reset clears the receipt ledger. Low purity rejects credit; the added receipt remains recorded but uncredited.",
          );
        } else console.log("Choose 1–5");
      } catch (e) {
        console.log("Rejected: " + e.message);
      }
    }
  } finally {
    rl.close();
  }
})();
