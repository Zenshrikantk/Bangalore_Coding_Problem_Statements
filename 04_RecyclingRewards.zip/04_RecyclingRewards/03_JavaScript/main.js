class Material {
  constructor(ident, kilograms, purity) {
    if (
      !ident ||
      !Number.isInteger(kilograms) ||
      kilograms < 1 ||
      kilograms > 100 ||
      !Number.isInteger(purity) ||
      purity < 0 ||
      purity > 100
    )
      throw new Error("invalid material");
    this.ident = ident;
    this.kilograms = kilograms;
    this.purity = purity;
    this.credited = false;
  }
  rate() {
    throw new Error("abstract rate");
  }
  minimum() {
    throw new Error("abstract minimum");
  }
  eligible() {
    return this.purity > this.minimum();
  }
  points() {
    if (!this.eligible()) return 0;
    const base = this.kilograms * this.rate();
    return base + (this.kilograms > 10 ? Math.ceil(base / 10) : 0);
  }
}
class Paper extends Material {
  rate() {
    return 2;
  }
  minimum() {
    return 90;
  }
}
class Glass extends Material {
  rate() {
    return 2;
  }
  minimum() {
    return 95;
  }
}
class Metal extends Material {
  rate() {
    return 5;
  }
  minimum() {
    return 90;
  }
}
class Depot {
  constructor() {
    this.materials = [];
    this.ledger = 0;
  }
  add(x) {
    if (this.materials.some((y) => y.ident === x.ident))
      throw new Error("duplicate id");
    this.materials.push(x);
  }
  find(id) {
    const x = this.materials.find((x) => x.ident === id);
    if (!x) throw new Error("unknown material");
    return x;
  }
  credit(id) {
    const x = this.find(id);
    if (x.credited) throw new Error("already credited");
    if (!x.eligible()) throw new Error("purity too low");
    const amount = x.points();
    x.credited = true;
    this.ledger = amount;
    return amount;
  }
  balance() {
    return this.ledger;
  }
  creditedCount() {
    return this.materials.filter((x) => x.credited).length;
  }
}
module.exports = { Material, Paper, Glass, Metal, Depot };
