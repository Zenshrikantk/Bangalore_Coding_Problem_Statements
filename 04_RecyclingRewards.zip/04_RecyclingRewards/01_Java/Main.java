import java.util.*;

abstract class Material {

  final String ident;
  final int kilograms, purity;
  boolean credited = false;

  Material(String id, int kg, int purity) {
    if (
      id == null ||
      id.isEmpty() ||
      kg < 1 ||
      kg > 100 ||
      purity < 0 ||
      purity > 100
    ) throw new IllegalArgumentException("invalid material");
    ident = id;
    kilograms = kg;
    this.purity = purity;
  }

  abstract int rate();

  abstract int minimum();

  boolean eligible() {
    return purity > minimum();
  }

  int points() {
    if (!eligible()) return 0;
    int base = kilograms * rate();
    return base + (kilograms > 10 ? (base + 9) / 10 : 0);
  }
}

class Paper extends Material {

  Paper(String id, int kg, int p) {
    super(id, kg, p);
  }

  @Override
  int rate() {
    return 2;
  }

  @Override
  int minimum() {
    return 90;
  }
}

class Glass extends Material {

  Glass(String id, int kg, int p) {
    super(id, kg, p);
  }

  @Override
  int rate() {
    return 2;
  }

  @Override
  int minimum() {
    return 95;
  }
}

class Metal extends Material {

  Metal(String id, int kg, int p) {
    super(id, kg, p);
  }

  @Override
  int rate() {
    return 5;
  }

  @Override
  int minimum() {
    return 90;
  }
}

class Depot {

  private final List<Material> materials = new ArrayList<>();
  private int ledger = 0;

  void add(Material x) {
    for (Material y : materials)
      if (y.ident.equals(x.ident)) throw new IllegalArgumentException(
        "duplicate id"
      );
    materials.add(x);
  }

  Material find(String id) {
    for (Material x : materials) if (x.ident.equals(id)) return x;
    throw new IllegalArgumentException("unknown material");
  }

  int credit(String id) {
    Material x = find(id);
    if (x.credited) throw new IllegalArgumentException("already credited");
    if (!x.eligible()) throw new IllegalArgumentException("purity too low");
    int amount = x.points();
    x.credited = true;
    ledger = amount;
    return amount;
  }

  int balance() {
    return ledger;
  }

  int creditedCount() {
    int count = 0;
    for (Material x : materials) if (x.credited) count++;
    return count;
  }
}

public class Main {}
