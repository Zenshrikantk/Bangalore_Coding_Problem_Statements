public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!expected.equals(actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void raises(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException e) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Depot s = new Depot();
    raises(() -> s.credit("none"));
    raises(() -> s.add(new Paper("BAD", 0, 100)));
    eq(0, s.balance());
  }

  static void tc2() {
    Paper x = new Paper("R1", 2, 90);
    eq(true, x.eligible());
    eq(4, x.points());
  }

  static void tc3() {
    Glass x = new Glass("R2", 2, 100);
    eq(6, x.points());
  }

  static void tc4() {
    Metal x = new Metal("R3", 2, 85);
    eq(10, x.points());
  }

  static void tc5() {
    Paper x = new Paper("R4", 10, 100);
    eq(22, x.points());
  }

  static void tc6() {
    Metal x = new Metal("R5", 11, 100);
    eq(60, x.points());
  }

  static void tc7() {
    Depot s = new Depot();
    s.add(new Paper("R6", 2, 50));
    raises(() -> s.credit("R6"));
    eq(0, s.balance());
    eq(0, s.creditedCount());
  }

  static void tc8() {
    Depot s = new Depot();
    s.add(new Paper("R7", 2, 100));
    eq(4, s.credit("R7"));
    raises(() -> s.credit("R7"));
    eq(4, s.balance());
    eq(1, s.creditedCount());
  }

  static void tc9() {
    Depot s = new Depot();
    s.add(new Paper("A", 2, 100));
    s.add(new Paper("B", 3, 100));
    eq(4, s.credit("A"));
    eq(6, s.credit("B"));
    eq(10, s.balance());
    eq(2, s.creditedCount());
  }

  static void tc10() {
    throw new AssertionError(
      "Add Metal MX (11kg,purity80) and Glass GX (10kg,purity95). Credit them for60 and33; assert balance93 and creditedCount2. Retry MX, assert rejection and unchanged balance93/count2."
    );
  }

  public static void main(String[] args) {
    int passed = 0;
    try {
      tc1();
      passed++;
      System.out.println("TC1 PASS: Unknown material and invalid quantities");
    } catch (Throwable e) {
      System.out.println(
        "TC1 FAIL: Unknown material and invalid quantities: " + e.getMessage()
      );
    }
    try {
      tc2();
      passed++;
      System.out.println("TC2 PASS: Inclusive purity threshold");
    } catch (Throwable e) {
      System.out.println(
        "TC2 FAIL: Inclusive purity threshold: " + e.getMessage()
      );
    }
    try {
      tc3();
      passed++;
      System.out.println("TC3 PASS: Glass rate override");
    } catch (Throwable e) {
      System.out.println("TC3 FAIL: Glass rate override: " + e.getMessage());
    }
    try {
      tc4();
      passed++;
      System.out.println("TC4 PASS: Metal purity override");
    } catch (Throwable e) {
      System.out.println("TC4 FAIL: Metal purity override: " + e.getMessage());
    }
    try {
      tc5();
      passed++;
      System.out.println("TC5 PASS: Bulk threshold at ten kilograms");
    } catch (Throwable e) {
      System.out.println(
        "TC5 FAIL: Bulk threshold at ten kilograms: " + e.getMessage()
      );
    }
    try {
      tc6();
      passed++;
      System.out.println("TC6 PASS: Bulk bonus rounds down");
    } catch (Throwable e) {
      System.out.println("TC6 FAIL: Bulk bonus rounds down: " + e.getMessage());
    }
    try {
      tc7();
      passed++;
      System.out.println("TC7 PASS: Rejected purity preserves ledger");
    } catch (Throwable e) {
      System.out.println(
        "TC7 FAIL: Rejected purity preserves ledger: " + e.getMessage()
      );
    }
    try {
      tc8();
      passed++;
      System.out.println("TC8 PASS: Repeated credit rejected");
    } catch (Throwable e) {
      System.out.println(
        "TC8 FAIL: Repeated credit rejected: " + e.getMessage()
      );
    }
    try {
      tc9();
      passed++;
      System.out.println("TC9 PASS: Ledger accumulates multiple credits");
    } catch (Throwable e) {
      System.out.println(
        "TC9 FAIL: Ledger accumulates multiple credits: " + e.getMessage()
      );
    }
    try {
      tc10();
      passed++;
      System.out.println("TC10 PASS: Mixed thresholds, bonus and retry");
    } catch (Throwable e) {
      System.out.println(
        "TC10 FAIL: Mixed thresholds, bonus and retry: " + e.getMessage()
      );
    }
    System.out.println("SUMMARY " + passed + "/10 PASS");
    if (passed != 10) System.exit(1);
  }
}
