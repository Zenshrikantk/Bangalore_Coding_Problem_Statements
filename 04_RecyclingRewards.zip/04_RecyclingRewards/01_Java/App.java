import java.util.*;

public class App {

  static Scanner in = new Scanner(System.in);

  static String ask(String p) {
    System.out.print(p);
    if (!in.hasNextLine()) throw new NoSuchElementException();
    return in.nextLine().trim();
  }

  static int number(String p) {
    return Integer.parseInt(ask(p));
  }

  static Depot make() {
    return new Depot();
  }

  public static void main(String[] args) {
    Depot state = make();
    while (true) {
      System.out.println(
        "1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit"
      );
      try {
        String choice = ask("> ");
        if (choice.equals("5")) break;
        switch (choice) {
          case "1": {
            System.out.println(
              "Metal 11kg, purity80: " + new Metal("DEMO", 11, 80).points()
            );
            break;
          }
          case "2": {
            String id = ask("Receipt ID: "),
              kind = ask("Material P/G/M: ").toUpperCase();
            int kg = number("Kilograms: "),
              p = number("Purity percent: ");
            Material x;
            if (kind.equals("P")) x = new Paper(id, kg, p);
            else if (kind.equals("G")) x = new Glass(id, kg, p);
            else if (kind.equals("M")) x = new Metal(id, kg, p);
            else throw new IllegalArgumentException("unknown material");
            state.add(x);
            System.out.println("Credited: " + state.credit(id));
            break;
          }
          case "3": {
            System.out.println(
              "Balance: " +
                state.balance() +
                " Credited receipts: " +
                state.creditedCount()
            );
            break;
          }
          case "4": {
            state = make();
            System.out.println(
              "Reset clears the receipt ledger. Low purity rejects credit; the added receipt remains recorded but uncredited."
            );
            break;
          }
          default:
            System.out.println("Choose 1–5");
        }
      } catch (NoSuchElementException e) {
        break;
      } catch (IllegalArgumentException e) {
        System.out.println("Rejected: " + e.getMessage());
      }
    }
  }
}
