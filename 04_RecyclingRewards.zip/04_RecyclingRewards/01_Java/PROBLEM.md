# Recycling Reward Ledger Debugging Challenge

**Track:** OOP · **Difficulty:** Intermediate · **Suggested time:** 90–120 minutes

Repair a recycling depot that awards points by material subtype, purity and bulk weight, while preserving a one-credit-per-receipt ledger.

This is a deliberately defective, dependency-free console application. Diagnose the defects, repair business code, and implement TC10. The rules below are authoritative; source code may disagree. Policies are fictional training rules.

## Model and public API

Abstract `Material(id,kilograms,purity)`; `Paper`, `Glass`, `Metal` supply `rate()` and `minimum()`. `eligible()` checks quality; `points()` is a pure quote. `Depot.add(item)`, `credit(id)`, `balance()`, `creditedCount()` maintain the ledger. `credit` returns the points awarded for that receipt.

## Rules and boundaries

- IDs are nonempty case-sensitive unique receipt IDs. Kilograms are integer1–100; purity is integer percent0–100. At most1000 receipts; correct argument types and concrete subtypes are supplied.
- Paper:2 points/kg, minimum purity90%; Glass:3 points/kg, minimum95%; Metal:5 points/kg, minimum80%. Minimum purity is inclusive.
- An ineligible quote is zero. For eligible material, base points = kilograms × subtype rate.
- At weight >=10kg, add floor(base points/10) as the bulk bonus. Do not round the bonus up. Under10kg receives no bonus.
- add records an uncredited receipt; duplicate ID rejects without replacement. credit first looks up ID, then rejects already-credited, then rejects insufficient purity.
- After validation, credit marks the receipt credited and adds its full polymorphic points to the cumulative ledger. Repeat credit rejects; rejected credit leaves balance and credited count unchanged.
- A low-purity receipt remains stored and uncredited after rejection. balance is a cumulative total; creditedCount counts completed receipts. Zero receipts gives zero for both.
- No money conversion or real recycling regulation is implied. Invalid domain values/transitions use ValueError / Error / IllegalArgumentException.

## Worked examples

- **Metal,11kg,purity80%** → **60 points**. 55 base + floor(55/10)=5; exact minimum purity is eligible.
- **Glass,10kg,purity95%** → **33 points**. 30 base +3 bulk bonus; both thresholds are inclusive.

## Supplied tests

| Case | Coverage | Expected outcome |
|---|---|---|
| TC1 | Unknown material and invalid quantities | Unknown ID and zero kilograms reject; balance0. |
| TC2 | Inclusive purity threshold | Paper at90% gets4 for2kg. |
| TC3 | Glass rate override | Glass2kg at100% gets6. |
| TC4 | Metal purity override | Metal2kg at85% gets10. |
| TC5 | Bulk threshold at ten kilograms | Paper10kg gets22. |
| TC6 | Bulk bonus rounds down | Metal11kg gets60, not61. |
| TC7 | Rejected purity preserves ledger | Low-purity rejection leaves balance0/count0. |
| TC8 | Repeated credit rejected | Receipt credit4; retry rejects; balance4/count1. |
| TC9 | Ledger accumulates multiple credits | 4+6 credits accumulate to10/count2. |

## TC10 — candidate-owned test

Add Metal MX (11kg,purity80) and Glass GX (10kg,purity95). Credit them for60 and33; assert balance93 and creditedCount2. Retry MX, assert rejection and unchanged balance93/count2.

Replace the deliberately failing stub with meaningful assertions. Retain TC1–TC9 unchanged. The runner continues after each failure and exits nonzero if any test fails.

## Run locally

Select one language; all three implement the same rules.

```text
Java (01_Java):       javac Main.java TestRunner.java App.java
                     java TestRunner
                     java App
Python (02_Python):   python3 test_runner.py
                     python3 app.py
Node (03_JavaScript): node test_runner.js
                     node app.js
```

Requires a JDK (Java 11+), Python 3.8+, or Node 16+. No package installation is required. Run from the chosen language directory.

## Candidate deliverables

1. Record the baseline failures and explain each root cause.
2. Repair business logic while preserving the public APIs and the supplied tests.
3. Complete TC10, achieve 10/10, and demonstrate a user-entered console operation.
4. Explain the object model, boundary arithmetic, and complexity. Avoid fixture-specific outputs or disabling assertions.

## Discussion prompts

- Why is an ineligible quote zero but credit an error?
- Which invariant protects the reward ledger?
- Why delegate minimum and rate to subtypes?
