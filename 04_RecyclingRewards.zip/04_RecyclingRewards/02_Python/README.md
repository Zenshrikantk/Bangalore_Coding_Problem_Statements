# Recycling Reward Ledger — Python

Read [PROBLEM.md](PROBLEM.md) for the complete candidate contract.

```text
python3 test_runner.py
python3 app.py
```

Starter code intentionally contains defects; TC10 is yours to write.
