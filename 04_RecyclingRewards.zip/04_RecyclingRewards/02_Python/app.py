from main import *


def make():
    return Depot()


state = make()
while True:
    print("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit")
    try:
        choice = input("> ").strip()
        if choice == "5":
            break
        if choice == "1":
            print("Metal 11kg, purity80:", Metal("DEMO", 11, 80).points())
        elif choice == "2":
            ident = input("Receipt ID: ").strip()
            kind = input("Material P/G/M: ").strip().upper()
            kg = int(input("Kilograms: "))
            purity = int(input("Purity percent: "))
            if kind == "P":
                item = Paper(ident, kg, purity)
            elif kind == "G":
                item = Glass(ident, kg, purity)
            elif kind == "M":
                item = Metal(ident, kg, purity)
            else:
                raise ValueError("unknown material")
            state.add(item)
            print("Credited:", state.credit(ident))
        elif choice == "3":
            print(
                "Balance:", state.balance(), "Credited receipts:", state.creditedCount()
            )
        elif choice == "4":
            state = make()
            print(
                "Reset clears the receipt ledger. Low purity rejects credit; the added receipt remains recorded but uncredited."
            )
        else:
            print("Choose 1–5")
    except (EOFError, KeyboardInterrupt):
        break
    except (ValueError, TypeError) as e:
        print("Rejected:", e)
