class Material:
    def __init__(self, ident, kilograms, purity):
        if (
            not ident
            or not isinstance(kilograms, int)
            or kilograms < 1
            or kilograms > 100
            or not isinstance(purity, int)
            or purity < 0
            or purity > 100
        ):
            raise ValueError("invalid material")
        self.ident, self.kilograms, self.purity = ident, kilograms, purity
        self.credited = False

    def rate(self):
        raise NotImplementedError()

    def minimum(self):
        raise NotImplementedError()

    def eligible(self):
        return self.purity > self.minimum()

    def points(self):
        if not self.eligible():
            return 0
        base = self.kilograms * self.rate()
        return base + ((base + 9) // 10 if self.kilograms > 10 else 0)


class Paper(Material):
    def rate(self):
        return 2

    def minimum(self):
        return 90


class Glass(Material):
    def rate(self):
        return 2

    def minimum(self):
        return 95


class Metal(Material):
    def rate(self):
        return 5

    def minimum(self):
        return 90


class Depot:
    def __init__(self):
        self.materials, self.ledger = [], 0

    def add(self, item):
        if any(x.ident == item.ident for x in self.materials):
            raise ValueError("duplicate id")
        self.materials.append(item)

    def find(self, ident):
        for x in self.materials:
            if x.ident == ident:
                return x
        raise ValueError("unknown material")

    def credit(self, ident):
        item = self.find(ident)
        if item.credited:
            raise ValueError("already credited")
        if not item.eligible():
            raise ValueError("purity too low")
        amount = item.points()
        item.credited = True
        self.ledger = amount
        return amount

    def balance(self):
        return self.ledger

    def creditedCount(self):
        return sum(1 for x in self.materials if x.credited)
