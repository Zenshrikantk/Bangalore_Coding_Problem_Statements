from main import *
import sys


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def raises(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    s = Depot()
    raises(lambda: s.credit("none"))
    raises(lambda: s.add(Paper("BAD", 0, 100)))
    eq(0, s.balance())


def tc2():
    x = Paper("R1", 2, 90)
    eq(True, x.eligible())
    eq(4, x.points())


def tc3():
    x = Glass("R2", 2, 100)
    eq(6, x.points())


def tc4():
    x = Metal("R3", 2, 85)
    eq(10, x.points())


def tc5():
    x = Paper("R4", 10, 100)
    eq(22, x.points())


def tc6():
    x = Metal("R5", 11, 100)
    eq(60, x.points())


def tc7():
    s = Depot()
    s.add(Paper("R6", 2, 50))
    raises(lambda: s.credit("R6"))
    eq(0, s.balance())
    eq(0, s.creditedCount())


def tc8():
    s = Depot()
    s.add(Paper("R7", 2, 100))
    eq(4, s.credit("R7"))
    raises(lambda: s.credit("R7"))
    eq(4, s.balance())
    eq(1, s.creditedCount())


def tc9():
    s = Depot()
    s.add(Paper("A", 2, 100))
    s.add(Paper("B", 3, 100))
    eq(4, s.credit("A"))
    eq(6, s.credit("B"))
    eq(10, s.balance())
    eq(2, s.creditedCount())


def tc10():
    raise AssertionError(
        "Add Metal MX (11kg,purity80) and Glass GX (10kg,purity95). Credit them for60 and33; assert balance93 and creditedCount2. Retry MX, assert rejection and unchanged balance93/count2."
    )


if __name__ == "__main__":
    passed = 0
    try:
        tc1()
        passed += 1
        print("TC1 PASS: Unknown material and invalid quantities")
    except Exception as e:
        print("TC1 FAIL: Unknown material and invalid quantities: " + str(e))
    try:
        tc2()
        passed += 1
        print("TC2 PASS: Inclusive purity threshold")
    except Exception as e:
        print("TC2 FAIL: Inclusive purity threshold: " + str(e))
    try:
        tc3()
        passed += 1
        print("TC3 PASS: Glass rate override")
    except Exception as e:
        print("TC3 FAIL: Glass rate override: " + str(e))
    try:
        tc4()
        passed += 1
        print("TC4 PASS: Metal purity override")
    except Exception as e:
        print("TC4 FAIL: Metal purity override: " + str(e))
    try:
        tc5()
        passed += 1
        print("TC5 PASS: Bulk threshold at ten kilograms")
    except Exception as e:
        print("TC5 FAIL: Bulk threshold at ten kilograms: " + str(e))
    try:
        tc6()
        passed += 1
        print("TC6 PASS: Bulk bonus rounds down")
    except Exception as e:
        print("TC6 FAIL: Bulk bonus rounds down: " + str(e))
    try:
        tc7()
        passed += 1
        print("TC7 PASS: Rejected purity preserves ledger")
    except Exception as e:
        print("TC7 FAIL: Rejected purity preserves ledger: " + str(e))
    try:
        tc8()
        passed += 1
        print("TC8 PASS: Repeated credit rejected")
    except Exception as e:
        print("TC8 FAIL: Repeated credit rejected: " + str(e))
    try:
        tc9()
        passed += 1
        print("TC9 PASS: Ledger accumulates multiple credits")
    except Exception as e:
        print("TC9 FAIL: Ledger accumulates multiple credits: " + str(e))
    try:
        tc10()
        passed += 1
        print("TC10 PASS: Mixed thresholds, bonus and retry")
    except Exception as e:
        print("TC10 FAIL: Mixed thresholds, bonus and retry: " + str(e))
    print(f"SUMMARY {passed}/10 PASS")
    sys.exit(0 if passed == 10 else 1)
