import java.util.*;

public class TestRunner {

  static int passed = 0;

  static void check(
    int number,
    String title,
    String[] commands,
    String[] expected
  ) {
    try {
      Main engine = new Main();
      List<String> actual = new ArrayList<>();
      for (String command : commands) actual.add(engine.execute(command));
      if (!actual.equals(Arrays.asList(expected))) throw new AssertionError(
        "expected " + Arrays.toString(expected) + ", got " + actual
      );
      System.out.println("TC" + number + " PASS: " + title);
      passed++;
    } catch (Throwable e) {
      System.out.println(
        "TC" + number + " FAIL: " + title + " (" + e.getMessage() + ")"
      );
    }
  }

  public static void main(String[] args) {
    check(
      1,
      "Empty registry and unknown packet",
      new String[] { "STATUS", "GET P" },
      new String[] { "PACKETS -", "ERROR:UNKNOWN" }
    );
    check(
      2,
      "First chunk acknowledged",
      new String[] { "START P 2", "PUT P 0 Hi" },
      new String[] { "STARTED P", "ACK P/0" }
    );
    check(
      3,
      "Out-of-order assembly",
      new String[] {
        "START P 3",
        "PUT P 2 C",
        "PUT P 0 A",
        "PUT P 1 B",
        "GET P",
      },
      new String[] { "STARTED P", "ACK P/2", "ACK P/0", "ACK P/1", "DATA ABC" }
    );
    check(
      4,
      "Upper index boundary rejected",
      new String[] { "START P 2", "PUT P 2 X", "MISSING P" },
      new String[] { "STARTED P", "ERROR:INDEX", "MISSING 0,1" }
    );
    check(
      5,
      "Conflicting replay rejected atomically",
      new String[] { "START P 1", "PUT P 0 A", "PUT P 0 B", "GET P" },
      new String[] { "STARTED P", "ACK P/0", "ERROR:CONFLICT", "DATA A" }
    );
    check(
      6,
      "Missing indexes include zero",
      new String[] { "START P 3", "PUT P 1 B", "MISSING P" },
      new String[] { "STARTED P", "ACK P/1", "MISSING 0,2" }
    );
    check(
      7,
      "Incomplete packet cannot be read",
      new String[] { "START P 2", "PUT P 0 A", "GET P" },
      new String[] { "STARTED P", "ACK P/0", "ERROR:INCOMPLETE" }
    );
    check(
      8,
      "Repeated start cannot erase data",
      new String[] { "START P 1", "PUT P 0 A", "START P 2", "GET P" },
      new String[] { "STARTED P", "ACK P/0", "ERROR:DUPLICATE", "DATA A" }
    );
    check(
      9,
      "Identical chunk is idempotent",
      new String[] { "START P 1", "PUT P 0 A", "PUT P 0 A", "GET P" },
      new String[] { "STARTED P", "ACK P/0", "ACK P/0", "DATA A" }
    );
    // TC10 task: Start P with 2 chunks and Q with 1. Put P/1=B, Q/0=Z, then reject conflicting P/1=X. Assert P still misses only index 0, Q reads Z, and P reads AB after P/0=A. Re-read both packets to prove assembly does not consume data.
    try {
      throw new AssertionError("Implement TC10 with real assertions");
    } catch (AssertionError e) {
      System.out.println("TC10 FAIL: " + e.getMessage());
    }
    System.out.println("SUMMARY: " + passed + "/10 PASS");
    System.exit(passed == 10 ? 0 : 1);
  }
}
