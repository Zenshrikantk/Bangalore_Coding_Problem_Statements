# 10 · Out-of-Order Packet Assembler Debugging Challenge

Track: Algorithm | Difficulty: Intermediate | Suggested time: 90–120 minutes

A local transfer tool receives message chunks out of order. Repair it so messages reconstruct by chunk index and replayed or conflicting chunks cannot corrupt existing data.

Repair the deliberately defective starter, prove the behavior with tests, and explain the algorithm. The rules below are authoritative.

## Contract and commands

- Entities: a packet ID owns a fixed chunk count and a map from zero-based index to text. API: execute(command) on Engine (Python/JavaScript) or Main (Java). Commands are START id total, PUT id index payload, GET id, MISSING id and STATUS.
- Packet IDs match [A-Z][A-Z0-9_]{0,15}. Total is an integer 1..32. Payload is 1..16 ASCII letters or digits, without spaces. Index is a nonnegative integer, with valid range 0 <= index < total. Sessions contain at most 100 packets and 1,000 commands.
- START validates ID and total first, then rejects any existing ID with ERROR:DUPLICATE, preserving all chunks. Success returns STARTED id. Packet IDs are never reused in a session.
- PUT validates syntax/payload, checks existence (ERROR:UNKNOWN), then the upper index bound (ERROR:INDEX), then conflict. An identical replay returns ACK id/index without creating an additional chunk. A different payload for an occupied index returns ERROR:CONFLICT and preserves old data. Other successful writes also return ACK id/index.
- GET returns ERROR:UNKNOWN for missing IDs and ERROR:INCOMPLETE unless every index exists. A complete packet returns DATA followed by payloads concatenated in increasing index order, regardless of arrival order. Repeated reads are identical and do not consume chunks.
- MISSING returns missing indexes in ascending order, including zero; complete packets return MISSING -. STATUS returns PACKETS with sorted IDs, or PACKETS -. Unknown commands, wrong argument counts, negative indexes, or malformed values return ERROR:INPUT. All errors leave state unchanged.

## Worked examples

1. **Input:** `START P 3; PUT P 2 C; PUT P 0 A; PUT P 1 B; GET P`
   **Expected:** `DATA ABC`. The numeric chunk index determines reconstruction order.

2. **Input:** `START P 2; PUT P 1 B; PUT P 1 X; MISSING P`
   **Expected:** `ERROR:CONFLICT; MISSING 0`. The conflict leaves B intact and does not create the missing first chunk.

## Supplied cases

| Case | Purpose | Expected result |
|---|---|---|
| TC1 | Empty registry and unknown packet | PACKETS - ; ERROR:UNKNOWN |
| TC2 | First chunk acknowledged | STARTED P ; ACK P/0 |
| TC3 | Out-of-order assembly | STARTED P ; ACK P/2 ; ACK P/0 ; ACK P/1 ; DATA ABC |
| TC4 | Upper index boundary rejected | STARTED P ; ERROR:INDEX ; MISSING 0,1 |
| TC5 | Conflicting replay rejected atomically | STARTED P ; ACK P/0 ; ERROR:CONFLICT ; DATA A |
| TC6 | Missing indexes include zero | STARTED P ; ACK P/1 ; MISSING 0,2 |
| TC7 | Incomplete packet cannot be read | STARTED P ; ACK P/0 ; ERROR:INCOMPLETE |
| TC8 | Repeated start cannot erase data | STARTED P ; ACK P/0 ; ERROR:DUPLICATE ; DATA A |
| TC9 | Identical chunk is idempotent | STARTED P ; ACK P/0 ; ACK P/0 ; DATA A |

## TC10 — candidate-owned test

Start P with 2 chunks and Q with 1. Put P/1=B, Q/0=Z, then reject conflicting P/1=X. Assert P still misses only index 0, Q reads Z, and P reads AB after P/0=A. Re-read both packets to prove assembly does not consume data.


## Candidate deliverables

1. Run the starter and record every initial PASS/FAIL result.
2. Repair business logic without changing the command API or TC1–TC9 assertions. Do not hard-code fixture outputs or disable tests.
3. Implement the described TC10 with independent literal expectations, including state checks where requested.
4. Obtain 10/10 PASS, demonstrate the interactive console, and explain each root cause and regression test.

The supplied runner always executes all cases and exits nonzero when any case fails. A correct implementation with the original TC10 stub must score 9/10; completing TC10 earns 10/10. These are fictional training policies. Work is in-memory, single-threaded, and requires no network, database, package installation or external services.

## Run locally

Choose one language folder. `PROBLEM.md` inside it is a standalone copy of this statement.

- Java (JDK 11+): `javac Main.java TestRunner.java App.java`, then `java TestRunner` or `java App`.
- Python (3.8+): `python3 test_runner.py` or `python3 app.py`.
- JavaScript (Node.js 18+): `node test_runner.js` or `node app.js`.

Console options: 1 runs a fresh demonstration; 2 executes a command against your current session; 3 displays session status; 4 resets your session; 5 exits. Demonstration state does not alter your session.

## Technical discussion

- Why is chunk count alone sufficient after validation?
- Why can insertion order not be used?
- What is the difference between a replay and a conflict?
- What extra checks would a real transfer protocol need?
