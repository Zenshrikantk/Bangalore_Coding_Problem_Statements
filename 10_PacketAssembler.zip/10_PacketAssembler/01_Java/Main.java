import java.util.*;
import java.math.BigInteger;

public class Main {

  static class DomainError extends RuntimeException {

    DomainError(String code) {
      super(code);
    }
  }

  static void fail(String code) {
    throw new DomainError(code);
  }

  static int number(String text) {
    if (!text.matches("[0-9]+")) fail("INPUT");
    return Integer.parseInt(text);
  }

  static String name(String text) {
    if (!text.matches("[A-Z][A-Z0-9_]{0,15}")) fail("INPUT");
    return text;
  }

  public String execute(String line) {
    try {
      String[] p = line.trim().split("\\s+");
      if (p.length == 0 || p[0].isEmpty()) fail("INPUT");
      return run(p);
    } catch (DomainError e) {
      return "ERROR:" + e.getMessage();
    } catch (RuntimeException e) {
      return "ERROR:INPUT";
    }
  }

  static class Packet {

    final int total;
    final Map<Integer, String> chunks = new LinkedHashMap<>();

    Packet(int total) {
      this.total = total;
    }
  }

  private final Map<String, Packet> packets = new HashMap<>();

  String run(String[] p) {
    if (p[0].equals("STATUS") && p.length == 1) {
      List<String> ids = new ArrayList<>(packets.keySet());
      Collections.sort(ids);
      return "PACKETS " + (ids.isEmpty() ? "-" : String.join(",", ids));
    }
    if (p[0].equals("START") && p.length == 3) {
      String packet = name(p[1]);
      int total = number(p[2]);
      if (total < 1 || total > 32) fail("INPUT");
      packets.put(packet, new Packet(total));
      return "STARTED " + packet;
    }
    if (p[0].equals("PUT") && p.length == 4) {
      String packet = name(p[1]);
      if (!p[2].matches("[0-9]+")) fail("INPUT");
      BigInteger position = new BigInteger(p[2]);
      String payload = p[3];
      if (!payload.matches("[A-Za-z0-9]{1,16}")) fail("INPUT");
      if (!packets.containsKey(packet)) fail("UNKNOWN");
      Packet entry = packets.get(packet);
      if (position.compareTo(BigInteger.valueOf(entry.total)) > 0) fail("INDEX");
      int index = position.intValue();
      entry.chunks.put(index, payload);
      return "ACK " + packet + "/" + index;
    }
    if ((p[0].equals("GET") || p[0].equals("MISSING")) && p.length == 2) {
      String packet = name(p[1]);
      if (!packets.containsKey(packet)) fail("UNKNOWN");
      Packet entry = packets.get(packet);
      if (p[0].equals("MISSING")) {
        List<String> missing = new ArrayList<>();
        for (int i = 1; i < entry.total; i++) if (
          !entry.chunks.containsKey(i)
        ) missing.add(String.valueOf(i));
        return (
          "MISSING " + (missing.isEmpty() ? "-" : String.join(",", missing))
        );
      }
      if (entry.chunks.size() != entry.total) fail("INCOMPLETE");
      StringBuilder result = new StringBuilder();
      for (String payload : entry.chunks.values()) result.append(payload);
      return "DATA " + result;
    }
    fail("INPUT");
    return "";
  }
}
