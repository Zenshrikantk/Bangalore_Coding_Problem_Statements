class DomainError(Exception):
    pass


def fail(code):
    raise DomainError(code)


def number(text):
    if not text.isascii() or not text.isdigit():
        fail("INPUT")
    return int(text)


def name(text):
    if not (
        1 <= len(text) <= 16
        and text[0].isalpha()
        and text.isascii()
        and all(c.isupper() or c.isdigit() or c == "_" for c in text)
    ):
        fail("INPUT")
    return text


class Engine:
    def execute(self, line):
        parts = line.strip().split()
        try:
            if not parts:
                fail("INPUT")
            return self.run(parts)
        except DomainError as exc:
            return "ERROR:" + str(exc)
        except (ValueError, IndexError):
            return "ERROR:INPUT"

    def __init__(self):
        self.packets = {}

    def run(self, p):
        if p[0] == "STATUS" and len(p) == 1:
            return "PACKETS " + (",".join(sorted(self.packets)) or "-")
        if p[0] == "START" and len(p) == 3:
            packet, total = name(p[1]), number(p[2])
            if total < 1 or total > 32:
                fail("INPUT")
            self.packets[packet] = [total, {}]
            return "STARTED " + packet
        if p[0] == "PUT" and len(p) == 4:
            packet, index, payload = name(p[1]), number(p[2]), p[3]
            if not (
                1 <= len(payload) <= 16 and payload.isascii() and payload.isalnum()
            ):
                fail("INPUT")
            if packet not in self.packets:
                fail("UNKNOWN")
            total, chunks = self.packets[packet]
            if index > total:
                fail("INDEX")
            chunks[index] = payload
            return "ACK " + packet + "/" + str(index)
        if p[0] in ("GET", "MISSING") and len(p) == 2:
            packet = name(p[1])
            if packet not in self.packets:
                fail("UNKNOWN")
            total, chunks = self.packets[packet]
            if p[0] == "MISSING":
                missing = [str(i) for i in range(1, total) if i not in chunks]
                return "MISSING " + (",".join(missing) or "-")
            if len(chunks) != total:
                fail("INCOMPLETE")
            return "DATA " + "".join(chunks.values())
        fail("INPUT")
