from main import Engine
import sys

CASES = [
    (
        "Empty registry and unknown packet",
        ["STATUS", "GET P"],
        ["PACKETS -", "ERROR:UNKNOWN"],
    ),
    ("First chunk acknowledged", ["START P 2", "PUT P 0 Hi"], ["STARTED P", "ACK P/0"]),
    (
        "Out-of-order assembly",
        ["START P 3", "PUT P 2 C", "PUT P 0 A", "PUT P 1 B", "GET P"],
        ["STARTED P", "ACK P/2", "ACK P/0", "ACK P/1", "DATA ABC"],
    ),
    (
        "Upper index boundary rejected",
        ["START P 2", "PUT P 2 X", "MISSING P"],
        ["STARTED P", "ERROR:INDEX", "MISSING 0,1"],
    ),
    (
        "Conflicting replay rejected atomically",
        ["START P 1", "PUT P 0 A", "PUT P 0 B", "GET P"],
        ["STARTED P", "ACK P/0", "ERROR:CONFLICT", "DATA A"],
    ),
    (
        "Missing indexes include zero",
        ["START P 3", "PUT P 1 B", "MISSING P"],
        ["STARTED P", "ACK P/1", "MISSING 0,2"],
    ),
    (
        "Incomplete packet cannot be read",
        ["START P 2", "PUT P 0 A", "GET P"],
        ["STARTED P", "ACK P/0", "ERROR:INCOMPLETE"],
    ),
    (
        "Repeated start cannot erase data",
        ["START P 1", "PUT P 0 A", "START P 2", "GET P"],
        ["STARTED P", "ACK P/0", "ERROR:DUPLICATE", "DATA A"],
    ),
    (
        "Identical chunk is idempotent",
        ["START P 1", "PUT P 0 A", "PUT P 0 A", "GET P"],
        ["STARTED P", "ACK P/0", "ACK P/0", "DATA A"],
    ),
]

passed = 0
for index, (title, commands, expected) in enumerate(CASES, 1):
    try:
        engine = Engine()
        actual = [engine.execute(command) for command in commands]
        assert actual == expected, "expected %r, got %r" % (expected, actual)
        print("TC%d PASS: %s" % (index, title))
        passed += 1
    except Exception as exc:
        print("TC%d FAIL: %s (%s)" % (index, title, exc))

# TC10 task: Start P with 2 chunks and Q with 1. Put P/1=B, Q/0=Z, then reject conflicting P/1=X. Assert P still misses only index 0, Q reads Z, and P reads AB after P/0=A. Re-read both packets to prove assembly does not consume data.
try:
    raise AssertionError("Implement TC10 with real assertions")
except Exception as exc:
    print("TC10 FAIL: %s" % exc)

print("SUMMARY: %d/10 PASS" % passed)
sys.exit(0 if passed == 10 else 1)
