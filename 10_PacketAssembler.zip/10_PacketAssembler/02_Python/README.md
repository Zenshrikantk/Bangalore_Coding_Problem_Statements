# Out-of-Order Packet Assembler · Python

Read [PROBLEM.md](PROBLEM.md) for the complete standalone statement. The [domain statement](../README.md) is also available in the full candidate collection.

```text
python3 test_runner.py
python3 app.py
```

The starter has planted logic defects; TC10 is deliberately unfinished. Preserve TC1–TC9.
