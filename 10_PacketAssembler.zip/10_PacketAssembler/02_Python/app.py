from main import Engine


def main():
    engine = Engine()
    while True:
        print("1 Demo | 2 Enter command | 3 Status | 4 Reset | 5 Exit")
        try:
            option = input("> ").strip()
        except EOFError:
            break
        if option == "1":
            sample = Engine()
            for command in DEMO:
                print(command, "=>", sample.execute(command))
        elif option == "2":
            try:
                print(engine.execute(input("Command: ")))
            except EOFError:
                break
        elif option == "3":
            print(engine.execute("STATUS"))
        elif option == "4":
            engine = Engine()
            print("RESET")
        elif option == "5":
            break
        else:
            print("Choose 1 through 5. Read PROBLEM.md for commands.")


DEMO = ["START P 3", "PUT P 2 C", "PUT P 0 A", "PUT P 1 B", "GET P"]
if __name__ == "__main__":
    main()
