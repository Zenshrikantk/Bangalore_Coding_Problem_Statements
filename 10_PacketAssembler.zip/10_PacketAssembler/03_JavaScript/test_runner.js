"use strict";
const { Engine } = require("./main");
const cases = [
  [
    "Empty registry and unknown packet",
    ["STATUS", "GET P"],
    ["PACKETS -", "ERROR:UNKNOWN"],
  ],
  [
    "First chunk acknowledged",
    ["START P 2", "PUT P 0 Hi"],
    ["STARTED P", "ACK P/0"],
  ],
  [
    "Out-of-order assembly",
    ["START P 3", "PUT P 2 C", "PUT P 0 A", "PUT P 1 B", "GET P"],
    ["STARTED P", "ACK P/2", "ACK P/0", "ACK P/1", "DATA ABC"],
  ],
  [
    "Upper index boundary rejected",
    ["START P 2", "PUT P 2 X", "MISSING P"],
    ["STARTED P", "ERROR:INDEX", "MISSING 0,1"],
  ],
  [
    "Conflicting replay rejected atomically",
    ["START P 1", "PUT P 0 A", "PUT P 0 B", "GET P"],
    ["STARTED P", "ACK P/0", "ERROR:CONFLICT", "DATA A"],
  ],
  [
    "Missing indexes include zero",
    ["START P 3", "PUT P 1 B", "MISSING P"],
    ["STARTED P", "ACK P/1", "MISSING 0,2"],
  ],
  [
    "Incomplete packet cannot be read",
    ["START P 2", "PUT P 0 A", "GET P"],
    ["STARTED P", "ACK P/0", "ERROR:INCOMPLETE"],
  ],
  [
    "Repeated start cannot erase data",
    ["START P 1", "PUT P 0 A", "START P 2", "GET P"],
    ["STARTED P", "ACK P/0", "ERROR:DUPLICATE", "DATA A"],
  ],
  [
    "Identical chunk is idempotent",
    ["START P 1", "PUT P 0 A", "PUT P 0 A", "GET P"],
    ["STARTED P", "ACK P/0", "ACK P/0", "DATA A"],
  ],
];
let passed = 0;
for (let i = 0; i < cases.length; i++) {
  const [title, commands, expected] = cases[i];
  try {
    const engine = new Engine();
    const actual = commands.map((command) => engine.execute(command));
    if (JSON.stringify(actual) !== JSON.stringify(expected))
      throw new Error(
        `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      );
    console.log(`TC${i + 1} PASS: ${title}`);
    passed++;
  } catch (e) {
    console.log(`TC${i + 1} FAIL: ${title} (${e.message})`);
  }
}
// TC10 task: Start P with 2 chunks and Q with 1. Put P/1=B, Q/0=Z, then reject conflicting P/1=X. Assert P still misses only index 0, Q reads Z, and P reads AB after P/0=A. Re-read both packets to prove assembly does not consume data.
try {
  throw new Error("Implement TC10 with real assertions");
} catch (e) {
  console.log("TC10 FAIL: " + e.message);
}
console.log(`SUMMARY: ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
