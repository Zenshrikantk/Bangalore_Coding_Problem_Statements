"use strict";
class DomainError extends Error {}
function fail(code) {
  throw new DomainError(code);
}
function number(text) {
  if (!/^\d+$/.test(text || "")) fail("INPUT");
  return Number(text);
}
function name(text) {
  if (!/^[A-Z][A-Z0-9_]{0,15}$/.test(text || "")) fail("INPUT");
  return text;
}
class Engine {
  execute(line) {
    try {
      const parts = line.trim().split(/\s+/);
      if (!parts[0]) fail("INPUT");
      return this.run(parts);
    } catch (e) {
      return "ERROR:" + (e instanceof DomainError ? e.message : "INPUT");
    }
  }
  constructor() {
    this.packets = new Map();
  }
  run(p) {
    if (p[0] === "STATUS" && p.length === 1)
      return "PACKETS " + ([...this.packets.keys()].sort().join(",") || "-");
    if (p[0] === "START" && p.length === 3) {
      const packet = name(p[1]),
        total = number(p[2]);
      if (total < 1 || total > 32) fail("INPUT");
      this.packets.set(packet, { total, chunks: new Map() });
      return "STARTED " + packet;
    }
    if (p[0] === "PUT" && p.length === 4) {
      const packet = name(p[1]),
        index = number(p[2]),
        payload = p[3];
      if (!/^[A-Za-z0-9]{1,16}$/.test(payload)) fail("INPUT");
      if (!this.packets.has(packet)) fail("UNKNOWN");
      const { total, chunks } = this.packets.get(packet);
      if (index > total) fail("INDEX");
      chunks.set(index, payload);
      return "ACK " + packet + "/" + index;
    }
    if (["GET", "MISSING"].includes(p[0]) && p.length === 2) {
      const packet = name(p[1]);
      if (!this.packets.has(packet)) fail("UNKNOWN");
      const { total, chunks } = this.packets.get(packet);
      if (p[0] === "MISSING") {
        const missing = [];
        for (let i = 1; i < total; i++) if (!chunks.has(i)) missing.push(i);
        return "MISSING " + (missing.join(",") || "-");
      }
      if (chunks.size !== total) fail("INCOMPLETE");
      return "DATA " + [...chunks.values()].join("");
    }
    fail("INPUT");
  }
}
module.exports = { Engine };
