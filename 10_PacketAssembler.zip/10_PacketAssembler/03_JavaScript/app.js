"use strict";
const { Engine } = require("./main");
const readline = require("readline");
const demo = ["START P 3", "PUT P 2 C", "PUT P 0 A", "PUT P 1 B", "GET P"];
let engine = new Engine();
let awaitingCommand = false;
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false,
});
function menu() {
  console.log("1 Demo | 2 Enter command | 3 Status | 4 Reset | 5 Exit");
}
menu();
rl.on("line", (line) => {
  if (awaitingCommand) {
    console.log(engine.execute(line));
    awaitingCommand = false;
    menu();
    return;
  }
  switch (line.trim()) {
    case "1": {
      const sample = new Engine();
      for (const command of demo)
        console.log(command + " => " + sample.execute(command));
      break;
    }
    case "2":
      awaitingCommand = true;
      console.log("Command:");
      return;
    case "3":
      console.log(engine.execute("STATUS"));
      break;
    case "4":
      engine = new Engine();
      console.log("RESET");
      break;
    case "5":
      rl.close();
      process.stdin.destroy();
      return;
    default:
      console.log("Choose 1 through 5. Read PROBLEM.md for commands.");
  }
  menu();
});
