"use strict";
class DomainError extends Error {}
function fail(code) {
  throw new DomainError(code);
}
function number(text) {
  if (!/^\d+$/.test(text || "")) fail("INPUT");
  return Number(text);
}
function name(text) {
  if (!/^[A-Z][A-Z0-9_]{0,15}$/.test(text || "")) fail("INPUT");
  return text;
}
class Engine {
  execute(line) {
    try {
      const parts = line.trim().split(/\s+/);
      if (!parts[0]) fail("INPUT");
      return this.run(parts);
    } catch (e) {
      return "ERROR:" + (e instanceof DomainError ? e.message : "INPUT");
    }
  }
  constructor() {
    this.buckets = new Map();
    this.lastTime = 0;
  }
  run(p) {
    if (p[0] === "STATUS" && p.length === 1)
      return "CLIENTS " + ([...this.buckets.keys()].sort().join(",") || "-");
    if (!["HIT", "COUNT"].includes(p[0]) || p.length !== 3) fail("INPUT");
    const client = name(p[1]),
      time = number(p[2]);
    if (time > 1000000) fail("INPUT");
    if (time < 0) fail("TIME");
    const key = client[0];
    const events = (this.buckets.get(key) || []).filter((t) => t >= time - 10);
    this.lastTime = time;
    if (p[0] === "COUNT") {
      if (this.buckets.has(key)) this.buckets.set(key, events);
      return "COUNT " + events.length;
    }
    if (events.length > 3) {
      events.push(time);
      this.buckets.set(key, events);
      return "DENY " + events.length;
    }
    events.push(time);
    this.buckets.set(key, events);
    return "ALLOW " + events.length;
  }
}
module.exports = { Engine };
