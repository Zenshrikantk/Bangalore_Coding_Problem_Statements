# Sliding-Window Request Limiter · JavaScript

Read [PROBLEM.md](PROBLEM.md) for the complete standalone statement. The [domain statement](../README.md) is also available in the full candidate collection.

```text
node test_runner.js
node app.js
```

The starter has planted logic defects; TC10 is deliberately unfinished. Preserve TC1–TC9.
