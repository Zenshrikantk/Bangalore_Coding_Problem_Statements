"use strict";
const { Engine } = require("./main");
const cases = [
  [
    "First three hits at the same time",
    ["HIT A 0", "HIT A 0", "HIT A 0"],
    ["ALLOW 1", "ALLOW 2", "ALLOW 3"],
  ],
  [
    "Count never-seen client",
    ["COUNT A 0", "STATUS"],
    ["COUNT 0", "CLIENTS -"],
  ],
  [
    "Exact capacity",
    ["HIT A 0", "HIT A 0", "HIT A 0", "HIT A 0"],
    ["ALLOW 1", "ALLOW 2", "ALLOW 3", "DENY 3"],
  ],
  [
    "Left window boundary expires",
    ["HIT A 0", "COUNT A 10"],
    ["ALLOW 1", "COUNT 0"],
  ],
  [
    "Full client identity isolates quotas",
    ["HIT A1 0", "HIT A2 0", "COUNT A1 0", "COUNT A2 0"],
    ["ALLOW 1", "ALLOW 1", "COUNT 1", "COUNT 1"],
  ],
  [
    "Old events expire after idle period",
    ["HIT A 0", "HIT A 1", "COUNT A 12"],
    ["ALLOW 1", "ALLOW 2", "COUNT 0"],
  ],
  [
    "Backwards time rejected atomically",
    ["HIT A 5", "HIT B 4", "STATUS", "COUNT A 5"],
    ["ALLOW 1", "ERROR:TIME", "CLIENTS A", "COUNT 1"],
  ],
  [
    "Rejected requests never become active events",
    ["HIT A 0", "HIT A 1", "HIT A 2", "HIT A 3", "HIT A 4", "COUNT A 12"],
    ["ALLOW 1", "ALLOW 2", "ALLOW 3", "DENY 3", "DENY 3", "COUNT 0"],
  ],
  [
    "Malformed timestamp leaves clock unchanged",
    ["HIT A -1", "HIT A 0", "COUNT A 0"],
    ["ERROR:INPUT", "ALLOW 1", "COUNT 1"],
  ],
];
let passed = 0;
for (let i = 0; i < cases.length; i++) {
  const [title, commands, expected] = cases[i];
  try {
    const engine = new Engine();
    const actual = commands.map((command) => engine.execute(command));
    if (JSON.stringify(actual) !== JSON.stringify(expected))
      throw new Error(
        `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      );
    console.log(`TC${i + 1} PASS: ${title}`);
    passed++;
  } catch (e) {
    console.log(`TC${i + 1} FAIL: ${title} (${e.message})`);
  }
}
// TC10 task: Fill A1 with three accepted hits at second 0; deny another at second 9. At second 10 verify that A1 accepts a new hit and has count 1. Independently accept A2 at second 10 and verify both counts remain 1.
try {
  throw new Error("Implement TC10 with real assertions");
} catch (e) {
  console.log("TC10 FAIL: " + e.message);
}
console.log(`SUMMARY: ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
