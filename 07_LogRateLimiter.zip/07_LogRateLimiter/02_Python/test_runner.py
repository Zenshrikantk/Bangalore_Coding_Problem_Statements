from main import Engine
import sys

CASES = [
    (
        "First three hits at the same time",
        ["HIT A 0", "HIT A 0", "HIT A 0"],
        ["ALLOW 1", "ALLOW 2", "ALLOW 3"],
    ),
    ("Count never-seen client", ["COUNT A 0", "STATUS"], ["COUNT 0", "CLIENTS -"]),
    (
        "Exact capacity",
        ["HIT A 0", "HIT A 0", "HIT A 0", "HIT A 0"],
        ["ALLOW 1", "ALLOW 2", "ALLOW 3", "DENY 3"],
    ),
    ("Left window boundary expires", ["HIT A 0", "COUNT A 10"], ["ALLOW 1", "COUNT 0"]),
    (
        "Full client identity isolates quotas",
        ["HIT A1 0", "HIT A2 0", "COUNT A1 0", "COUNT A2 0"],
        ["ALLOW 1", "ALLOW 1", "COUNT 1", "COUNT 1"],
    ),
    (
        "Old events expire after idle period",
        ["HIT A 0", "HIT A 1", "COUNT A 12"],
        ["ALLOW 1", "ALLOW 2", "COUNT 0"],
    ),
    (
        "Backwards time rejected atomically",
        ["HIT A 5", "HIT B 4", "STATUS", "COUNT A 5"],
        ["ALLOW 1", "ERROR:TIME", "CLIENTS A", "COUNT 1"],
    ),
    (
        "Rejected requests never become active events",
        ["HIT A 0", "HIT A 1", "HIT A 2", "HIT A 3", "HIT A 4", "COUNT A 12"],
        ["ALLOW 1", "ALLOW 2", "ALLOW 3", "DENY 3", "DENY 3", "COUNT 0"],
    ),
    (
        "Malformed timestamp leaves clock unchanged",
        ["HIT A -1", "HIT A 0", "COUNT A 0"],
        ["ERROR:INPUT", "ALLOW 1", "COUNT 1"],
    ),
]

passed = 0
for index, (title, commands, expected) in enumerate(CASES, 1):
    try:
        engine = Engine()
        actual = [engine.execute(command) for command in commands]
        assert actual == expected, "expected %r, got %r" % (expected, actual)
        print("TC%d PASS: %s" % (index, title))
        passed += 1
    except Exception as exc:
        print("TC%d FAIL: %s (%s)" % (index, title, exc))

# TC10 task: Fill A1 with three accepted hits at second 0; deny another at second 9. At second 10 verify that A1 accepts a new hit and has count 1. Independently accept A2 at second 10 and verify both counts remain 1.
try:
    raise AssertionError("Implement TC10 with real assertions")
except Exception as exc:
    print("TC10 FAIL: %s" % exc)

print("SUMMARY: %d/10 PASS" % passed)
sys.exit(0 if passed == 10 else 1)
