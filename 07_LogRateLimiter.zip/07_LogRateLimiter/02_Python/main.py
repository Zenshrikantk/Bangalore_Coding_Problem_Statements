class DomainError(Exception):
    pass


def fail(code):
    raise DomainError(code)


def number(text):
    if not text.isascii() or not text.isdigit():
        fail("INPUT")
    return int(text)


def name(text):
    if not (
        1 <= len(text) <= 16
        and text[0].isalpha()
        and text.isascii()
        and all(c.isupper() or c.isdigit() or c == "_" for c in text)
    ):
        fail("INPUT")
    return text


class Engine:
    def execute(self, line):
        parts = line.strip().split()
        try:
            if not parts:
                fail("INPUT")
            return self.run(parts)
        except DomainError as exc:
            return "ERROR:" + str(exc)
        except (ValueError, IndexError):
            return "ERROR:INPUT"

    def __init__(self):
        self.buckets = {}
        self.last_time = 0

    def run(self, p):
        if p[0] == "STATUS" and len(p) == 1:
            return "CLIENTS " + (",".join(sorted(self.buckets)) or "-")
        if p[0] not in ("HIT", "COUNT") or len(p) != 3:
            fail("INPUT")
        client, time = name(p[1]), number(p[2])
        if time > 1000000:
            fail("INPUT")
        if time < 0:
            fail("TIME")
        key = client[0]
        events = [t for t in self.buckets.get(key, []) if t >= time - 10]
        self.last_time = time
        if p[0] == "COUNT":
            if key in self.buckets:
                self.buckets[key] = events
            return "COUNT " + str(len(events))
        if len(events) > 3:
            events.append(time)
            self.buckets[key] = events
            return "DENY " + str(len(events))
        events.append(time)
        self.buckets[key] = events
        return "ALLOW " + str(len(events))
