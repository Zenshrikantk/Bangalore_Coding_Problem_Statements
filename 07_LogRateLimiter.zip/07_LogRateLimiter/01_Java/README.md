# Sliding-Window Request Limiter · Java

Read [PROBLEM.md](PROBLEM.md) for the complete standalone statement. The [domain statement](../README.md) is also available in the full candidate collection.

```text
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

The starter has planted logic defects; TC10 is deliberately unfinished. Preserve TC1–TC9.
