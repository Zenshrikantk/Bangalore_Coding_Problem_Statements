# 07 · Sliding-Window Request Limiter Debugging Challenge

Track: Algorithm | Difficulty: Intermediate | Suggested time: 90–120 minutes

An event gateway admits at most three requests per client in a rolling ten-second window. Repair the limiter so that rejected requests and other clients cannot consume a client’s quota.

Repair the deliberately defective starter, prove the behavior with tests, and explain the algorithm. The rules below are authoritative.

## Contract and commands

- Entity: each client ID owns a list of accepted request timestamps. API: execute(command) on Engine (Python/JavaScript) or Main (Java). Commands are HIT client second, COUNT client second and STATUS.
- Client IDs match [A-Z][A-Z0-9_]{0,15}. Times are integer seconds from 0 through 1,000,000. Sessions contain at most 1,000 commands and 100 clients. Malformed values return ERROR:INPUT.
- All timestamped commands, including COUNT and denied HIT, must use globally nondecreasing time. A time smaller than the last valid timestamp returns ERROR:TIME and changes no state. Validation occurs before pruning or advancing the clock.
- At time t the active window is (t-10, t]: a timestamp exactly t-10 has expired. Count only accepted HIT events for that complete client ID. Equal timestamps represent distinct requests.
- HIT first discards expired events for that client. If three remain, return DENY 3 without appending an event; otherwise append t and return ALLOW n, where n is the new active count. A denial may prune old events and advances the clock, but cannot create an accepted event.
- COUNT returns COUNT n after pruning, without recording a request or creating a previously unseen client. STATUS lists clients that have ever received HIT in ascending order as CLIENTS A,B; expired clients remain listed. Empty status is CLIENTS -. STATUS does not change time.

## Worked examples

1. **Input:** `HIT A 0 three times; HIT A 9; HIT A 10`
   **Expected:** `ALLOW 1; ALLOW 2; ALLOW 3; DENY 3; ALLOW 1`. The three second-zero events all expire at second 10, and the denied request never entered the window.

2. **Input:** `HIT A1 5; HIT A2 5; COUNT A1 5`
   **Expected:** `ALLOW 1; ALLOW 1; COUNT 1`. Clients sharing a prefix still have independent quotas.

## Supplied cases

| Case | Purpose | Expected result |
|---|---|---|
| TC1 | First three hits at the same time | ALLOW 1 ; ALLOW 2 ; ALLOW 3 |
| TC2 | Count never-seen client | COUNT 0 ; CLIENTS - |
| TC3 | Exact capacity | ALLOW 1 ; ALLOW 2 ; ALLOW 3 ; DENY 3 |
| TC4 | Left window boundary expires | ALLOW 1 ; COUNT 0 |
| TC5 | Full client identity isolates quotas | ALLOW 1 ; ALLOW 1 ; COUNT 1 ; COUNT 1 |
| TC6 | Old events expire after idle period | ALLOW 1 ; ALLOW 2 ; COUNT 0 |
| TC7 | Backwards time rejected atomically | ALLOW 1 ; ERROR:TIME ; CLIENTS A ; COUNT 1 |
| TC8 | Rejected requests never become active events | ALLOW 1 ; ALLOW 2 ; ALLOW 3 ; DENY 3 ; DENY 3 ; COUNT 0 |
| TC9 | Malformed timestamp leaves clock unchanged | ERROR:INPUT ; ALLOW 1 ; COUNT 1 |

## TC10 — candidate-owned test

Fill A1 with three accepted hits at second 0; deny another at second 9. At second 10 verify that A1 accepts a new hit and has count 1. Independently accept A2 at second 10 and verify both counts remain 1.


## Candidate deliverables

1. Run the starter and record every initial PASS/FAIL result.
2. Repair business logic without changing the command API or TC1–TC9 assertions. Do not hard-code fixture outputs or disable tests.
3. Implement the described TC10 with independent literal expectations, including state checks where requested.
4. Obtain 10/10 PASS, demonstrate the interactive console, and explain each root cause and regression test.

The supplied runner always executes all cases and exits nonzero when any case fails. A correct implementation with the original TC10 stub must score 9/10; completing TC10 earns 10/10. These are fictional training policies. Work is in-memory, single-threaded, and requires no network, database, package installation or external services.

## Run locally

Choose one language folder. `PROBLEM.md` inside it is a standalone copy of this statement.

- Java (JDK 11+): `javac Main.java TestRunner.java App.java`, then `java TestRunner` or `java App`.
- Python (3.8+): `python3 test_runner.py` or `python3 app.py`.
- JavaScript (Node.js 18+): `node test_runner.js` or `node app.js`.

Console options: 1 runs a fresh demonstration; 2 executes a command against your current session; 3 displays session status; 4 resets your session; 5 exits. Demonstration state does not alter your session.

## Technical discussion

- Why is the cutoff strict?
- Why should rejected attempts not be appended?
- Why is monotonic time required here?
- Would the same code be safe under parallel requests?
