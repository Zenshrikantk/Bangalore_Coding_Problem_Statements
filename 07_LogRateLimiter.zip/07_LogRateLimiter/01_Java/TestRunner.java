import java.util.*;

public class TestRunner {

  static int passed = 0;

  static void check(
    int number,
    String title,
    String[] commands,
    String[] expected
  ) {
    try {
      Main engine = new Main();
      List<String> actual = new ArrayList<>();
      for (String command : commands) actual.add(engine.execute(command));
      if (!actual.equals(Arrays.asList(expected))) throw new AssertionError(
        "expected " + Arrays.toString(expected) + ", got " + actual
      );
      System.out.println("TC" + number + " PASS: " + title);
      passed++;
    } catch (Throwable e) {
      System.out.println(
        "TC" + number + " FAIL: " + title + " (" + e.getMessage() + ")"
      );
    }
  }

  public static void main(String[] args) {
    check(
      1,
      "First three hits at the same time",
      new String[] { "HIT A 0", "HIT A 0", "HIT A 0" },
      new String[] { "ALLOW 1", "ALLOW 2", "ALLOW 3" }
    );
    check(
      2,
      "Count never-seen client",
      new String[] { "COUNT A 0", "STATUS" },
      new String[] { "COUNT 0", "CLIENTS -" }
    );
    check(
      3,
      "Exact capacity",
      new String[] { "HIT A 0", "HIT A 0", "HIT A 0", "HIT A 0" },
      new String[] { "ALLOW 1", "ALLOW 2", "ALLOW 3", "DENY 3" }
    );
    check(
      4,
      "Left window boundary expires",
      new String[] { "HIT A 0", "COUNT A 10" },
      new String[] { "ALLOW 1", "COUNT 0" }
    );
    check(
      5,
      "Full client identity isolates quotas",
      new String[] { "HIT A1 0", "HIT A2 0", "COUNT A1 0", "COUNT A2 0" },
      new String[] { "ALLOW 1", "ALLOW 1", "COUNT 1", "COUNT 1" }
    );
    check(
      6,
      "Old events expire after idle period",
      new String[] { "HIT A 0", "HIT A 1", "COUNT A 12" },
      new String[] { "ALLOW 1", "ALLOW 2", "COUNT 0" }
    );
    check(
      7,
      "Backwards time rejected atomically",
      new String[] { "HIT A 5", "HIT B 4", "STATUS", "COUNT A 5" },
      new String[] { "ALLOW 1", "ERROR:TIME", "CLIENTS A", "COUNT 1" }
    );
    check(
      8,
      "Rejected requests never become active events",
      new String[] {
        "HIT A 0",
        "HIT A 1",
        "HIT A 2",
        "HIT A 3",
        "HIT A 4",
        "COUNT A 12",
      },
      new String[] {
        "ALLOW 1",
        "ALLOW 2",
        "ALLOW 3",
        "DENY 3",
        "DENY 3",
        "COUNT 0",
      }
    );
    check(
      9,
      "Malformed timestamp leaves clock unchanged",
      new String[] { "HIT A -1", "HIT A 0", "COUNT A 0" },
      new String[] { "ERROR:INPUT", "ALLOW 1", "COUNT 1" }
    );
    // TC10 task: Fill A1 with three accepted hits at second 0; deny another at second 9. At second 10 verify that A1 accepts a new hit and has count 1. Independently accept A2 at second 10 and verify both counts remain 1.
    try {
      throw new AssertionError("Implement TC10 with real assertions");
    } catch (AssertionError e) {
      System.out.println("TC10 FAIL: " + e.getMessage());
    }
    System.out.println("SUMMARY: " + passed + "/10 PASS");
    System.exit(passed == 10 ? 0 : 1);
  }
}
