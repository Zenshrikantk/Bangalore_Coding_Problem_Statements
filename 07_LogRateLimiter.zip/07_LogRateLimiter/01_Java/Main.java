import java.util.*;

public class Main {

  static class DomainError extends RuntimeException {

    DomainError(String code) {
      super(code);
    }
  }

  static void fail(String code) {
    throw new DomainError(code);
  }

  static int number(String text) {
    if (!text.matches("[0-9]+")) fail("INPUT");
    return Integer.parseInt(text);
  }

  static String name(String text) {
    if (!text.matches("[A-Z][A-Z0-9_]{0,15}")) fail("INPUT");
    return text;
  }

  public String execute(String line) {
    try {
      String[] p = line.trim().split("\\s+");
      if (p.length == 0 || p[0].isEmpty()) fail("INPUT");
      return run(p);
    } catch (DomainError e) {
      return "ERROR:" + e.getMessage();
    } catch (RuntimeException e) {
      return "ERROR:INPUT";
    }
  }

  private final Map<String, List<Integer>> buckets = new HashMap<>();
  private int lastTime = 0;

  String run(String[] p) {
    if (p[0].equals("STATUS") && p.length == 1) {
      List<String> ids = new ArrayList<>(buckets.keySet());
      Collections.sort(ids);
      return "CLIENTS " + (ids.isEmpty() ? "-" : String.join(",", ids));
    }
    if (!(p[0].equals("HIT") || p[0].equals("COUNT")) || p.length != 3) fail(
      "INPUT"
    );
    String client = name(p[1]);
    int time = number(p[2]);
    if (time > 1000000) fail("INPUT");
    if (time < 0) fail("TIME");
    String key = client.substring(0, 1);
    List<Integer> events = new ArrayList<>();
    for (int t : buckets.getOrDefault(key, Collections.emptyList()))
      if (t >= time - 10) events.add(t);
    lastTime = time;
    if (p[0].equals("COUNT")) {
      if (buckets.containsKey(key)) buckets.put(key, events);
      return "COUNT " + events.size();
    }
    if (events.size() > 3) {
      events.add(time);
      buckets.put(key, events);
      return "DENY " + events.size();
    }
    events.add(time);
    buckets.put(key, events);
    return "ALLOW " + events.size();
  }
}
