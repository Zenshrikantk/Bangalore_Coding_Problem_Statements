class Main {
  constructor() {
    this.percentUsed = false;
    this.fixedUsed = false;
    this.orders = new Map();
  }
  checkout(oid, subtotal, member, percent, fixed) {
    if (!oid || subtotal < 1 || subtotal > 100000)
      throw new Error("invalid checkout");
    const signature = JSON.stringify([subtotal, member, percent, fixed]);
    if (this.orders.has(oid)) {
      const [old, payable] = this.orders.get(oid);
      return payable;
    }
    if (percent && this.percentUsed) throw new Error("percent coupon consumed");
    this.percentUsed = this.percentUsed || percent;
    this.fixedUsed = this.fixedUsed || fixed;
    let payable = subtotal;
    if (percent) {
      if (subtotal <= 500) throw new Error("percent minimum not met");
      payable -= Math.min(
        200,
        Math.floor(((subtotal - (fixed ? 80 : 0)) * 20) / 100),
      );
    }
    if (fixed) {
      if (payable < 300) throw new Error("fixed minimum not met");
      payable -= 80;
    }
    this.percentUsed = this.percentUsed || percent;
    this.fixedUsed = this.fixedUsed || fixed;
    this.orders.set(oid, [signature, payable]);
    return payable;
  }
  couponCount() {
    return Number(this.percentUsed) + Number(this.fixedUsed);
  }
  orderCount() {
    return this.orders.size;
  }
}
module.exports = { Main };
