const { Main } = require("./main");
const readline = require("readline");
const input = readline.createInterface({
  input: process.stdin,
  crlfDelay: Infinity,
});
const lines = input[Symbol.asyncIterator]();
async function read(prompt) {
  process.stdout.write(prompt + ": ");
  const next = await lines.next();
  return next.done ? null : next.value.trim();
}
async function value(prompt, kind) {
  const text = await read(prompt);
  if (text === null) throw new Error("end of input");
  if (kind === "int") {
    if (!/^-?[0-9]+$/.test(text) || !Number.isSafeInteger(Number(text)))
      throw new Error("enter an integer");
    return Number(text);
  }
  if (kind === "bool") {
    if (!["true", "false"].includes(text.toLowerCase()))
      throw new Error("enter true or false");
    return text.toLowerCase() === "true";
  }
  return text;
}
function report(m) {
  console.log("couponCount:", m.couponCount());
  console.log("orderCount:", m.orderCount());
}
function demo() {
  const m = new Main();
  console.log("Result:", m.checkout("DEMO", 600, true, true, true));
  console.log("Result:", m.checkout("DEMO", 600, true, true, true));
  report(m);
}
async function main() {
  let m = new Main();
  console.log("Atomic Coupon Checkout — fictional training exercise");
  while (true) {
    const choice = await read(
      "\n1 Demo | 2 checkout | 3 Report | 4 Reset | 5 Exit\nChoice",
    );
    if (choice === null || choice === "5") break;
    try {
      if (choice === "1") demo();
      else if (choice === "2") {
        const v0 = await value("Order ID", "str");
        const v1 = await value("Subtotal", "int");
        const v2 = await value("Member (true/false)", "bool");
        const v3 = await value("Use percent coupon (true/false)", "bool");
        const v4 = await value("Use fixed coupon (true/false)", "bool");
        console.log("Result:", m.checkout(v0, v1, v2, v3, v4));
      } else if (choice === "3") report(m);
      else if (choice === "4") {
        m = new Main();
        console.log("Reset complete");
      } else console.log("Enter 1 through 5");
    } catch (error) {
      console.log("Error:", error.message);
    }
  }
  input.close();
}
main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
