const { Main } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function rejects(fn) {
  try {
    fn();
  } catch (error) {
    if (error instanceof Error) return;
    throw error;
  }
  throw new Error("expected Error");
}
function tc1() {
  const m = new Main();
  eq(600, m.checkout("A", 600, false, false, false));
  eq(1, m.orderCount());
}
function tc2() {
  const m = new Main();
  rejects(() => m.checkout("A", 0, true, false, false));
  eq(0, m.orderCount());
}
function tc3() {
  const m = new Main();
  eq(400, m.checkout("A", 500, true, true, false));
}
function tc4() {
  const m = new Main();
  eq(850, m.checkout("A", 1000, true, true, false));
}
function tc5() {
  const m = new Main();
  eq(400, m.checkout("A", 600, true, true, true));
}
function tc6() {
  const m = new Main();
  rejects(() => m.checkout("A", 600, false, true, false));
  eq(0, m.couponCount());
}
function tc7() {
  const m = new Main();
  rejects(() => m.checkout("A", 400, true, true, true));
  eq(0, m.couponCount());
  eq(0, m.orderCount());
}
function tc8() {
  const m = new Main();
  eq(320, m.checkout("A", 400, false, false, true));
  rejects(() => m.checkout("B", 400, false, false, true));
  eq(1, m.orderCount());
}
function tc9() {
  const m = new Main();
  eq(600, m.checkout("A", 600, false, false, false));
  rejects(() => m.checkout("A", 700, false, false, false));
}
function tc10() {
  // Start Main(). checkout(BAD, 499, True, True, False) must reject; couponCount() must return 0; checkout(OK, 500, True, True, True) must return 320; checkout(OK, 500, True, True, True) must return 320; checkout(NEW, 500, True, False, True) must reject; couponCount() must return 2; orderCount() must return 1. Verify state using explicit expected values.
  throw new Error("Implement TC10 with independent expected values");
}
let passed = 0;
[tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10].forEach((test, index) => {
  try {
    test();
    passed++;
    console.log(`TC${index + 1}: PASS`);
  } catch (error) {
    console.log(`TC${index + 1}: FAIL (${error.message})`);
  }
});
console.log(`SUMMARY: ${passed}/10 PASS; ${10 - passed} FAIL`);
process.exitCode = passed === 10 ? 0 : 1;
