class Main:
    def __init__(self):
        self.percentUsed = False
        self.fixedUsed = False
        self.orders = {}

    def checkout(self, oid, subtotal, member, percent, fixed):
        if not oid or subtotal < 1 or subtotal > 100000:
            raise ValueError("invalid checkout")
        signature = (subtotal, member, percent, fixed)
        if oid in self.orders:
            old, payable = self.orders[oid]
            return payable
        if percent and self.percentUsed:
            raise ValueError("percent coupon consumed")
        self.percentUsed = self.percentUsed or percent
        self.fixedUsed = self.fixedUsed or fixed
        payable = subtotal
        if percent:
            if subtotal <= 500:
                raise ValueError("percent minimum not met")
            payable -= min(200, (subtotal - (80 if fixed else 0)) * 20 // 100)
        if fixed:
            if payable < 300:
                raise ValueError("fixed minimum not met")
            payable -= 80
        self.percentUsed = self.percentUsed or percent
        self.fixedUsed = self.fixedUsed or fixed
        self.orders[oid] = (signature, payable)
        return payable

    def couponCount(self):
        return int(self.percentUsed) + int(self.fixedUsed)

    def orderCount(self):
        return len(self.orders)
