from main import Main


def read_value(prompt, kind):
    text = input(prompt + ": ").strip()
    if kind == "int":
        return int(text)
    if kind == "bool":
        if text.lower() not in ("true", "false"):
            raise ValueError("enter true or false")
        return text.lower() == "true"
    return text


def report(m):
    print("couponCount:", m.couponCount())
    print("orderCount:", m.orderCount())


def demo():
    m = Main()
    print("Result:", m.checkout("DEMO", 600, True, True, True))
    print("Result:", m.checkout("DEMO", 600, True, True, True))
    report(m)


def main():
    m = Main()
    print("Atomic Coupon Checkout — fictional training exercise")
    while True:
        try:
            choice = input(
                "\n1 Demo | 2 checkout | 3 Report | 4 Reset | 5 Exit\nChoice: "
            ).strip()
            if choice == "5":
                break
            if choice == "1":
                demo()
            elif choice == "2":
                v0 = read_value("Order ID", "str")
                v1 = read_value("Subtotal", "int")
                v2 = read_value("Member (true/false)", "bool")
                v3 = read_value("Use percent coupon (true/false)", "bool")
                v4 = read_value("Use fixed coupon (true/false)", "bool")
                print("Result:", m.checkout(v0, v1, v2, v3, v4))
            elif choice == "3":
                report(m)
            elif choice == "4":
                m = Main()
                print("Reset complete")
            else:
                print("Enter 1 through 5")
        except EOFError:
            break
        except (ValueError, TypeError) as error:
            print("Error:", error)


if __name__ == "__main__":
    main()
