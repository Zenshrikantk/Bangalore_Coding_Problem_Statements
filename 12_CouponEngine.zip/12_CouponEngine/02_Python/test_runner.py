from main import Main


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    m = Main()
    eq(600, m.checkout("A", 600, False, False, False))
    eq(1, m.orderCount())


def tc2():
    m = Main()
    rejects(lambda: m.checkout("A", 0, True, False, False))
    eq(0, m.orderCount())


def tc3():
    m = Main()
    eq(400, m.checkout("A", 500, True, True, False))


def tc4():
    m = Main()
    eq(850, m.checkout("A", 1000, True, True, False))


def tc5():
    m = Main()
    eq(400, m.checkout("A", 600, True, True, True))


def tc6():
    m = Main()
    rejects(lambda: m.checkout("A", 600, False, True, False))
    eq(0, m.couponCount())


def tc7():
    m = Main()
    rejects(lambda: m.checkout("A", 400, True, True, True))
    eq(0, m.couponCount())
    eq(0, m.orderCount())


def tc8():
    m = Main()
    eq(320, m.checkout("A", 400, False, False, True))
    rejects(lambda: m.checkout("B", 400, False, False, True))
    eq(1, m.orderCount())


def tc9():
    m = Main()
    eq(600, m.checkout("A", 600, False, False, False))
    rejects(lambda: m.checkout("A", 700, False, False, False))


def tc10():
    # Start Main(). checkout(BAD, 499, True, True, False) must reject; couponCount() must return 0; checkout(OK, 500, True, True, True) must return 320; checkout(OK, 500, True, True, True) must return 320; checkout(NEW, 500, True, False, True) must reject; couponCount() must return 2; orderCount() must return 1. Verify state using explicit expected values.
    raise AssertionError("Implement TC10 with independent expected values")


if __name__ == "__main__":
    passed = 0
    for i, test in enumerate([tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10], 1):
        try:
            test()
            passed += 1
            print(f"TC{i}: PASS")
        except Exception as error:
            print(f"TC{i}: FAIL ({error})")
    print(f"SUMMARY: {passed}/10 PASS; {10-passed} FAIL")
    raise SystemExit(0 if passed == 10 else 1)
