import java.util.*;

public class App {

  static final Scanner input = new Scanner(System.in);

  static String read(String prompt) {
    System.out.print(prompt + ": ");
    return input.nextLine().trim();
  }

  static int number(String prompt) {
    return Integer.parseInt(read(prompt));
  }

  static boolean bool(String prompt) {
    String s = read(prompt).toLowerCase(Locale.ROOT);
    if (
      !s.equals("true") && !s.equals("false")
    ) throw new IllegalArgumentException("enter true or false");
    return Boolean.parseBoolean(s);
  }

  static void report(Main m) {
    System.out.println("couponCount: " + m.couponCount());
    System.out.println("orderCount: " + m.orderCount());
  }

  static void demo() {
    Main m = new Main();
    System.out.println("Result: " + m.checkout("DEMO", 600, true, true, true));
    System.out.println("Result: " + m.checkout("DEMO", 600, true, true, true));
    report(m);
  }

  public static void main(String[] args) {
    Main m = new Main();
    System.out.println("Atomic Coupon Checkout — fictional training exercise");
    while (true) {
      try {
        String choice = read(
          "\n1 Demo | 2 checkout | 3 Report | 4 Reset | 5 Exit\nChoice"
        );
        if (choice.equals("5")) break;
        if (choice.equals("1")) demo();
        else if (choice.equals("2")) {
          String v0 = read("Order ID");
          int v1 = number("Subtotal");
          boolean v2 = bool("Member (true/false)");
          boolean v3 = bool("Use percent coupon (true/false)");
          boolean v4 = bool("Use fixed coupon (true/false)");
          System.out.println("Result: " + m.checkout(v0, v1, v2, v3, v4));
        } else if (choice.equals("3")) report(m);
        else if (choice.equals("4")) {
          m = new Main();
          System.out.println("Reset complete");
        } else System.out.println("Enter 1 through 5");
      } catch (NoSuchElementException error) {
        break;
      } catch (IllegalArgumentException error) {
        System.out.println("Error: " + error.getMessage());
      }
    }
  }
}
