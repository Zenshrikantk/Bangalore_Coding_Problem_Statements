# 12 · Atomic Coupon Checkout

Track: Policy · Difficulty: Intermediate · Suggested time: 90–120 minutes

Repair a checkout calculator that applies two ordered coupons and consumes them only after a valid purchase.

This is a fictional training policy, not a real commercial or employment rule. The starter runs but deliberately violates this specification. Diagnose the failures, repair the business logic and implement TC10.

## API and data model

`Main()` owns the ledger and its receipt records. Public method names are identical across the three languages. The primary operation is `checkout(Order ID, Subtotal, Member (true/false), Use percent coupon (true/false), Use fixed coupon (true/false))`. Read-only methods are `couponCount()`, `orderCount()`.

Java rejects invalid operations with `IllegalArgumentException`, Python with `ValueError`, and JavaScript with `Error`. Tests use integer values, strings and booleans of the declared types; fractional numbers and cross-type coercions are out of scope. No database, network, clock or concurrent access is needed.

## Authoritative rules

1. All amounts are integer training credits. checkout(id, subtotal, member, percent, fixed) accepts a nonempty string ID, subtotal 1–100000 and three booleans. This service models one customer; every coupon can be consumed once across that customer’s purchases.
2. The percent coupon is for members only and requires original subtotal >= 500. It takes 20% of the original subtotal, rounded down, capped at 150 credits.
3. Apply the percent coupon first. The fixed coupon then requires the remaining payable amount >= 300 and subtracts 80 credits. Both selected coupons must be eligible and unused; otherwise reject the whole purchase.
4. With no selected coupon, payable equals subtotal. couponCount() reports consumed coupon types (0, 1 or 2); orderCount() reports successful unique purchase IDs.
5. Validate argument ranges, then handle a stored ID. An exact replay of all four non-ID arguments returns its original payable even after coupons were consumed. A different argument under that ID is a conflict.
6. For new IDs, check availability and all eligibility, compute the final payable, then atomically store the receipt and consume selected coupons. Any rejection leaves coupons and orders unchanged.

## Worked examples

- **Input:** Member checkout 600 with both coupons. **Expected:** 400 payable; two coupons consumed. 20% of 600 is 120; residual 480 qualifies for the fixed 80 reduction.
- **Input:** Member checkout 1000 with only percent coupon. **Expected:** 850 payable. The computed 200 discount is capped at 150.

## Supplied tests

Every test creates a fresh instance. Test fixtures are explicit in each runner.

| Case | Purpose | Required outcome |
|---|---|---|
| TC1 | Plain checkout | 600 payable and one order |
| TC2 | Invalid subtotal | Rejected and zero orders |
| TC3 | Exact percent threshold | 400 payable at threshold 500 |
| TC4 | Percent discount cap | 150 maximum discount |
| TC5 | Ordered stacking | 400 payable after percent then fixed |
| TC6 | Membership eligibility | Nonmember rejected without consumption |
| TC7 | Failure is atomic | Ineligible stack consumes nothing |
| TC8 | Single-use coupon | Second use rejected; one order |
| TC9 | Conflicting order retry | Changed subtotal under same ID rejected |

## TC10 — candidate-owned test

Start Main(). checkout(BAD, 499, True, True, False) must reject; couponCount() must return 0; checkout(OK, 500, True, True, True) must return 320; checkout(OK, 500, True, True, True) must return 320; checkout(NEW, 500, True, False, True) must reject; couponCount() must return 2; orderCount() must return 1. Verify state using explicit expected values.

Expected final result: **320 payable once; exactly two consumed coupon types and one order**. Replace only the TC10 stub with real assertions; do not call the implementation to derive expected values.

## Run

Choose one language folder. Each folder contains this complete statement as `PROBLEM.md`, the business implementation, a test runner and a console app. No third-party dependencies are needed.

### Java

From `01_Java`:

```sh
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

### Python

From `02_Python`:

```sh
python3 test_runner.py
python3 app.py
```

### JavaScript

From `03_JavaScript`:

```sh
node test_runner.js
node app.js
```

Use a working JDK 17+ for Java, Python 3.8+ or Node.js 18+. The test runner always attempts all ten cases and exits nonzero if any fail. A repaired application with an unfinished TC10 should report 9/10; complete work reports 10/10.

## Console workflow

The console starts with `Main()`. Option 1 runs an isolated demonstration; option 2 accepts user values for `checkout`; option 3 reports the current instance; option 4 resets it; option 5 exits. The demo does not change your working instance. Invalid input prints an error and returns to the menu.

## Deliverables

1. Record the initial results and a concise root-cause log.
2. Fix business code while preserving the public methods and supplied TC1–TC9 assertions.
3. Complete TC10, reach ten passing cases and demonstrate the console with an independent example.
4. Explain each repair and its boundary cases; do not hard-code fixture answers or disable tests.

## Discussion

- Why is stacking order part of the specification?
- Why can an exact replay bypass used-coupon checks?
- How should a failed multi-coupon checkout behave?
