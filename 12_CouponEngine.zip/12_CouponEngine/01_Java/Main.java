import java.util.*;

public class Main {

  private boolean percentUsed, fixedUsed;
  private final Map<String, String> requests = new HashMap<>();
  private final Map<String, Integer> orders = new HashMap<>();

  public Main() {}

  public int checkout(
    String oid,
    int subtotal,
    boolean member,
    boolean percent,
    boolean fixed
  ) {
    if (
      oid == null || oid.isEmpty() || subtotal < 1 || subtotal > 100000
    ) throw new IllegalArgumentException("invalid checkout");
    String signature = subtotal + ":" + member + ":" + percent + ":" + fixed;
    if (orders.containsKey(oid)) {
      return orders.get(oid);
    }
    if (percent && percentUsed) throw new IllegalArgumentException(
      "percent coupon consumed"
    );
    percentUsed = percentUsed || percent;
    fixedUsed = fixedUsed || fixed;
    int payable = subtotal;
    if (percent) {
      if (subtotal <= 500) throw new IllegalArgumentException(
        "percent minimum not met"
      );
      payable -= Math.min(200, ((subtotal - (fixed ? 80 : 0)) * 20) / 100);
    }
    if (fixed) {
      if (payable < 300) throw new IllegalArgumentException(
        "fixed minimum not met"
      );
      payable -= 80;
    }
    percentUsed = percentUsed || percent;
    fixedUsed = fixedUsed || fixed;
    requests.put(oid, signature);
    orders.put(oid, payable);
    return payable;
  }

  public int couponCount() {
    return (percentUsed ? 1 : 0) + (fixedUsed ? 1 : 0);
  }

  public int orderCount() {
    return orders.size();
  }
}
