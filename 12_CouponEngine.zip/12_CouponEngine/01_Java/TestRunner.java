import java.util.*;

public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!Objects.equals(expected, actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void rejects(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException error) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Main m = new Main();
    eq(600, m.checkout("A", 600, false, false, false));
    eq(1, m.orderCount());
  }

  static void tc2() {
    Main m = new Main();
    rejects(() -> m.checkout("A", 0, true, false, false));
    eq(0, m.orderCount());
  }

  static void tc3() {
    Main m = new Main();
    eq(400, m.checkout("A", 500, true, true, false));
  }

  static void tc4() {
    Main m = new Main();
    eq(850, m.checkout("A", 1000, true, true, false));
  }

  static void tc5() {
    Main m = new Main();
    eq(400, m.checkout("A", 600, true, true, true));
  }

  static void tc6() {
    Main m = new Main();
    rejects(() -> m.checkout("A", 600, false, true, false));
    eq(0, m.couponCount());
  }

  static void tc7() {
    Main m = new Main();
    rejects(() -> m.checkout("A", 400, true, true, true));
    eq(0, m.couponCount());
    eq(0, m.orderCount());
  }

  static void tc8() {
    Main m = new Main();
    eq(320, m.checkout("A", 400, false, false, true));
    rejects(() -> m.checkout("B", 400, false, false, true));
    eq(1, m.orderCount());
  }

  static void tc9() {
    Main m = new Main();
    eq(600, m.checkout("A", 600, false, false, false));
    rejects(() -> m.checkout("A", 700, false, false, false));
  }

  static void tc10() {
    // Start Main(). checkout(BAD, 499, True, True, False) must reject; couponCount() must return 0; checkout(OK, 500, True, True, True) must return 320; checkout(OK, 500, True, True, True) must return 320; checkout(NEW, 500, True, False, True) must reject; couponCount() must return 2; orderCount() must return 1. Verify state using explicit expected values.
    throw new AssertionError("Implement TC10 with independent expected values");
  }

  public static void main(String[] args) {
    Runnable[] tests = {
      TestRunner::tc1,
      TestRunner::tc2,
      TestRunner::tc3,
      TestRunner::tc4,
      TestRunner::tc5,
      TestRunner::tc6,
      TestRunner::tc7,
      TestRunner::tc8,
      TestRunner::tc9,
      TestRunner::tc10,
    };
    int passed = 0;
    for (int i = 0; i < tests.length; i++) {
      try {
        tests[i].run();
        passed++;
        System.out.println("TC" + (i + 1) + ": PASS");
      } catch (Exception | AssertionError error) {
        System.out.println(
          "TC" + (i + 1) + ": FAIL (" + error.getMessage() + ")"
        );
      }
    }
    System.out.println(
      "SUMMARY: " + passed + "/10 PASS; " + (10 - passed) + " FAIL"
    );
    if (passed != 10) System.exit(1);
  }
}
