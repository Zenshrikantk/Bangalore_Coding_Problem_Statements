from main import Main


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    m = Main()
    eq(10, m.checkIn(10, 500))
    eq(1, m.dayCount())


def tc2():
    m = Main()
    rejects(lambda: m.checkIn(-1, 500))
    eq(0, m.dayCount())


def tc3():
    m = Main()
    eq(10, m.checkIn(10, 540))


def tc4():
    m = Main()
    rejects(lambda: m.checkIn(10, 601))
    eq(0, m.dayCount())


def tc5():
    m = Main()
    eq(10, m.checkIn(10, 500))
    eq(10, m.checkIn(12, 500))
    eq(1, m.currentStreak())


def tc6():
    m = Main()
    eq(10, m.checkIn(10, 500))
    eq(10, m.checkIn(11, 500))
    eq(15, m.checkIn(12, 500))


def tc7():
    m = Main()
    eq(10, m.checkIn(10, 500))
    eq(10, m.checkIn(10, 560))
    eq(1, m.dayCount())


def tc8():
    m = Main()
    eq(10, m.checkIn(10, 500))
    eq(10, m.checkIn(12, 500))
    eq(20, m.totalCredits())


def tc9():
    m = Main()
    eq(10, m.checkIn(12, 500))
    rejects(lambda: m.checkIn(11, 500))
    eq(1, m.dayCount())


def tc10():
    # Start Main(). checkIn(10, 540) must return 10; checkIn(11, 600) must return 4; checkIn(12, 539) must return 15; checkIn(12, 900) must return 15; checkIn(13, 601) must reject; totalCredits() must return 29; currentStreak() must return 3; dayCount() must return 3. Verify state using explicit expected values.
    raise AssertionError("Implement TC10 with independent expected values")


if __name__ == "__main__":
    passed = 0
    for i, test in enumerate([tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10], 1):
        try:
            test()
            passed += 1
            print(f"TC{i}: PASS")
        except Exception as error:
            print(f"TC{i}: FAIL ({error})")
    print(f"SUMMARY: {passed}/10 PASS; {10-passed} FAIL")
    raise SystemExit(0 if passed == 10 else 1)
