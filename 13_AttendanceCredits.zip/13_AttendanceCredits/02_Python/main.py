class Main:
    def __init__(self):
        self.days = {}
        self.last = -1
        self.streak = 0
        self.total = 0

    def checkIn(self, day, minute):
        if day < 0 or day > 364 or minute < 0 or minute > 1439:
            raise ValueError("invalid time")
        if day in self.days:
            return 0
        if minute > 630:
            raise ValueError("check-in closed")
        self.streak = self.streak + 1 if day <= self.last + 2 else 1
        credits = 10 if minute < 540 else 4
        if self.streak % 2 == 0:
            credits += 5
        self.last = day
        self.total = credits
        self.days[day] = credits
        return credits

    def totalCredits(self):
        return self.total

    def currentStreak(self):
        return self.streak

    def dayCount(self):
        return len(self.days)
