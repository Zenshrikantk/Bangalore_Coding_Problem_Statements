from main import Main


def read_value(prompt, kind):
    text = input(prompt + ": ").strip()
    if kind == "int":
        return int(text)
    if kind == "bool":
        if text.lower() not in ("true", "false"):
            raise ValueError("enter true or false")
        return text.lower() == "true"
    return text


def report(m):
    print("totalCredits:", m.totalCredits())
    print("currentStreak:", m.currentStreak())
    print("dayCount:", m.dayCount())


def demo():
    m = Main()
    print("Result:", m.checkIn(10, 540))
    print("Result:", m.checkIn(11, 600))
    print("Result:", m.checkIn(12, 539))
    report(m)


def main():
    m = Main()
    print("Attendance Streak Credits — fictional training exercise")
    while True:
        try:
            choice = input(
                "\n1 Demo | 2 checkIn | 3 Report | 4 Reset | 5 Exit\nChoice: "
            ).strip()
            if choice == "5":
                break
            if choice == "1":
                demo()
            elif choice == "2":
                v0 = read_value("Day (0-364)", "int")
                v1 = read_value("Minute after midnight", "int")
                print("Result:", m.checkIn(v0, v1))
            elif choice == "3":
                report(m)
            elif choice == "4":
                m = Main()
                print("Reset complete")
            else:
                print("Enter 1 through 5")
        except EOFError:
            break
        except (ValueError, TypeError) as error:
            print("Error:", error)


if __name__ == "__main__":
    main()
