class Main {
  constructor() {
    this.days = new Map();
    this.last = -1;
    this.streak = 0;
    this.total = 0;
  }
  checkIn(day, minute) {
    if (day < 0 || day > 364 || minute < 0 || minute > 1439)
      throw new Error("invalid time");
    if (this.days.has(day)) return 0;
    if (minute > 630) throw new Error("check-in closed");
    this.streak = day <= this.last + 2 ? this.streak + 1 : 1;
    let credits = minute < 540 ? 10 : 4;
    if (this.streak % 2 === 0) credits += 5;
    this.last = day;
    this.total = credits;
    this.days.set(day, credits);
    return credits;
  }
  totalCredits() {
    return this.total;
  }
  currentStreak() {
    return this.streak;
  }
  dayCount() {
    return this.days.size;
  }
}
module.exports = { Main };
