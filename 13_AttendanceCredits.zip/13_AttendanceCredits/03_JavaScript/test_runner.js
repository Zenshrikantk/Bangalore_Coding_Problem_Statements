const { Main } = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function rejects(fn) {
  try {
    fn();
  } catch (error) {
    if (error instanceof Error) return;
    throw error;
  }
  throw new Error("expected Error");
}
function tc1() {
  const m = new Main();
  eq(10, m.checkIn(10, 500));
  eq(1, m.dayCount());
}
function tc2() {
  const m = new Main();
  rejects(() => m.checkIn(-1, 500));
  eq(0, m.dayCount());
}
function tc3() {
  const m = new Main();
  eq(10, m.checkIn(10, 540));
}
function tc4() {
  const m = new Main();
  rejects(() => m.checkIn(10, 601));
  eq(0, m.dayCount());
}
function tc5() {
  const m = new Main();
  eq(10, m.checkIn(10, 500));
  eq(10, m.checkIn(12, 500));
  eq(1, m.currentStreak());
}
function tc6() {
  const m = new Main();
  eq(10, m.checkIn(10, 500));
  eq(10, m.checkIn(11, 500));
  eq(15, m.checkIn(12, 500));
}
function tc7() {
  const m = new Main();
  eq(10, m.checkIn(10, 500));
  eq(10, m.checkIn(10, 560));
  eq(1, m.dayCount());
}
function tc8() {
  const m = new Main();
  eq(10, m.checkIn(10, 500));
  eq(10, m.checkIn(12, 500));
  eq(20, m.totalCredits());
}
function tc9() {
  const m = new Main();
  eq(10, m.checkIn(12, 500));
  rejects(() => m.checkIn(11, 500));
  eq(1, m.dayCount());
}
function tc10() {
  // Start Main(). checkIn(10, 540) must return 10; checkIn(11, 600) must return 4; checkIn(12, 539) must return 15; checkIn(12, 900) must return 15; checkIn(13, 601) must reject; totalCredits() must return 29; currentStreak() must return 3; dayCount() must return 3. Verify state using explicit expected values.
  throw new Error("Implement TC10 with independent expected values");
}
let passed = 0;
[tc1, tc2, tc3, tc4, tc5, tc6, tc7, tc8, tc9, tc10].forEach((test, index) => {
  try {
    test();
    passed++;
    console.log(`TC${index + 1}: PASS`);
  } catch (error) {
    console.log(`TC${index + 1}: FAIL (${error.message})`);
  }
});
console.log(`SUMMARY: ${passed}/10 PASS; ${10 - passed} FAIL`);
process.exitCode = passed === 10 ? 0 : 1;
