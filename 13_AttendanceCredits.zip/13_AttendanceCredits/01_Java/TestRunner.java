import java.util.*;

public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!Objects.equals(expected, actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void rejects(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException error) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    Main m = new Main();
    eq(10, m.checkIn(10, 500));
    eq(1, m.dayCount());
  }

  static void tc2() {
    Main m = new Main();
    rejects(() -> m.checkIn(-1, 500));
    eq(0, m.dayCount());
  }

  static void tc3() {
    Main m = new Main();
    eq(10, m.checkIn(10, 540));
  }

  static void tc4() {
    Main m = new Main();
    rejects(() -> m.checkIn(10, 601));
    eq(0, m.dayCount());
  }

  static void tc5() {
    Main m = new Main();
    eq(10, m.checkIn(10, 500));
    eq(10, m.checkIn(12, 500));
    eq(1, m.currentStreak());
  }

  static void tc6() {
    Main m = new Main();
    eq(10, m.checkIn(10, 500));
    eq(10, m.checkIn(11, 500));
    eq(15, m.checkIn(12, 500));
  }

  static void tc7() {
    Main m = new Main();
    eq(10, m.checkIn(10, 500));
    eq(10, m.checkIn(10, 560));
    eq(1, m.dayCount());
  }

  static void tc8() {
    Main m = new Main();
    eq(10, m.checkIn(10, 500));
    eq(10, m.checkIn(12, 500));
    eq(20, m.totalCredits());
  }

  static void tc9() {
    Main m = new Main();
    eq(10, m.checkIn(12, 500));
    rejects(() -> m.checkIn(11, 500));
    eq(1, m.dayCount());
  }

  static void tc10() {
    // Start Main(). checkIn(10, 540) must return 10; checkIn(11, 600) must return 4; checkIn(12, 539) must return 15; checkIn(12, 900) must return 15; checkIn(13, 601) must reject; totalCredits() must return 29; currentStreak() must return 3; dayCount() must return 3. Verify state using explicit expected values.
    throw new AssertionError("Implement TC10 with independent expected values");
  }

  public static void main(String[] args) {
    Runnable[] tests = {
      TestRunner::tc1,
      TestRunner::tc2,
      TestRunner::tc3,
      TestRunner::tc4,
      TestRunner::tc5,
      TestRunner::tc6,
      TestRunner::tc7,
      TestRunner::tc8,
      TestRunner::tc9,
      TestRunner::tc10,
    };
    int passed = 0;
    for (int i = 0; i < tests.length; i++) {
      try {
        tests[i].run();
        passed++;
        System.out.println("TC" + (i + 1) + ": PASS");
      } catch (Exception | AssertionError error) {
        System.out.println(
          "TC" + (i + 1) + ": FAIL (" + error.getMessage() + ")"
        );
      }
    }
    System.out.println(
      "SUMMARY: " + passed + "/10 PASS; " + (10 - passed) + " FAIL"
    );
    if (passed != 10) System.exit(1);
  }
}
