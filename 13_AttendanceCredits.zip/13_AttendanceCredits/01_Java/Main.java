import java.util.*;

public class Main {

  private final Map<Integer, Integer> days = new HashMap<>();
  private int last = -1,
    streak = 0,
    total = 0;

  public Main() {}

  public int checkIn(int day, int minute) {
    if (
      day < 0 || day > 364 || minute < 0 || minute > 1439
    ) throw new IllegalArgumentException("invalid time");
    if (days.containsKey(day)) return 0;
    if (minute > 630) throw new IllegalArgumentException("check-in closed");
    streak = day <= last + 2 ? streak + 1 : 1;
    int credits = minute < 540 ? 10 : 4;
    if (streak % 2 == 0) credits += 5;
    last = day;
    total = credits;
    days.put(day, credits);
    return credits;
  }

  public int totalCredits() {
    return total;
  }

  public int currentStreak() {
    return streak;
  }

  public int dayCount() {
    return days.size();
  }
}
