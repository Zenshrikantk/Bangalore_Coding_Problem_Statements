# 13 · Attendance Streak Credits

Track: Policy · Difficulty: Intermediate · Suggested time: 90–120 minutes

Repair a daily attendance ledger with cutoff minutes, idempotent check-ins and consecutive-day bonuses.

This is a fictional training policy, not a real commercial or employment rule. The starter runs but deliberately violates this specification. Diagnose the failures, repair the business logic and implement TC10.

## API and data model

`Main()` owns the ledger and its receipt records. Public method names are identical across the three languages. The primary operation is `checkIn(Day (0-364), Minute after midnight)`. Read-only methods are `totalCredits()`, `currentStreak()`, `dayCount()`.

Java rejects invalid operations with `IllegalArgumentException`, Python with `ValueError`, and JavaScript with `Error`. Tests use integer values, strings and booleans of the declared types; fractional numbers and cross-type coercions are out of scope. No database, network, clock or concurrent access is needed.

## Authoritative rules

1. All time values are plain integers: day 0–364 and minute 0–1439 after midnight. checkIn(day, minute) returns credits awarded for that day. Non-integer API inputs are outside the assessment contract.
2. A first check-in at minute <= 540 earns 10 credits. A check-in at minute 541 through 600 inclusive earns 4. Any new check-in after minute 600 is rejected.
3. Validate argument ranges first. A previously accepted day returns its original credit without changing any state, even if the new valid minute is later than the cutoff.
4. New days must be strictly later than the last accepted day. An earlier unrecorded day is rejected. A rejected day never advances the last accepted day or streak.
5. If the new accepted day equals lastDay + 1, increase streak by one. Otherwise reset streak to one. Award 5 extra credits on every third consecutive day (streak 3, 6, 9, ...), including late-but-accepted days.
6. totalCredits(), currentStreak() and dayCount() report cumulative credits, current streak, and unique accepted days. Replays do not change these values.

## Worked examples

- **Input:** Days 10, 11, 12 at minutes 540, 600, 539. **Expected:** 10 + 4 + 15 = 29 credits; streak 3. The third consecutive day adds a five-credit bonus.
- **Input:** Retry day 12 at minute 900, then try new day 13 at minute 601. **Expected:** Retry returns 15; day 13 rejected; total stays 29. A stored day is a receipt lookup; a new day must pass the cutoff.

## Supplied tests

Every test creates a fresh instance. Test fixtures are explicit in each runner.

| Case | Purpose | Required outcome |
|---|---|---|
| TC1 | First on-time day | 10 credits and one day |
| TC2 | Invalid day | Rejected without recording |
| TC3 | On-time cutoff | 10 at minute 540 |
| TC4 | Late cutoff rejection | Minute 601 rejected |
| TC5 | Gap breaks streak | Gap resets streak to one |
| TC6 | Third-day bonus | Third consecutive day earns 15 |
| TC7 | Duplicate returns original award | 10 again and one recorded day |
| TC8 | Credits accumulate | Total 20 across two accepted days |
| TC9 | Out-of-order new day | Earlier unrecorded day rejected |

## TC10 — candidate-owned test

Start Main(). checkIn(10, 540) must return 10; checkIn(11, 600) must return 4; checkIn(12, 539) must return 15; checkIn(12, 900) must return 15; checkIn(13, 601) must reject; totalCredits() must return 29; currentStreak() must return 3; dayCount() must return 3. Verify state using explicit expected values.

Expected final result: **29 credits, streak 3, three accepted days after replay and rejection**. Replace only the TC10 stub with real assertions; do not call the implementation to derive expected values.

## Run

Choose one language folder. Each folder contains this complete statement as `PROBLEM.md`, the business implementation, a test runner and a console app. No third-party dependencies are needed.

### Java

From `01_Java`:

```sh
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

### Python

From `02_Python`:

```sh
python3 test_runner.py
python3 app.py
```

### JavaScript

From `03_JavaScript`:

```sh
node test_runner.js
node app.js
```

Use a working JDK 17+ for Java, Python 3.8+ or Node.js 18+. The test runner always attempts all ten cases and exits nonzero if any fail. A repaired application with an unfinished TC10 should report 9/10; complete work reports 10/10.

## Console workflow

The console starts with `Main()`. Option 1 runs an isolated demonstration; option 2 accepts user values for `checkIn`; option 3 reports the current instance; option 4 resets it; option 5 exits. The demo does not change your working instance. Invalid input prints an error and returns to the menu.

## Deliverables

1. Record the initial results and a concise root-cause log.
2. Fix business code while preserving the public methods and supplied TC1–TC9 assertions.
3. Complete TC10, reach ten passing cases and demonstrate the console with an independent example.
4. Explain each repair and its boundary cases; do not hard-code fixture answers or disable tests.

## Discussion

- Does a rejected late day break a streak immediately?
- Why return the original credit on a duplicate?
- How would you test bonus boundaries?
