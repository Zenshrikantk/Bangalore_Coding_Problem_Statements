# Attendance Streak Credits — Java

Read [PROBLEM.md](PROBLEM.md) for the complete statement; [domain overview](../README.md) is also available in the master collection.

```sh
javac Main.java TestRunner.java App.java
java TestRunner
java App
```

The starter contains deliberate business-logic defects. Preserve TC1–TC9 and implement TC10. All ten tests run; any failure produces a nonzero exit status.
