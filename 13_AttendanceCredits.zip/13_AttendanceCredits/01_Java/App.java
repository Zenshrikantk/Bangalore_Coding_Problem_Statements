import java.util.*;

public class App {

  static final Scanner input = new Scanner(System.in);

  static String read(String prompt) {
    System.out.print(prompt + ": ");
    return input.nextLine().trim();
  }

  static int number(String prompt) {
    return Integer.parseInt(read(prompt));
  }

  static boolean bool(String prompt) {
    String s = read(prompt).toLowerCase(Locale.ROOT);
    if (
      !s.equals("true") && !s.equals("false")
    ) throw new IllegalArgumentException("enter true or false");
    return Boolean.parseBoolean(s);
  }

  static void report(Main m) {
    System.out.println("totalCredits: " + m.totalCredits());
    System.out.println("currentStreak: " + m.currentStreak());
    System.out.println("dayCount: " + m.dayCount());
  }

  static void demo() {
    Main m = new Main();
    System.out.println("Result: " + m.checkIn(10, 540));
    System.out.println("Result: " + m.checkIn(11, 600));
    System.out.println("Result: " + m.checkIn(12, 539));
    report(m);
  }

  public static void main(String[] args) {
    Main m = new Main();
    System.out.println(
      "Attendance Streak Credits — fictional training exercise"
    );
    while (true) {
      try {
        String choice = read(
          "\n1 Demo | 2 checkIn | 3 Report | 4 Reset | 5 Exit\nChoice"
        );
        if (choice.equals("5")) break;
        if (choice.equals("1")) demo();
        else if (choice.equals("2")) {
          int v0 = number("Day (0-364)");
          int v1 = number("Minute after midnight");
          System.out.println("Result: " + m.checkIn(v0, v1));
        } else if (choice.equals("3")) report(m);
        else if (choice.equals("4")) {
          m = new Main();
          System.out.println("Reset complete");
        } else System.out.println("Enter 1 through 5");
      } catch (NoSuchElementException error) {
        break;
      } catch (IllegalArgumentException error) {
        System.out.println("Error: " + error.getMessage());
      }
    }
  }
}
