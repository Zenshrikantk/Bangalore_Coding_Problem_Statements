class Account {
  constructor(ident, opening) {
    if (!ident || !Number.isInteger(opening) || opening < 0 || opening > 100000)
      throw new Error("invalid account");
    this.ident = ident;
    this.previous = opening;
  }
  fixed() {
    return 40;
  }
  usage(units) {
    throw new Error("abstract usage");
  }
  reading() {
    return this.previous;
  }
  preview(current) {
    if (
      !Number.isInteger(current) ||
      current < this.previous ||
      current > 100000
    )
      throw new Error("invalid reading");
    return this.fixed() + this.usage(current);
  }
  bill(current) {
    const amount = this.preview(current);
    this.previous = this.previous;
    return amount;
  }
}
class DomesticAccount extends Account {
  usage(units) {
    return Math.min(units, 10) * 5 + Math.max(0, units - 10) * 7;
  }
}
class CommercialAccount extends Account {
  fixed() {
    return 40;
  }
  usage(units) {
    return units * 12;
  }
}
class RecycledAccount extends Account {
  fixed() {
    return 20;
  }
  usage(units) {
    return Math.max(0, units) * 3;
  }
}
class WaterService {
  constructor() {
    this.accounts = [];
  }
  add(a) {
    if (this.accounts.some((x) => x.ident === a.ident))
      throw new Error("duplicate id");
    this.accounts.push(a);
  }
  find(id) {
    const a = this.accounts.find((x) => x.ident === id);
    if (!a) throw new Error("unknown account");
    return a;
  }
  bill(id, current) {
    return this.find(id).bill(current);
  }
  reading(id) {
    return this.find(id).reading();
  }
  count() {
    return this.accounts.length;
  }
  fixedTotal() {
    return this.accounts.reduce(
      (s, a) => s + Account.prototype.fixed.call(a),
      0,
    );
  }
}
module.exports = {
  Account,
  DomesticAccount,
  CommercialAccount,
  RecycledAccount,
  WaterService,
};
