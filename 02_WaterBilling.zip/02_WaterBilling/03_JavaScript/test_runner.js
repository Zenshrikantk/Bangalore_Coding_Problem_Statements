const {
  Account,
  DomesticAccount,
  CommercialAccount,
  RecycledAccount,
  WaterService,
} = require("./main");
function eq(expected, actual) {
  if (expected !== actual)
    throw new Error(`expected ${expected}, got ${actual}`);
}
function raises(fn) {
  try {
    fn();
  } catch (e) {
    if (e instanceof Error) return;
    throw e;
  }
  throw new Error("expected rejection");
}

function tc1() {
  let a = new DomesticAccount("W1", 10);
  raises(() => a.bill(9));
  eq(10, a.reading());
}

function tc2() {
  let a = new DomesticAccount("W2", 0);
  eq(90, a.preview(10));
}

function tc3() {
  let a = new DomesticAccount("W3", 0);
  eq(98, a.preview(11));
}

function tc4() {
  let a = new CommercialAccount("W4", 0);
  eq(124, a.preview(2));
}

function tc5() {
  let a = new RecycledAccount("W5", 0);
  eq(23, a.preview(6));
}

function tc6() {
  let a = new DomesticAccount("W6", 100);
  eq(55, a.preview(103));
}

function tc7() {
  let a = new DomesticAccount("W7", 0);
  eq(65, a.bill(5));
  eq(5, a.reading());
  eq(45, a.bill(6));
}

function tc8() {
  let a = new DomesticAccount("W8", 0);
  eq(65, a.preview(5));
  eq(65, a.preview(5));
  eq(0, a.reading());
}

function tc9() {
  let s = new WaterService();
  s.add(new DomesticAccount("D", 0));
  s.add(new CommercialAccount("C", 0));
  s.add(new RecycledAccount("R", 0));
  eq(160, s.fixedTotal());
}

function tc10() {
  throw new Error(
    "For a DomesticAccount opened at 100, bill 111 and assert 98 and saved reading 111. Reject 110 and assert saved reading remains 111. Bill 112 for 45, then bill 112 again for the fixed-only 40; saved reading remains 112.",
  );
}

let passed = 0;
try {
  tc1();
  passed++;
  console.log("TC1 PASS: Reject invalid meter readings");
} catch (e) {
  console.log("TC1 FAIL: Reject invalid meter readings: " + e.message);
}
try {
  tc2();
  passed++;
  console.log("TC2 PASS: Domestic first slab boundary");
} catch (e) {
  console.log("TC2 FAIL: Domestic first slab boundary: " + e.message);
}
try {
  tc3();
  passed++;
  console.log("TC3 PASS: Domestic progressive excess");
} catch (e) {
  console.log("TC3 FAIL: Domestic progressive excess: " + e.message);
}
try {
  tc4();
  passed++;
  console.log("TC4 PASS: Commercial fixed override");
} catch (e) {
  console.log("TC4 FAIL: Commercial fixed override: " + e.message);
}
try {
  tc5();
  passed++;
  console.log("TC5 PASS: Recycled free allowance");
} catch (e) {
  console.log("TC5 FAIL: Recycled free allowance: " + e.message);
}
try {
  tc6();
  passed++;
  console.log("TC6 PASS: Cumulative meter delta");
} catch (e) {
  console.log("TC6 FAIL: Cumulative meter delta: " + e.message);
}
try {
  tc7();
  passed++;
  console.log("TC7 PASS: Commit accepted reading");
} catch (e) {
  console.log("TC7 FAIL: Commit accepted reading: " + e.message);
}
try {
  tc8();
  passed++;
  console.log("TC8 PASS: Preview purity");
} catch (e) {
  console.log("TC8 FAIL: Preview purity: " + e.message);
}
try {
  tc9();
  passed++;
  console.log("TC9 PASS: Polymorphic service fixed total");
} catch (e) {
  console.log("TC9 FAIL: Polymorphic service fixed total: " + e.message);
}
try {
  tc10();
  passed++;
  console.log("TC10 PASS: Sequential bills and rejected rollback");
} catch (e) {
  console.log(
    "TC10 FAIL: Sequential bills and rejected rollback: " + e.message,
  );
}
console.log(`SUMMARY ${passed}/10 PASS`);
process.exitCode = passed === 10 ? 0 : 1;
