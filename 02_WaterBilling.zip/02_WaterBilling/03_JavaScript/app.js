const {
  Account,
  DomesticAccount,
  CommercialAccount,
  RecycledAccount,
  WaterService,
} = require("./main");
const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const lines = [];
let waiter = null,
  ended = false;
rl.on("line", (line) => {
  if (waiter) {
    const w = waiter;
    waiter = null;
    w(line);
  } else lines.push(line);
});
rl.on("close", () => {
  ended = true;
  if (waiter) {
    waiter(null);
    waiter = null;
  }
});
async function ask(prompt) {
  process.stdout.write(prompt);
  if (lines.length) return lines.shift();
  if (ended) return null;
  return await new Promise((r) => (waiter = r));
}
function number(s) {
  if (s === null || s.trim() === "" || !Number.isInteger(Number(s)))
    throw new Error("integer required");
  return Number(s);
}
function make() {
  const s = new WaterService();
  s.add(new DomesticAccount("HOME", 100));
  s.add(new CommercialAccount("SHOP", 200));
  s.add(new RecycledAccount("GARDEN", 0));
  return s;
}
(async () => {
  let state = make();
  try {
    while (true) {
      console.log("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit");
      const choice = await ask("> ");
      if (choice === null || choice === "5") break;
      try {
        if (choice === "1") {
          console.log(
            "Domestic 100→111:",
            new DomesticAccount("DEMO", 100).preview(111),
          );
        } else if (choice === "2") {
          const id = await ask("Account HOME/SHOP/GARDEN: "),
            reading = number(await ask("Cumulative reading: "));
          console.log("Bill:", state.bill(id, reading));
        } else if (choice === "3") {
          console.log("Fixed total:", state.fixedTotal());
          for (const id of ["HOME", "SHOP", "GARDEN"])
            console.log(id, state.reading(id));
        } else if (choice === "4") {
          state = make();
          console.log(
            "Reset opening meters: HOME=100, SHOP=200, GARDEN=0. Every accepted bill charges its fixed fee.",
          );
        } else console.log("Choose 1–5");
      } catch (e) {
        console.log("Rejected: " + e.message);
      }
    }
  } finally {
    rl.close();
  }
})();
