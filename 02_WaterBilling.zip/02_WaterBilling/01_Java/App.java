import java.util.*;

public class App {

  static Scanner in = new Scanner(System.in);

  static String ask(String p) {
    System.out.print(p);
    if (!in.hasNextLine()) throw new NoSuchElementException();
    return in.nextLine().trim();
  }

  static int number(String p) {
    return Integer.parseInt(ask(p));
  }

  static WaterService make() {
    WaterService s = new WaterService();
    s.add(new DomesticAccount("HOME", 100));
    s.add(new CommercialAccount("SHOP", 200));
    s.add(new RecycledAccount("GARDEN", 0));
    return s;
  }

  public static void main(String[] args) {
    WaterService state = make();
    while (true) {
      System.out.println(
        "1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit"
      );
      try {
        String choice = ask("> ");
        if (choice.equals("5")) break;
        switch (choice) {
          case "1": {
            System.out.println(
              "Domestic 100→111: " +
                new DomesticAccount("DEMO", 100).preview(111)
            );
            break;
          }
          case "2": {
            String id = ask("Account HOME/SHOP/GARDEN: ");
            int reading = number("Cumulative reading: ");
            System.out.println("Bill: " + state.bill(id, reading));
            break;
          }
          case "3": {
            System.out.println("Fixed total: " + state.fixedTotal());
            for (String id : new String[] { "HOME", "SHOP", "GARDEN" })
              System.out.println(id + " " + state.reading(id));
            break;
          }
          case "4": {
            state = make();
            System.out.println(
              "Reset opening meters: HOME=100, SHOP=200, GARDEN=0. Every accepted bill charges its fixed fee."
            );
            break;
          }
          default:
            System.out.println("Choose 1–5");
        }
      } catch (NoSuchElementException e) {
        break;
      } catch (IllegalArgumentException e) {
        System.out.println("Rejected: " + e.getMessage());
      }
    }
  }
}
