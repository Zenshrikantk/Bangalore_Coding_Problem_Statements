public class TestRunner {

  static void eq(Object expected, Object actual) {
    if (!expected.equals(actual)) throw new AssertionError(
      "expected " + expected + ", got " + actual
    );
  }

  static void raises(Runnable fn) {
    try {
      fn.run();
    } catch (IllegalArgumentException e) {
      return;
    }
    throw new AssertionError("expected IllegalArgumentException");
  }

  static void tc1() {
    DomesticAccount a = new DomesticAccount("W1", 10);
    raises(() -> a.bill(9));
    eq(10, a.reading());
  }

  static void tc2() {
    DomesticAccount a = new DomesticAccount("W2", 0);
    eq(90, a.preview(10));
  }

  static void tc3() {
    DomesticAccount a = new DomesticAccount("W3", 0);
    eq(98, a.preview(11));
  }

  static void tc4() {
    CommercialAccount a = new CommercialAccount("W4", 0);
    eq(124, a.preview(2));
  }

  static void tc5() {
    RecycledAccount a = new RecycledAccount("W5", 0);
    eq(23, a.preview(6));
  }

  static void tc6() {
    DomesticAccount a = new DomesticAccount("W6", 100);
    eq(55, a.preview(103));
  }

  static void tc7() {
    DomesticAccount a = new DomesticAccount("W7", 0);
    eq(65, a.bill(5));
    eq(5, a.reading());
    eq(45, a.bill(6));
  }

  static void tc8() {
    DomesticAccount a = new DomesticAccount("W8", 0);
    eq(65, a.preview(5));
    eq(65, a.preview(5));
    eq(0, a.reading());
  }

  static void tc9() {
    WaterService s = new WaterService();
    s.add(new DomesticAccount("D", 0));
    s.add(new CommercialAccount("C", 0));
    s.add(new RecycledAccount("R", 0));
    eq(160, s.fixedTotal());
  }

  static void tc10() {
    throw new AssertionError(
      "For a DomesticAccount opened at 100, bill 111 and assert 98 and saved reading 111. Reject 110 and assert saved reading remains 111. Bill 112 for 45, then bill 112 again for the fixed-only 40; saved reading remains 112."
    );
  }

  public static void main(String[] args) {
    int passed = 0;
    try {
      tc1();
      passed++;
      System.out.println("TC1 PASS: Reject invalid meter readings");
    } catch (Throwable e) {
      System.out.println(
        "TC1 FAIL: Reject invalid meter readings: " + e.getMessage()
      );
    }
    try {
      tc2();
      passed++;
      System.out.println("TC2 PASS: Domestic first slab boundary");
    } catch (Throwable e) {
      System.out.println(
        "TC2 FAIL: Domestic first slab boundary: " + e.getMessage()
      );
    }
    try {
      tc3();
      passed++;
      System.out.println("TC3 PASS: Domestic progressive excess");
    } catch (Throwable e) {
      System.out.println(
        "TC3 FAIL: Domestic progressive excess: " + e.getMessage()
      );
    }
    try {
      tc4();
      passed++;
      System.out.println("TC4 PASS: Commercial fixed override");
    } catch (Throwable e) {
      System.out.println(
        "TC4 FAIL: Commercial fixed override: " + e.getMessage()
      );
    }
    try {
      tc5();
      passed++;
      System.out.println("TC5 PASS: Recycled free allowance");
    } catch (Throwable e) {
      System.out.println(
        "TC5 FAIL: Recycled free allowance: " + e.getMessage()
      );
    }
    try {
      tc6();
      passed++;
      System.out.println("TC6 PASS: Cumulative meter delta");
    } catch (Throwable e) {
      System.out.println("TC6 FAIL: Cumulative meter delta: " + e.getMessage());
    }
    try {
      tc7();
      passed++;
      System.out.println("TC7 PASS: Commit accepted reading");
    } catch (Throwable e) {
      System.out.println(
        "TC7 FAIL: Commit accepted reading: " + e.getMessage()
      );
    }
    try {
      tc8();
      passed++;
      System.out.println("TC8 PASS: Preview purity");
    } catch (Throwable e) {
      System.out.println("TC8 FAIL: Preview purity: " + e.getMessage());
    }
    try {
      tc9();
      passed++;
      System.out.println("TC9 PASS: Polymorphic service fixed total");
    } catch (Throwable e) {
      System.out.println(
        "TC9 FAIL: Polymorphic service fixed total: " + e.getMessage()
      );
    }
    try {
      tc10();
      passed++;
      System.out.println("TC10 PASS: Sequential bills and rejected rollback");
    } catch (Throwable e) {
      System.out.println(
        "TC10 FAIL: Sequential bills and rejected rollback: " + e.getMessage()
      );
    }
    System.out.println("SUMMARY " + passed + "/10 PASS");
    if (passed != 10) System.exit(1);
  }
}
