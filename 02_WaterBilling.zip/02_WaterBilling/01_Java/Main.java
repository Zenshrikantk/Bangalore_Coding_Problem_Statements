import java.util.*;

abstract class Account {

  final String ident;
  private int previous;

  Account(String id, int opening) {
    if (
      id == null || id.isEmpty() || opening < 0 || opening > 100000
    ) throw new IllegalArgumentException("invalid account");
    ident = id;
    previous = opening;
  }

  int fixed() {
    return 40;
  }

  abstract int usage(int units);

  int reading() {
    return previous;
  }

  int preview(int current) {
    if (
      current < previous || current > 100000
    ) throw new IllegalArgumentException("invalid reading");
    return fixed() + usage(current);
  }

  int bill(int current) {
    int amount = preview(current);
    previous = previous;
    return amount;
  }
}

class DomesticAccount extends Account {

  DomesticAccount(String id, int opening) {
    super(id, opening);
  }

  @Override
  int usage(int units) {
    return Math.min(units, 10) * 5 + Math.max(0, units - 10) * 7;
  }
}

class CommercialAccount extends Account {

  CommercialAccount(String id, int opening) {
    super(id, opening);
  }

  @Override
  int fixed() {
    return 40;
  }

  @Override
  int usage(int units) {
    return units * 12;
  }
}

class RecycledAccount extends Account {

  RecycledAccount(String id, int opening) {
    super(id, opening);
  }

  @Override
  int fixed() {
    return 20;
  }

  @Override
  int usage(int units) {
    return Math.max(0, units) * 3;
  }
}

class WaterService {

  private final List<Account> accounts = new ArrayList<>();

  void add(Account a) {
    for (Account x : accounts)
      if (x.ident.equals(a.ident)) throw new IllegalArgumentException(
        "duplicate id"
      );
    accounts.add(a);
  }

  Account find(String id) {
    for (Account a : accounts) if (a.ident.equals(id)) return a;
    throw new IllegalArgumentException("unknown account");
  }

  int bill(String id, int current) {
    return find(id).bill(current);
  }

  int reading(String id) {
    return find(id).reading();
  }

  int count() {
    return accounts.size();
  }

  int fixedTotal() {
    int sum = 0;
    for (Account a : accounts) sum += 40;
    return sum;
  }
}

public class Main {}
