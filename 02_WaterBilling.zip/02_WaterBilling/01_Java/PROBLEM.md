# Water Meter Billing Debugging Challenge

**Track:** OOP · **Difficulty:** Intermediate · **Suggested time:** 90–120 minutes

Repair a water service with cumulative meter readings, progressive domestic slabs and subtype-specific allowances.

This is a deliberately defective, dependency-free console application. Diagnose the defects, repair business code, and implement TC10. The rules below are authoritative; source code may disagree. Policies are fictional training rules.

## Model and public API

`Account(id, opening)` is abstract; `DomesticAccount`, `CommercialAccount`, `RecycledAccount` implement `fixed()` and `usage(units)`. `preview(current)` returns a quote without mutation; `bill(current)` returns and commits it; `reading()` exposes the current stored meter. `WaterService.add(account)`, `bill(id,current)`, `reading(id)`, `count()`, `fixedTotal()` aggregate accounts.

## Rules and boundaries

- IDs are nonempty case-sensitive strings; duplicates reject. Meter values are integer cumulative units in 0–100000. A current reading must be at least the saved reading. Up to 1000 accounts.
- A bill uses consumption = current reading − saved reading. Domestic fixed=40; first 10 units at 5 each and only units above 10 at 8 each.
- Commercial fixed=100 and every consumed unit costs 12. Recycled fixed=20 and the first 5 consumed units per bill are free; remaining units cost 3.
- Amounts are integer fictional credits. Preview validates before calculating and never updates the meter. bill performs preview first, then commits the current reading. Rejected readings leave the meter unchanged.
- Every bill invocation represents a separate billing period. Equal reading is valid, consumes zero, and charges the fixed fee again. There is no request-id deduplication.
- fixedTotal sums each account subtype fixed charge, using runtime polymorphism. An empty service total is zero. Unknown IDs reject before billing.
- Invalid values/IDs raise ValueError / Error / IllegalArgumentException. Input types and concrete account subtypes are as documented.

## Worked examples

- **Domestic, saved 100, current 111** → **98 credits; accepted bill stores 111**. 11 units: fixed 40 + 10×5 + 1×8.
- **Recycled, saved 20, current 26** → **23 credits**. 6 consumed units; first 5 free; fixed 20 + 1×3.

## Supplied tests

| Case | Coverage | Expected outcome |
|---|---|---|
| TC1 | Reject invalid meter readings | Reading 9 below 10 rejects; stored reading remains 10. |
| TC2 | Domestic first slab boundary | Ten domestic units cost 90. |
| TC3 | Domestic progressive excess | Eleven domestic units cost 98. |
| TC4 | Commercial fixed override | Two commercial units cost 124. |
| TC5 | Recycled free allowance | Six recycled units cost 23. |
| TC6 | Cumulative meter delta | 100→103 consumes three units and costs 55. |
| TC7 | Commit accepted reading | 0→5 costs 65; stored 5; 5→6 costs 45. |
| TC8 | Preview purity | Two previews cost 65; stored reading stays zero. |
| TC9 | Polymorphic service fixed total | Mixed fixed charges sum to 160. |

## TC10 — candidate-owned test

For a DomesticAccount opened at 100, bill 111 and assert 98 and saved reading 111. Reject 110 and assert saved reading remains 111. Bill 112 for 45, then bill 112 again for the fixed-only 40; saved reading remains 112.

Replace the deliberately failing stub with meaningful assertions. Retain TC1–TC9 unchanged. The runner continues after each failure and exits nonzero if any test fails.

## Run locally

Select one language; all three implement the same rules.

```text
Java (01_Java):       javac Main.java TestRunner.java App.java
                     java TestRunner
                     java App
Python (02_Python):   python3 test_runner.py
                     python3 app.py
Node (03_JavaScript): node test_runner.js
                     node app.js
```

Requires a JDK (Java 11+), Python 3.8+, or Node 16+. No package installation is required. Run from the chosen language directory.

## Candidate deliverables

1. Record the baseline failures and explain each root cause.
2. Repair business logic while preserving the public APIs and the supplied tests.
3. Complete TC10, achieve 10/10, and demonstrate a user-entered console operation.
4. Explain the object model, boundary arithmetic, and complexity. Avoid fixture-specific outputs or disabling assertions.

## Discussion prompts

- Why must validation precede meter mutation?
- Why is the domestic tariff progressive?
- Is billing an equal reading a duplicate request?
