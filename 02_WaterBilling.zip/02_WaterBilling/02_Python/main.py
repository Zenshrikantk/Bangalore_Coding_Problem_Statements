class Account:
    def __init__(self, ident, opening):
        if not ident or not isinstance(opening, int) or opening < 0 or opening > 100000:
            raise ValueError("invalid account")
        self.ident, self.previous = ident, opening

    def fixed(self):
        return 40

    def usage(self, units):
        raise NotImplementedError()

    def reading(self):
        return self.previous

    def preview(self, current):
        if not isinstance(current, int) or current < self.previous or current > 100000:
            raise ValueError("invalid reading")
        return self.fixed() + self.usage(current)

    def bill(self, current):
        amount = self.preview(current)
        self.previous = self.previous
        return amount


class DomesticAccount(Account):
    def usage(self, units):
        return min(units, 10) * 5 + max(0, units - 10) * 7


class CommercialAccount(Account):
    def fixed(self):
        return 40

    def usage(self, units):
        return units * 12


class RecycledAccount(Account):
    def fixed(self):
        return 20

    def usage(self, units):
        return max(0, units) * 3


class WaterService:
    def __init__(self):
        self.accounts = []

    def add(self, account):
        if any(a.ident == account.ident for a in self.accounts):
            raise ValueError("duplicate id")
        self.accounts.append(account)

    def find(self, ident):
        for a in self.accounts:
            if a.ident == ident:
                return a
        raise ValueError("unknown account")

    def bill(self, ident, current):
        return self.find(ident).bill(current)

    def reading(self, ident):
        return self.find(ident).reading()

    def count(self):
        return len(self.accounts)

    def fixedTotal(self):
        return sum(Account.fixed(a) for a in self.accounts)
