from main import *
import sys


def eq(expected, actual):
    if expected != actual:
        raise AssertionError(f"expected {expected!r}, got {actual!r}")


def raises(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def tc1():
    a = DomesticAccount("W1", 10)
    raises(lambda: a.bill(9))
    eq(10, a.reading())


def tc2():
    a = DomesticAccount("W2", 0)
    eq(90, a.preview(10))


def tc3():
    a = DomesticAccount("W3", 0)
    eq(98, a.preview(11))


def tc4():
    a = CommercialAccount("W4", 0)
    eq(124, a.preview(2))


def tc5():
    a = RecycledAccount("W5", 0)
    eq(23, a.preview(6))


def tc6():
    a = DomesticAccount("W6", 100)
    eq(55, a.preview(103))


def tc7():
    a = DomesticAccount("W7", 0)
    eq(65, a.bill(5))
    eq(5, a.reading())
    eq(45, a.bill(6))


def tc8():
    a = DomesticAccount("W8", 0)
    eq(65, a.preview(5))
    eq(65, a.preview(5))
    eq(0, a.reading())


def tc9():
    s = WaterService()
    s.add(DomesticAccount("D", 0))
    s.add(CommercialAccount("C", 0))
    s.add(RecycledAccount("R", 0))
    eq(160, s.fixedTotal())


def tc10():
    raise AssertionError(
        "For a DomesticAccount opened at 100, bill 111 and assert 98 and saved reading 111. Reject 110 and assert saved reading remains 111. Bill 112 for 45, then bill 112 again for the fixed-only 40; saved reading remains 112."
    )


if __name__ == "__main__":
    passed = 0
    try:
        tc1()
        passed += 1
        print("TC1 PASS: Reject invalid meter readings")
    except Exception as e:
        print("TC1 FAIL: Reject invalid meter readings: " + str(e))
    try:
        tc2()
        passed += 1
        print("TC2 PASS: Domestic first slab boundary")
    except Exception as e:
        print("TC2 FAIL: Domestic first slab boundary: " + str(e))
    try:
        tc3()
        passed += 1
        print("TC3 PASS: Domestic progressive excess")
    except Exception as e:
        print("TC3 FAIL: Domestic progressive excess: " + str(e))
    try:
        tc4()
        passed += 1
        print("TC4 PASS: Commercial fixed override")
    except Exception as e:
        print("TC4 FAIL: Commercial fixed override: " + str(e))
    try:
        tc5()
        passed += 1
        print("TC5 PASS: Recycled free allowance")
    except Exception as e:
        print("TC5 FAIL: Recycled free allowance: " + str(e))
    try:
        tc6()
        passed += 1
        print("TC6 PASS: Cumulative meter delta")
    except Exception as e:
        print("TC6 FAIL: Cumulative meter delta: " + str(e))
    try:
        tc7()
        passed += 1
        print("TC7 PASS: Commit accepted reading")
    except Exception as e:
        print("TC7 FAIL: Commit accepted reading: " + str(e))
    try:
        tc8()
        passed += 1
        print("TC8 PASS: Preview purity")
    except Exception as e:
        print("TC8 FAIL: Preview purity: " + str(e))
    try:
        tc9()
        passed += 1
        print("TC9 PASS: Polymorphic service fixed total")
    except Exception as e:
        print("TC9 FAIL: Polymorphic service fixed total: " + str(e))
    try:
        tc10()
        passed += 1
        print("TC10 PASS: Sequential bills and rejected rollback")
    except Exception as e:
        print("TC10 FAIL: Sequential bills and rejected rollback: " + str(e))
    print(f"SUMMARY {passed}/10 PASS")
    sys.exit(0 if passed == 10 else 1)
