from main import *


def make():
    s = WaterService()
    s.add(DomesticAccount("HOME", 100))
    s.add(CommercialAccount("SHOP", 200))
    s.add(RecycledAccount("GARDEN", 0))
    return s


state = make()
while True:
    print("1 Demo  2 Enter operation  3 Report  4 Reset/help  5 Exit")
    try:
        choice = input("> ").strip()
        if choice == "5":
            break
        if choice == "1":
            print("Domestic 100→111:", DomesticAccount("DEMO", 100).preview(111))
        elif choice == "2":
            ident = input("Account HOME/SHOP/GARDEN: ").strip()
            current = int(input("Cumulative reading: "))
            print("Bill:", state.bill(ident, current))
        elif choice == "3":
            print("Fixed total:", state.fixedTotal())
            for ident in ["HOME", "SHOP", "GARDEN"]:
                print(ident, state.reading(ident))
        elif choice == "4":
            state = make()
            print(
                "Reset opening meters: HOME=100, SHOP=200, GARDEN=0. Every accepted bill charges its fixed fee."
            )
        else:
            print("Choose 1–5")
    except (EOFError, KeyboardInterrupt):
        break
    except (ValueError, TypeError) as e:
        print("Rejected:", e)
